# Projet **CIMP** [Console Image Manipulation Program]

### Aperçu
Ce dépôt contient le projet **CIMP**, 
un programme de manipulation d'images 
utilisant, principalement, une interface console.


####Introduction

Dans le cadre de ce projet, la documentation a été généré de manière la plus complète possible.
La documentation se trouve dans le répertoire 
*./Docs/html/*
Ouvrir index.html

####Installation

#####Librairie nécéssaire
- *SDL version 2.0 ou plus récent*  [Librairie SDL2](https://www.libsdl.org/download-2.0.php)
- *SDL Image version 2.0 ou plus récent* [Librairie SDL2 Image](https://www.libsdl.org/projects/SDL_image/)
- *SDL2_gfx version 1.0.4 ou plus récent* [Librairie SDL2_gfx](http://www.ferzkopp.net/wordpress/2016/01/02/sdl_gfx-sdl2_gfx/)
- *Libpng 1.6 ou plus récent* [Librairie libpng](http://www.libpng.org/pub/png/libpng.html)

#####Lancer le programme
- Dans une console, placez-vous dans le repertoire /src puis saisissez :
```
make
```
- Puis pour lancer le programme **CIMP** :
```
./cimp
```
