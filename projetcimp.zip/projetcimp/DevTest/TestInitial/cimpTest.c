#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#define WIN_SIZE_X 640
#define WIN_SIZE_Y 480

void initSDL();
SDL_Window* initWindow();
int printPicture(SDL_RWops*, SDL_Window*);
SDL_Surface* initSurface(SDL_RWops*);
int cli_events_listener();
int graphic_events_listener(SDL_Event);
int window_event(SDL_Event);
int mousedown_event(SDL_Event);
void execute(int code, SDL_Window* pWindow);


// Programme principal
int main(void) {
    initSDL();

    SDL_Window* pWindow = initWindow(1);
    SDL_Window* pWindow2 = initWindow(2);
        // Chargement d un fond par defaut
    // Creer une fonction demandant a l utilisateur un chemin vers une image
    // Attention, seul BMP est pris en charge par SDL2
    // Pour les autres formats, voir SDL_image2
    // Il y aura donc une gestion differente de l image suivant son extention
    SDL_RWops* rwop;
    SDL_RWops* rwop2;
    rwop = SDL_RWFromFile("pictures/scream.jpg", "rb");
    rwop2 = SDL_RWFromFile("pictures/fox.jpg", "rb");
    printPicture(rwop, pWindow);
    printPicture(rwop2, pWindow2);

    int code = 0;
    int code2 = 0;
    int flag1=0;
    int flag2=0;

    while (1) {
      //Utiliser SDL_WINDOWEVENT pour gerer les evenement sur les diffenrentes fenetres
        SDL_Event ev;

        /*
        --SDL_EventState MOUSEMOTION DISABLE--
        Bloque la lecture des evenements de mouvements de souris
        Inutile dans notre cas (sauf si besoin de dessiner)
        Evite de surcharger la pile d evenement inutilement
        */
        SDL_EventState(SDL_MOUSEMOTION,SDL_DISABLE);

        // --> Besoin de faire un fork au lancement du programme, un qui lis sur la console, l'autre sur la fenetre
        //code = cli_events_listener();


        if ((code = graphic_events_listener(ev)) == -1){
          SDL_DestroyWindow(pWindow);
          flag1=-1;
        }
        if ((code2 = graphic_events_listener(ev)) == -1){
          SDL_DestroyWindow(pWindow2);
          flag2=-1;
        }
        if ((flag2 ==-1) && (flag1==-1)){
            printf("test\n");
            break;
          }

        execute(code, pWindow);
        execute(code2, pWindow2);
    }
    SDL_DestroyWindow(pWindow2);
    SDL_DestroyWindow(pWindow);
    SDL_Quit();

    printf("Bye ! \n");

    return EXIT_SUCCESS;
}



/** Initialise la bibliotheque SDL
 * Ne prend pas de parametre
 * Quite le programme sur un EXIT_FAILURE si ne peut etre initialise
 * Ne retourne rien
 */
void initSDL() {
    if (SDL_Init(SDL_INIT_VIDEO) != 0) {
        fprintf(stdout, "SDL init failure (%s) \n",
            SDL_GetError());
        exit(EXIT_FAILURE);
    }
}


/** Initialise la fenetre
 * Ne prend pas de parametre
 * Retourne un pointeur de type SDL_Window
 */
SDL_Window* initWindow (int nb) {
    char tmpfile[50];
    char* nom="SDL2 - Window";
    sprintf(tmpfile,"%s %d",nom,nb);
    SDL_Window* pWindow =  SDL_CreateWindow(tmpfile, // nom
                                            SDL_WINDOWPOS_CENTERED, // pos x
                                            SDL_WINDOWPOS_CENTERED, // pos Y
                                            WIN_SIZE_X, // largeur
                                            WIN_SIZE_Y, // hauteur
                                            SDL_WINDOW_SHOWN); // option
    if (!pWindow) {
        fprintf(stderr, "Window creation failure: %s \n", SDL_GetError());
        SDL_Quit();
        exit(EXIT_FAILURE);
    }

    return pWindow;
}

/** Initialise un moteur de rendu
 * Prend en parametre un type :
 *  un pointeur SDL_Window
 * Retourne un pointeur de type SDL_Renderer
 */
SDL_Renderer* initRenderer (SDL_Window* pWindow) {
    SDL_Renderer* renderer = SDL_CreateRenderer(pWindow, -1, SDL_RENDERER_ACCELERATED);

    if (!renderer) {
        fprintf(stderr, "Renderer creation failure: %s", SDL_GetError());
        SDL_DestroyWindow(pWindow);
        SDL_Quit();
        exit(EXIT_FAILURE);
    }

    SDL_SetRenderDrawColor(renderer, 255, 255, 255, 255);
    SDL_RenderClear(renderer);
    SDL_RenderPresent(renderer);

    return renderer;
}


/** Affiche une image sur la fenetre
 * Prend en parametre un type :
 *  un pointeur SDL_RWops de l image a affiche
 *  un pointeur SDL_Window de la fenetre cible
 * Ne retourne rien
 */
int printPicture(SDL_RWops* rwop, SDL_Window* pWindow) {
    if (rwop == NULL || pWindow == NULL) {
        fprintf(stderr, "initSurface: wrong parameter \n");
        return -1;
    }

    SDL_Surface* picture;

    if (!(picture = initSurface(rwop))) {
        return -1;
    }

    int window_w = 0;
    int window_h = 0;

    SDL_GetWindowSize(pWindow, &window_w, &window_h);

    SDL_Rect dest = { window_w/2 - picture->w/2,
                      window_h/2 - picture->h/2,
                      0,
                      0};

    int rc = SDL_BlitSurface(picture, NULL, SDL_GetWindowSurface(pWindow), &dest);
    SDL_FreeSurface(picture);

    if (rc < 0) {
        fprintf(stderr, "SDL_BlitSurface: %s \n", SDL_GetError());
        return -1;
    }

    SDL_UpdateWindowSurface(pWindow);

    return 0;
}


/** Initilisation d une image avant affichage
 * Prend en parametre un type :
 *  un pointeur SDL_RWops de l image a charge
 * Retourne un pointeur SDL_Surface
 */
SDL_Surface* initSurface (SDL_RWops* rwop) {
    if (rwop == NULL) {
        fprintf(stderr, "initSurface: wrong parameter \n");
        return NULL;
    }

    SDL_Surface* picture = IMG_LoadJPG_RW(rwop);

    if(!picture) {
        fprintf(stderr, "IMG_LoadJPG_RW: %s \n", IMG_GetError());
        return NULL;
    }

    return picture;
}

/** Lit les evenements envoye par la console
 * Ne prend pas de parametre
 * Retourne un entier correspondant a une action a executer
 */
int cli_events_listener () {
    int code = 0;

    char cmd[10];
    printf("Votre commande: ");
    scanf("%s", cmd);
    printf("\n %s", cmd);

    return code;
}


/** Lit les evenements sur la fenetre
 * Prend en parametre un type SDL_Event
 * Retourne un entier correspondant a une action a executer
 */
int graphic_events_listener (SDL_Event ev) {
    int code = 0;

    while (SDL_PollEvent(&ev)) {
        switch(ev.type) {
            case SDL_WINDOWEVENT :
            code = window_event(ev);
            break;
            case SDL_MOUSEBUTTONDOWN :
            code = mousedown_event(ev);
            break;
        }
    }

    return code;
}


/** Gestion d un evenement de fenetre
 * Prend en parametre un type SDL_Event
 * Retourne un entier correspondant a une action a executer
 */
int window_event (SDL_Event ev)  {
    int code = 0;

    if (ev.window.event == SDL_WINDOWEVENT_MINIMIZED) {
        printf("Window minimized \n");
        code = 1;
    }
    else if (ev.window.event == SDL_WINDOWEVENT_CLOSE) {
        printf("Close request \n");
        code = -1;
    }

    return code;
}


/** Gestion d un evenement de pression sur un bouton de la souris
 * Prend en parametre un type SDL_Event
 * Retourne un entier correspondant a une action a executer
 */
int mousedown_event (SDL_Event ev) {
    int code = 0;

    if (ev.button.state == SDL_PRESSED) {
        printf("Pressure \n");
        printf("Mouse actioni \n");
        printf("#clicks: %u \n", ev.button.clicks);
        printf("Position[x;y]: [%u;%u] \n", ev.button.x, ev.button.y);
        code = 1;
    }

    return code;
}


/** Execution de l evenement correspondant au code
 * Prend en parametre un type
 *   int de l action a execute
 *   pointeur SDL_Window de la fenetre ou executer l action
 *   (PS: Ici, on est sur une seule fenetre, si plusieurs fenetres,
 *   les evenements doivent aussi preciser sur quelless fenetres l action a ete produite
 *   On peut imaginer une fenetre avec des boutons qui agirait sur la fenetre principale)
 * Ne retourne rien
 */
void execute (int code, SDL_Window* pWindow) {
    if (pWindow != NULL) {

        switch (code) {
            case 1 :
                printf("Je tourne encore ! \n");
            break;
        }
    }
}
