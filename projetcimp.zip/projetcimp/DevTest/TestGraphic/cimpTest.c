#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <stdlib.h>

#define WIN_DEFSIZE_X 400
#define WIN_DEFSIZE_Y 200

void initSDL();
SDL_Window* initWindow();
SDL_Renderer* initRenderer(SDL_Window*);
SDL_Texture* initTexture(SDL_Renderer*);
int resize_window(int, int, SDL_Window*, SDL_Texture*);
int repaint_window(SDL_Window*, SDL_Texture*);
int load_picture(const char*, SDL_Window*, SDL_Texture**);
int graphic_events_listener(SDL_Event, SDL_Window*, SDL_Texture*);
int window_event(SDL_Event, SDL_Window*, SDL_Texture*);
int mousedown_event(SDL_Event, SDL_Window*, SDL_Texture*);
int draw_rect_test(SDL_Renderer*);


// Programme principal
int main(void) {
    initSDL();
    printf("Hello ! \n");

    // Initialisation de la fenetre par defaut
    SDL_Window *window = initWindow();
    SDL_Renderer *renderer = initRenderer(window);
    SDL_Texture *texture = NULL;

    // Initialisation des events
    SDL_Event ev;
    SDL_EventState(SDL_MOUSEMOTION,SDL_DISABLE);

    // Ouverture de fichier
    printf("Chargement image \n");
    load_picture("pictures/rock.jpg", window, &texture);
    // printf("Modification taille \n");
    // resize_window(200,200, window, texture);


    //draw_rect_test(renderer);

    while (graphic_events_listener(ev, window, texture)) {
        // Boucle de lecture des evenements
    }


    // Destruction des variables
    SDL_DestroyTexture(texture);
    SDL_DestroyRenderer(renderer);
    SDL_DestroyWindow(window);
    SDL_Quit();
    
    printf("Bye ! \n");

    return EXIT_SUCCESS;
}



/** Initialise la bibliotheque SDL
 * Ne prend pas de parametre
 * Quite le programme sur un EXIT_FAILURE si ne peut etre initialise
 * Ne retourne rien 
 */
void initSDL() {
    if (SDL_Init(SDL_INIT_VIDEO) != 0) {
        fprintf(stdout, "SDL init failure (%s) \n", 
            SDL_GetError());
        exit(EXIT_FAILURE);
    }
}


/** Initialise la fenetre
 * Ne prend pas de parametre
 * Retourne un pointeur de type SDL_Window
 */
SDL_Window* initWindow () {
    SDL_Window* pWindow =  SDL_CreateWindow("SDL2 - Window 1", // nom 
                                            SDL_WINDOWPOS_CENTERED, // pos x
                                            SDL_WINDOWPOS_CENTERED, // pos Y
                                            WIN_DEFSIZE_X, // largeur
                                            WIN_DEFSIZE_Y, // hauteur
                                            SDL_WINDOW_SHOWN | SDL_WINDOW_RESIZABLE); // option
    if (!pWindow) {
        fprintf(stderr, "Window creation failure: %s \n", SDL_GetError());
        SDL_Quit();
        exit(EXIT_FAILURE);
    }

    return pWindow;
}


/** Initialise un moteur de rendu
 * Prend en parametre un type :
 *  un pointeur SDL_Window
 * Retourne un pointeur de type SDL_Renderer
 */
SDL_Renderer* initRenderer (SDL_Window* Window) {
    SDL_Renderer* renderer = SDL_CreateRenderer(Window, -1, SDL_RENDERER_ACCELERATED);
    
    if (!renderer) {
        fprintf(stderr, "Renderer creation failure: %s", SDL_GetError());
        SDL_DestroyWindow(Window);
        SDL_Quit();
        exit(EXIT_FAILURE);
    }

    SDL_SetRenderDrawColor(renderer, 255, 255, 255, 255);
    SDL_RenderClear(renderer);
    SDL_RenderPresent(renderer);

    return renderer;
}


int resize_window (int new_size_w, int new_size_h, SDL_Window* window, SDL_Texture* texture) {
    SDL_SetWindowSize(window, new_size_w, new_size_h);

    printf("New Window size \n"
           "  w= %d \n"
           "  h= %d \n", new_size_w, new_size_h);

    return 1;
}


int repaint_window (SDL_Window* window, SDL_Texture* texture) {
    int newPos_x, newPos_y;
    int texture_w, texture_h;
    int window_w, window_h;
    SDL_Rect DestR;


    SDL_Renderer* renderer = SDL_GetRenderer(window);
    SDL_RenderClear(renderer);                

    SDL_GetWindowSize(window, &window_w, &window_h);
    SDL_QueryTexture(texture, NULL, NULL, &texture_w, &texture_h);
    newPos_x = (window_w/ 2) - (texture_w / 2);
    newPos_y = (window_h / 2) - (texture_h / 2); 
    DestR.x = (newPos_x < 0)? 0 : newPos_x;
    DestR.y = (newPos_y < 0)? 0 : newPos_y;
    DestR.w = texture_w;
    DestR.h = texture_h;

    printf( "Taille de l'image: \n"
            "Largeur= %d \n"
            "Hauteur= %d \n", texture_w, texture_h);

    SDL_RenderCopy(renderer, texture, NULL, &DestR);

    SDL_RenderPresent(renderer);

    return 0;
}

/** Chargement d une image
 * Prend en parametre un type :
 *  un pointeur SDL_Renderer
 *  un chemin vers l'image
 * Retourne un pointeur de type SDL_Texture
 */
int load_picture (const char* path, SDL_Window* window, SDL_Texture** texture) {
    int texture_w, texture_h;

    printf("Image chargé \n");

    SDL_Renderer* renderer = SDL_GetRenderer(window);

    if ( !(*texture = IMG_LoadTexture(renderer, path)) ) {
        fprintf(stderr, "Picture loading failed \n");
        return -1;
    }


    SDL_QueryTexture(*texture, NULL, NULL, &texture_w, &texture_h);
    resize_window(texture_w, texture_h, window, *texture);

    return 0;
}


/** Lit les evenements sur la fenetre
 * Prend en parametre un type SDL_Event
 * Retourne un entier correspondant a une action a executer
 */
int graphic_events_listener (SDL_Event ev, SDL_Window* window, SDL_Texture* texture) {

    while (SDL_PollEvent(&ev)) {
        switch(ev.type) {
            case SDL_WINDOWEVENT :
            {
                return window_event(ev, window, texture);
            }
            case SDL_MOUSEBUTTONDOWN :
            {
                return mousedown_event(ev, window, texture);
            }
        }
    }

    return 1; 
}


/** Gestion d un evenement de fenetre
 * Prend en parametre un type SDL_Event
 * Retourne un entier correspondant a une action a executer
 */
int window_event (SDL_Event ev, SDL_Window* window, SDL_Texture* texture)  {
    switch (ev.window.event) {
        case SDL_WINDOWEVENT_MINIMIZED :
        {
            printf("Window minimized \n");
            
            return 1;
        }
        case SDL_WINDOWEVENT_CLOSE :
        {
            printf("Close request \n");
            
            return 0;
        }
        case SDL_WINDOWEVENT_SIZE_CHANGED :
        {
            printf("Size changed, repaint needed \n");
            repaint_window(window, texture);
            return 1;   
        }
        case SDL_WINDOWEVENT_RESIZED :
        {   
            printf("Resized \n");
            return 1;
        }
        default :
            return 1;
    }

}


/** Gestion d un evenement de pression sur un bouton de la souris
 * Prend en parametre un type SDL_Event
 * Retourne un entier correspondant a une action a executer
 */
int mousedown_event (SDL_Event ev, SDL_Window* window, SDL_Texture* texture) {

    switch (ev.button.state) {
        case SDL_PRESSED :
        {
            printf("Pressure \n");
            printf("Mouse actioni \n");
            printf("#clicks: %u \n", ev.button.clicks);
            printf("Position[x;y]: [%u;%u] \n", ev.button.x, ev.button.y);
            
            return 1;
        }
        default :
            return 1;
    }

}


int draw_rect_test (SDL_Renderer* renderer) {
        SDL_Rect rect[2];
        rect[0].x = rect[0].y = 0;
        rect[0].w = rect[1].w = 250;
        rect[0].h = rect[1].h = 250;
        rect[1].x = rect[1].y = 250;
        SDL_SetRenderDrawColor(renderer, 255, 0, 0, 255);
        SDL_RenderFillRects(renderer, rect, 2);
        SDL_RenderPresent(renderer);

        return 1;
}