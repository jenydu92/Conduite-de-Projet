/**
 * \file        CIMP_file.h
 * \author      C.Cedric
 * \version     1.0
 * \date        Avril 2019
 * \brief       Définit l'interface de gestion de fichiers.
 *
 * \details     Ce module permet la gestion de fichiers.
 */

#ifndef _CIMP_FILE_H_
#define _CIMP_FILE_H_

#include <dirent.h>
#include <errno.h>

/*!
*   \fn static char* CIMP_GetExt(char* path)
*   \brief Fonction récupérant l'extention du fichier.
* 
*   \param path Le chemin d'enregistrement.
*
*   \return L'extention du fichier.
*/
char* CIMP_GetExt (char*);

/*!
*   \fn char* CIMP_GetDirname (char* path)
*   \brief Fonction de récupération du dirname d'un chemin.
* 
*   \param path Le chemin d'enregistrement.
*
*   \return char* La partie dirname du chemin.
*
*   Renvoie un nouveau pointeur qui doit être free
*   quand plus utilisé.
*/
char* CIMP_GetDirname (char*);

/*!
*   \fn char* CIMP_GetBasename (char* path)
*   \brief Fonction de récupération du basename d'un chemin.
* 
*   \param path Le chemin d'enregistrement.
*
*   \return char* La partie basename du chemin.
*
*   Renvoie un nouveau pointeur qui doit être free
*   quand plus utilisé.
*/
char* CIMP_GetBasename (char*);

/*!
*   \fn int CIMP_PathExists (char* path)
*   \brief Fonction vérifiant si le chemin existe.
* 
*   \param path Le chemin d'enregistrement.
*
*   \return 1 si pas d'erreur , sinon 0.
*/
int CIMP_PathExists (char*);

#endif