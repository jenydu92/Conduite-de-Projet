/**
 * \file        CIMP_stringconverter.c
 * \author      C.Cedric
 * \version     1.0
 * \date        Avril 2019
 * \brief       Définit le convertisseur de chaine de caractères.
 *
 * \details    Ce module permet de convertir une chaine de caractères en un autre type.
 */

#include "CIMP_stringconverter.h"

// Permet de convertir une chaine en type size_t
int stringToSize_t(char* s, size_t* number) {
    char* next_s = NULL;
    unsigned long uNumber;

    uNumber = strtoul(s, &next_s, 10);

    if ( strcmp(next_s, "") )
        return 0;

    *number = uNumber;

    return 1;
}

// Convertit chaque caractère d'une chaine en minuscule
void stringToLowerCase(char* s) {
    for (int i = 0; s[i] != '\0'; i++)
        s[i] = tolower(s[i]);
}