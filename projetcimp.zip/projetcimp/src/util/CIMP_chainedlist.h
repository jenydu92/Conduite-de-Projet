/**
 * \file        CIMP_chainedlist.h
 * \author      C.Cedric
 * \version     1.0
 * \date        Avril 2019
 * \brief       Définit l'interface d'une liste chainée générique.
 *
 * \details    Ce module permet la gestion d'une liste chainée générique.
 */

#ifndef _CIMP_CHAINEDLIST_H_
#define _CIMP_CHAINEDLIST_H_

#include <stdlib.h>
#include <stdio.h>

/*!
*   \typedef CIMP_ChainedList
*   \brief La liste chainée.
* 
*   CIMP_ChainedList correspond à une liste chainée.
*   La liste chainée permet de stocker n'importe quel élément.
*   Une condition minimal est que chaque élément soit de la même taille.
*/
typedef struct CIMP_ChainedList CIMP_ChainedList;

/*!
*   \typedef DestroyFunc
*   \brief La fonction de libération de la mémoire de l'élément.
*/
typedef void (*DestroyFunc)(void**);

/*!
*   \fn int CIMP_CreateChainedList(CIMP_ChainedList** l, size_t sizeOfEl)
*   \brief Fonction d'initialisation de la liste chainée.
* 
*   \param l L'adresse du pointeur vers la liste chainée.
*   \param sizeOfEl Le poids que devront avoir chaque élément de la liste.
*
*   \return 0 si aucune erreur, sinon un entier négatif.
*
*   Créé automatiquement l'en-tête de la liste chainée.
*/
int CIMP_CreateChainedList(CIMP_ChainedList**, size_t);

/*!
*   \fn void* CIMP_PopElement(CIMP_ChainedList* l)
*   \brief Fonction retournant le premier élément et le retirant de la liste.
* 
*   \param l L'adresse du pointeur vers la liste chainée.
*
*   \return Le pointeur vers l'élément si aucune erreur, sinon NULL.
*/
void* CIMP_PopElement(CIMP_ChainedList*);

/*!
*   \fn void* CIMP_GetFirstElement(const CIMP_ChainedList* l)
*   \brief Fonction retournant le premier élément.
* 
*   \param l L'adresse du pointeur vers la liste chainée.
*
*   \return Le pointeur vers l'élément si aucune erreur, sinon NULL.
*/
void* CIMP_GetFirstElement(const CIMP_ChainedList*);

/*!
*   \fn void* CIMP_GetElement(const CIMP_ChainedList* l, size_t pos)
*   \brief Fonction retournant un élément.
* 
*   \param l L'adresse du pointeur vers la liste chainée.
*   \param pos La position de l'élément dans la liste.
*
*   \return Le pointeur vers l'élément si aucune erreur, sinon NULL.
*/
void* CIMP_GetElement(const CIMP_ChainedList*, size_t);

/*!
*   \fn size_t CIMP_ChainedListSize(CIMP_ChainedList* l)
*   \brief Fonction retournant la taille de la liste chainée.
* 
*   \param l L'adresse du pointeur vers la liste chainée.
*
*   \return La taille de la liste chainée.
*/
size_t CIMP_ChainedListSize(CIMP_ChainedList*);

/*!
*   \fn int CIMP_AddElement(CIMP_ChainedList* l, void* el, size_t sizeOfEl)
*   \brief Fonction ajoutant un élément au début de la liste chainée.
* 
*   \param l L'adresse du pointeur vers la liste chainée.
*   \param el L'élément à ajouter.
*   \param sizeOfEl Le poids de l'élément à ajouter.
*
*   \return 0 si aucune erreur, sinon un entier négatif.
*/
int CIMP_AddElement(CIMP_ChainedList*, void*, size_t);

/*!
*   \fn int CIMP_RemoveFirstElement(CIMP_ChainedList* l, DestroyFunc destroyFunc)
*   \brief Fonction supprimant le premier élément de la liste chainée.
* 
*   \param l L'adresse du pointeur vers la liste chainée.
*   \param destroyFunc La fonction de suppression spécifique à l'élément.
*
*   \return 0 si aucune erreur, sinon un entier négatif.
*/
int CIMP_RemoveFirstElement(CIMP_ChainedList*, DestroyFunc);

/*!
*   \fn int CIMP_RemoveElement(CIMP_ChainedList* l, size_t pos, DestroyFunc destroyFunc)
*   \brief Fonction supprimant un élément de la liste chainée.
* 
*   \param l L'adresse du pointeur vers la liste chainée.
*   \param pos La position dans la liste chainée.
*   \param destroyFunc La fonction de suppression spécifique à l'élément.
*
*   \return 0 si aucune erreur, sinon un entier négatif.
*/
int CIMP_RemoveElement(CIMP_ChainedList*, size_t, DestroyFunc);

/*!
*   \fn void CIMP_DestroyChainedList(CIMP_ChainedList** l, DestroyFunc destroyFunc)
*   \brief Fonction libérant la mémoire occupé par la liste chainée.
* 
*   \param l L'adresse du pointeur vers la liste chainée.
*   \param destroyFunc La fonction de suppression spécifique aux éléments de la fonctions.
*
*   \return 0 si aucune erreur, sinon un entier négatif.
*/
void CIMP_DestroyChainedList(CIMP_ChainedList**, DestroyFunc);


#endif