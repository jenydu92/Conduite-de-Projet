/**
 * \file        CIMP_savefile.h
 * \author      C.Cedric
 * \version     1.0
 * \date        Avril 2019
 * \brief       Définit l'interface de sauvegarde de fichier.
 *
 * \details     Ce module permet de contrôler le format d'enregistrement demandé et de redirigé vers le module adéquat.
 */

#ifndef _CIMP_SAVEFILE_H_
#define _CIMP_SAVEFILE_H_
    
#include <SDL2/SDL.h>
#include "CIMP_stringconverter.h"
#include "CIMP_file.h"
#include "CIMP_bmpfile.h"
#include "CIMP_pngfile.h"


/*!
*   \fn int CIMP_SaveFile (char* path, SDL_Surface* surface)
*   \brief Fonction d'enregistrement de fichier.
* 
*   \param path Le chemin d'enregistrement.
*   \param surface La SDL_Surface correspondant à l'image.
*
*   \return O si pas d'erreur, sinon un entier négatif.
*
*   La fonction saveFile permet de rediriger la sauvegarde vers
*   le module correspondant.
*/
int CIMP_SaveFile (char*, SDL_Surface*);

#endif