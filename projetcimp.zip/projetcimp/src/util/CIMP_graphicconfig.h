/**
 * \file        CIMP_graphicconfig.h
 * \author      C.Cedric
 * \version     1.0
 * \date        Avril 2019
 * \brief       Définit l'interface des outils de configuration graphique.
 *
 * \details    Ce module permet d'obtenir des informations sur le système graphique de l'utilisateur.
 */

#ifndef _CIMP_GRAPHICCONFIG_H_
#define _CIMP_GRAPHICCONFIG_H_
    
#include <SDL2/SDL.h>


/*!
*   \fn int CIMP_GetDesktopResolution (int* w, int* h)
*   \brief Fonction permettant de récupérer la résolution de l'écran de l'utilisateur.
* 
*   \param w La largeur de la résolution de l'écran.
*   \param h La hauteur de la résolution de l'écran.
*
*   Les pointeurs vers les entiers w et h seront remplie par la fonction.
*/
int CIMP_GetDesktopResolution(int*, int*);

#endif