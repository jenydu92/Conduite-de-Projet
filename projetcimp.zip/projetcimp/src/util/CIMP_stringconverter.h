/**
 * \file        CIMP_stringconverter.h
 * \author      C.Cedric
 * \version     1.0
 * \date        Avril 2019
 * \brief       Définit l'interface du convertisseur de chaine de caractères.
 *
 * \details    Ce module permet de convertir une chaine de caractères en un autre type.
 */

#ifndef _CIMP_STRINGCONVERTER_H_
#define _CIMP_STRINGCONVERTER_H_

#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <ctype.h>


/*!
*   \fn int stringToSize_t(char* s, size_t* number)
*   \brief Fonction convertissant une chaine de caractère en type size_t.
* 
*   \param s Une chaine de caractère.
*   \param number L'entier non signé récupéré de la chaine.
*
*   \return 0 si pas d'erreur, sinon un entier négatif.
*/
int stringToSize_t(char*, size_t*);

/*!
*   \fn void stringToLowerCase(char* s)
*   \brief Fonction convertissant tout les caractères d'une chaine en minuscule.
* 
*   \param s La chaine de caractère à convertir.
*/
void stringToLowerCase(char*);

#endif