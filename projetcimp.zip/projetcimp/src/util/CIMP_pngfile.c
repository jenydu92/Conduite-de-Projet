/**
 * \file        CIMP_pngfile.c
 * \author      C.Cedric
 * \version     1.0
 * \date        Avril 2019
 * \brief       Définit le gestionnaire de fichier png.
 *
 * \details     Ce module permet de traiter les fichiers png.
 */

#include "CIMP_pngfile.h"

 #if SDL_BYTEORDER == SDL_BIG_ENDIAN
#define rmask 0xFF000000 /*!< Couleur de masque Rouge en Big Endian */
#define gmask 0x00FF0000 /*!< Couleur de masque Vert en Big Endian */
#define bmask 0x0000FF00 /*!< Couleur de masque Bleu en Big Endian */
#define amask 0x000000FF /*!< Couleur de masque Alpha en Big Endian */
#else
#define rmask 0x000000FF /*!< Couleur de masque Rouge en Little Endian */
#define gmask 0x0000FF00 /*!< Couleur de masque Vert en Little Endian */
#define bmask 0x00FF0000 /*!< Couleur de masque Bleu en Little Endian */
#define amask 0xFF000000 /*!< Couleur de masque Alpha en Little Endian */
#endif


/*
* Code de l'enregistrement provenant en grande partie de
*   https://docs.huihoo.com/doxygen/wesnoth/savepng_8cpp_source.html
* En raison d'une documentation de libpng très difficile à lire
* pour un projet à faire avec si peu de temps.  
*/

// Enregistrement au format PNG
int CIMP_SavePNG (SDL_Surface* surface, char* path, char* name) {
    int colortype;
    FILE *dest = NULL;

    png_structp png_ptr = NULL;
    png_infop info_ptr = NULL;
    png_colorp pal_ptr;
    SDL_Palette *pal;


    // Open file for writing (binary mode)
    dest = fopen(path, "wb");
   
    if (dest == NULL) {
        fprintf(stderr, "Could not open file %s for writing\n", path);

        return -1;
    }

    // Initialize write structure
    png_ptr = png_create_write_struct(PNG_LIBPNG_VER_STRING, NULL, NULL, NULL);
    if (png_ptr == NULL) {
        fprintf(stderr, "Could not allocate write struct\n");
        fclose(dest);
      
        return -1;
    }

    // Initialize info structure
    info_ptr = png_create_info_struct(png_ptr);
    if (info_ptr == NULL) {
        fprintf(stderr, "Could not allocate info struct\n");
        fclose(dest);
        png_destroy_write_struct(&png_ptr, (png_infopp)NULL);
      
        return -1;
    }


    if (setjmp(png_jmpbuf(png_ptr))) {
        fprintf(stderr, "Error during png creation\n");
        fclose(dest);
        png_destroy_write_struct(&png_ptr, &info_ptr);

        return -1;
    }

    png_set_write_fn(png_ptr, dest, NULL, NULL);

    colortype = PNG_COLOR_MASK_COLOR;
    if (surface->format->BytesPerPixel > 0
    &&  surface->format->BytesPerPixel <= 8
    && (pal = surface->format->palette)) {
        colortype |= PNG_COLOR_MASK_PALETTE;
        pal_ptr = malloc(pal->ncolors * sizeof(png_color));
        for (int i = 0; i < pal->ncolors; i++) {
            pal_ptr[i].red   = pal->colors[i].r;
            pal_ptr[i].green = pal->colors[i].g;
            pal_ptr[i].blue  = pal->colors[i].b;
        }
        png_set_PLTE(png_ptr, info_ptr, pal_ptr, pal->ncolors);
        free(pal_ptr);
    }
    else if (surface->format->BytesPerPixel > 3 || surface->format->Amask)
        colortype |= PNG_COLOR_MASK_ALPHA;
    
    png_set_IHDR(png_ptr, info_ptr, surface->w, surface->h, 8, colortype,
    PNG_INTERLACE_NONE, PNG_COMPRESSION_TYPE_DEFAULT, PNG_FILTER_TYPE_DEFAULT);


    if (surface->format->Rmask == bmask
    && surface->format->Gmask == gmask
    && surface->format->Bmask == rmask)
        png_set_bgr(png_ptr);

    // Set title
    if (name != NULL) {
        png_text title_text;
        title_text.compression = PNG_TEXT_COMPRESSION_NONE;
        title_text.key = "Title";
        title_text.text = name;
        png_set_text(png_ptr, info_ptr, &title_text, 1);
    }

    png_write_info(png_ptr, info_ptr);


    // Write image data
    for (int i = 0; i < surface->h; i++)
        png_write_row(png_ptr, (png_bytep)(Uint8*)surface->pixels + i * surface->pitch);

    // End write
    png_write_end(png_ptr, NULL);


    fclose(dest);
    png_destroy_write_struct(&png_ptr, &info_ptr);

    return 0;
}