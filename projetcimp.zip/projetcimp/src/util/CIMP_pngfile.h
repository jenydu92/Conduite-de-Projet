/**
 * \file        CIMP_pngfile.h
 * \author      C.Cedric
 * \version     1.0
 * \date        Avril 2019
 * \brief       Définit l'interface du gestionnaire de fichier png.
 *
 * \details     Ce module permet de traiter les fichiers png.
 */

#ifndef _CIMP_PNGFILE_H_
#define _CIMP_PNGFILE_H_
    
#include <SDL2/SDL.h>
#include <png.h>

/*!
*   \fn int CIMP_SavePNG (SDL_Surface* surface, char* path, char* name)
*   \brief Fonction enregistrant le fichier au format png.
* 
*   \param path Le chemin d'enregistrement.
*   \param surface La surface correspondant à l'image.
*   \param name Le nom de l'image.
*
*   \return 0 si pas d'erreur, sinon un entier négatif.
*/
int CIMP_SavePNG (SDL_Surface*, char*, char*);

#endif