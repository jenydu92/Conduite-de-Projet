/**
 * \file        CIMP_graphicconfig.c
 * \author      C.Cedric
 * \version     1.0
 * \date        Avril 2019
 * \brief       Module des outils de configuration graphique.
 *
 * \details    Ce module permet d'obtenir des informations sur le système graphique de l'utilisateur.
 */

#include "CIMP_graphicconfig.h"


int CIMP_GetDesktopResolution (int* w, int* h) {
    SDL_DisplayMode dm;

    if (SDL_GetDesktopDisplayMode(0, &dm) != 0) {
        SDL_Log("Erreur CIMP_GetDesktopResolution: %s", SDL_GetError());
        return -1;
    }

    *w = dm.w;
    *h = dm.h;

    return 0;
}
