/**
 * \file        CIMP_file.h
 * \author      C.Cedric
 * \version     1.0
 * \date        Avril 2019
 * \brief       Définit la gestion de fichiers.
 *
 * \details     Ce module permet la gestion de fichiers.
 */

#include "CIMP_file.h"
#include <string.h>
#include <stdlib.h>
#include <stdio.h>


// Récupère l'extention du fichier
char* CIMP_GetExt (char* path) {
    char* ext = strrchr(path, '.');

    return ext;
}


// Récupère la dirname du chemin
char* CIMP_GetDirname (char* path) {
    char* sep = NULL;
    char* dirname = NULL;
    char* defaultDirname = ".";
    int dirnameSize;

    if( (sep = strrchr(path, '/')) ){
        dirnameSize = strlen(path) - strlen(sep);
    }
    else 
        dirnameSize = 1;

    if ( !(dirname = (char*)malloc((dirnameSize + 1) * sizeof(char))) ) {
        fprintf(stderr, "\033[31;1m Erreur rencontré lors de l'allocation mémoire du dirname dans CIMP_file \033[0m \n");

        return NULL;
    }

    memset(dirname, '\0', (dirnameSize + 1));
    strncpy(dirname, ((dirnameSize == 1)? defaultDirname : path), dirnameSize);

    return dirname;
}


// Récupère la basename du chemin
char* CIMP_GetBasename (char* path) {
    char* sep = NULL;
    char* basename = NULL;
    int basenameSize;


    if( (sep = strrchr(path, '/')) ) {
        if ( strlen(sep) == 1 ) // Vaut 1 si il n'y a rien après le dernier slash
            return NULL;
        sep++;
        basenameSize = strlen(sep);
    }
    else 
        basenameSize = strlen(path);
    
    if ( !(basename = (char*)malloc((basenameSize + 1) * sizeof(char))) ) {
        fprintf(stderr, "\033[31;1m Erreur rencontré lors de l'allocation mémoire du basename dans CIMP_file \033[0m \n");

        return NULL;
    }


    memset(basename, '\0', (basenameSize + 1));
    strncpy(basename, (( sep )? sep : path), basenameSize);
        
    return basename;
}


// Vérifie si le chemin existe
int CIMP_PathExists (char* path) {
    DIR* dir = NULL;
    char* dirname = NULL;
    int boolean = 0;


    if ( !(dirname = CIMP_GetDirname(path)) )
        return 0;

    if ( (dir = opendir(dirname)) ) {
        closedir(dir);
        boolean = 1;
    }
    else
        boolean = 0;


    free(dirname);
    dirname = NULL;

    return boolean;
}