/**
 * \file        CIMP_chainedlist.c
 * \author      C.Cedric
 * \version     1.0
 * \date        Avril 2019
 * \brief       Module d'une liste chainée générique.
 *
 * \details    Ce module permet la gestion d'une liste chainée générique.
 */

#include "CIMP_chainedlist.h"

/*!
*   \typedef CIMP_HeaderElement
*   \brief Objet en-tête de liste chainée.
*/
typedef struct CIMP_HeaderElement CIMP_HeaderElement;

/*!
*   \struct CIMP_HeaderElement
*   \brief Objet en-tête de liste chainée.
* 
*   CIMP_HeaderElement correspond à l'en-tête d'une liste chainée.
*   L'en-tête d'une liste chainée permet d'obtenir certaines informations
*   sur la liste chainée rapidement.
*   L'en-tête contient la taille d'un élément
*   ainsi que la longueur de la liste chainée. 
*/
struct CIMP_ChainedList {
    void *el; /*!< Le pointeur vers l'élément de type inconnu */
    CIMP_ChainedList *next; /*!< Le pointeur vers la prochaine cellule */
};

/*!
*   \struct CIMP_ChainedList
*   \brief La liste chainée.
* 
*   CIMP_ChainedList correspond à une liste chainée.
*   La liste chainée permet de stocker n'importe quel élément.
*   Une condition minimal est que chaque élément soit de la même taille.
*   Elle contient un élément et un pointeur vers le prochain élément. 
*/
struct CIMP_HeaderElement {
    size_t sizeOfEl; /*!< Taille d'un élément de la liste chainée */
    size_t length; /*!< Longueur de la liste chainée */
};


// Crée une liste chainée avec l'en-tête en première cellule
int CIMP_CreateChainedList(CIMP_ChainedList** l, size_t sizeOfEl) {
    *l = NULL;


    if ( !(*l = (CIMP_ChainedList*)malloc(sizeof(CIMP_ChainedList))) ) {
        fprintf(stderr, "Erreur rencontré lors de l'allocation mémoire de CIMP_ChainedList \n");
        
        return -1;
    }


    (*l)->next = NULL;
    (*l)->el = NULL;


    if ( !((*l)->el = (CIMP_HeaderElement*)malloc(sizeof(CIMP_HeaderElement))) ) {
        fprintf(stderr, "Erreur rencontré lors de l'allocation mémoire de CIMP_HeaderElement \n");
        
        free(*l);
        *l = NULL;

        return -1;
    }


    ((CIMP_HeaderElement*)(*l)->el)->sizeOfEl = sizeOfEl;
    ((CIMP_HeaderElement*)(*l)->el)->length = 0;

    return 0;
}


// Retourne le premier élément de la liste chainée
void* CIMP_PopElement(CIMP_ChainedList* l) {
    CIMP_ChainedList* next = NULL;
    void* el = NULL; 
    

    if ( !(el = CIMP_GetFirstElement(l)) )
        return NULL;

    next = (l->next)->next;
    free(l->next);
    l->next = next;

    ((CIMP_HeaderElement*)(l)->el)->length -= 1;

    return el;
}


// Retourne le premier élément de la liste chainée
void* CIMP_GetFirstElement(const CIMP_ChainedList* l) {
    if ( !((CIMP_HeaderElement*)l->el)->length ) {
        fprintf(stderr, "Erreur: Liste vide \n");

        return NULL;
    }

    return (l->next)->el;
}


// Retourne un élément de la liste chainée
void* CIMP_GetElement(const CIMP_ChainedList* l, size_t pos) {
    if ( pos >= ((CIMP_HeaderElement*)l->el)->length ) {
        fprintf(stderr, "Erreur: Position %lu de la liste chainée incorrect  \n", pos);
        
        return NULL;
    }


    CIMP_ChainedList* currentCell = l->next;

    for (size_t i = 0; i < pos; i++) {
        currentCell = currentCell->next;
    }

    return currentCell->el;
}


// Retourne la taille de la liste (sans compter l'en-tête)
size_t CIMP_ChainedListSize(CIMP_ChainedList* l) {
    return ((CIMP_HeaderElement*)l->el)->length;
}


// Ajoute un élément au début de la liste chainée
int CIMP_AddElement(CIMP_ChainedList* l, void* el, size_t sizeOfEl) {
    size_t elementSize = ((CIMP_HeaderElement*)l->el)->sizeOfEl;


    if ( sizeOfEl != elementSize ) {
        fprintf(stderr, "Erreur: Donnée incompatible avec la liste chainée \n");

        return -1;
    }


    CIMP_ChainedList* oldCell = l->next;
    CIMP_ChainedList* newCell = NULL;


    if ( !(newCell = (CIMP_ChainedList*)malloc(sizeof(CIMP_ChainedList))) ) {
        fprintf(stderr, "Erreur rencontré lors de l'allocation mémoire de la cellule suivante \n");
        
        return -1;
    }


    newCell->el = el;
    newCell->next = oldCell;

    l->next = newCell;

    ((CIMP_HeaderElement*)l->el)->length += 1;

    return 0;
}


// Retire le premier élément de la liste chainée
int CIMP_RemoveFirstElement(CIMP_ChainedList* l, DestroyFunc destroyFunc) {
    if ( !((CIMP_HeaderElement*)l->el)->length ) {
        fprintf(stderr, "Erreur: Liste vide \n");

        return -1;
    }

    CIMP_ChainedList* tmp = NULL;

    tmp = (l->next)->next;
    destroyFunc( &(l->next)->el );
    free(l->next);
    l->next = tmp;

    ((CIMP_HeaderElement*)l->el)->length -= 1;

    return 0;
}


// Retire un élément de la liste chainée
int CIMP_RemoveElement(CIMP_ChainedList* l, size_t pos, DestroyFunc destroyFunc) {
    if ( pos >= ((CIMP_HeaderElement*)l->el)->length ) {
        fprintf(stderr, "Erreur: Position %lu de la liste chainée incorrect  \n", pos);
        
        return -1;
    }

    CIMP_ChainedList* currentCell = l;
    CIMP_ChainedList* tmp = NULL;

    for (size_t i = 0; i < pos; i++) {
        currentCell = currentCell->next;
    }

    tmp = (currentCell->next)->next;
    destroyFunc( &(currentCell->next)->el );
    free(currentCell->next);
    currentCell->next = tmp;

    ((CIMP_HeaderElement*)l->el)->length -= 1;

    return 0;
}


// Libère la mémoire occupé par la liste chainée
void CIMP_DestroyChainedList(CIMP_ChainedList** l, DestroyFunc destroyFunc) {
    CIMP_ChainedList* nextCell = NULL;
    CIMP_ChainedList* tmpCell = NULL;
    size_t length = CIMP_ChainedListSize(*l);
    

    // Pointe vers la cellule suivante
    nextCell = (*l)->next;

    // Libération de la mémoire de l'en-tête
    ((CIMP_HeaderElement*)(*l)->el)->length = 0;
    ((CIMP_HeaderElement*)(*l)->el)->sizeOfEl = 0;
    free((*l)->el);
    (*l)->el = NULL;
    // Fin libération de la mémoire de l'en-tête


    for (size_t i = 0; i < length; i++) {
        // Libération de la mémoire du contenu de la première cellule de la chaine
        destroyFunc(&(nextCell)->el); //

        tmpCell = nextCell;
        nextCell = nextCell->next; //

        free(tmpCell); //
        tmpCell = NULL; //
    }

    // Libération de la mémoire de la cellule contenant l'en-tête
    free(*l);//
    *l = NULL;
    // FIn libération de la mémoire de la cellule contenant l'en-tête
}