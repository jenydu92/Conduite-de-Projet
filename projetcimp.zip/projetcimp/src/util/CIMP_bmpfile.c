/**
 * \file        CIMP_bmpfile.c
 * \author      C.Cedric
 * \version     1.0
 * \date        Avril 2019
 * \brief       Définit le gestionnaire de fichier bmp.
 *
 * \details     Ce module permet de traiter les fichiers bmp.
 */

#include "CIMP_bmpfile.h"

// Enregistrement au format BMP
int CIMP_SaveBMP (SDL_Surface* surface, char* path) {
    return SDL_SaveBMP(surface, path);
}