/**
 * \file        CIMP_savefile.c
 * \author      C.Cedric
 * \version     1.0
 * \date        Avril 2019
 * \brief       Définit la sauvegarde de fichier.
 *
 * \details     Ce module permet de contrôler le format d'enregistrement demandé et de redirigé vers le module adéquat.
 */

#include "CIMP_savefile.h"


/*!
*   \fn static int CIMP_IsValidExt (char* path)
*   \brief Fonction vérifiant si le format d'enregistrement demandé est valide.
* 
*   \param path Le chemin d'enregistrement.
*
*   \return le code correspondant au format si valide, sinon 0.
*/
static int CIMP_IsValidExt (char*);


// Vérifie si le format d'enregistrement demandé est valide
static int CIMP_IsValidExt (char* path) {
    char* tmpExt = NULL;
    char* ext = NULL;
    int code = 0;

    if ( !(tmpExt = CIMP_GetExt(path)) )
        return 0;

    if ( !(ext = (char*)malloc((strlen(tmpExt) + 1) * sizeof(char))) ) {
        fprintf(stderr, "\033[31;1m Erreur rencontré lors de l'allocation mémoire de l'extention dans CIMP_savefile \033[0m \n");

        return 0;
    }

    memset(ext, '\0', (strlen(tmpExt) + 1));
    strcpy(ext, tmpExt);
    stringToLowerCase(ext+1);

    if ( strcmp(".bmp", ext) == 0 )
        code =  1;
    else if ( strcmp(".png", ext) == 0 )
        code = 2;
    else
        code = 0;

    free(ext);
    ext = NULL;

    return code;
}

// Sélectionne le module de traitement adéquat
int CIMP_SaveFile (char* path, SDL_Surface* surface) {
    char* dirname = NULL;
    char* basename = NULL;
    int code = 0;


    if ( !(dirname = CIMP_GetDirname(path)) )
        return -1;

    if ( !(basename = CIMP_GetBasename(path)) ) {
        free(dirname);
        dirname = NULL;

        return -2;
    }


    switch ( CIMP_IsValidExt(basename) ) { 
        case 1 : // #BMP
            if ( CIMP_SaveBMP(surface, path) < 0 )
                code = -4;
        break;
        case 2 : // #PNG
            if ( CIMP_SavePNG(surface, path, basename) < 0 )
                code = -4;
        break;
        default: // #Non valide
            code = -3;
    }


    free(dirname);
    dirname = NULL;
    free(basename);
    basename = NULL;

    return code;
}