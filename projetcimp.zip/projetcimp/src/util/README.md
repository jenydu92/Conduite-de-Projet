## Librairie utilitaire


### CIMP_graphicconfig.h

```C
#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>

/* Donne les dimensions de l'écran w et h
 * en remplissant les paramètres envoyé
 * dans ce même ordre
 */
int CIMP_GetDesktopResolution(int*, int*);
```

### CIMP_chainedlist.h

```C
#include <stdlib.h>
#include <stdio.h>

// Liste chainée
typedef struct CIMP_ChainedList CIMP_ChainedList;

// Crée une liste chainée avec l'en-tête en première cellule
int CIMP_CreateChainedList(CIMP_ChainedList**, size_t);
// Pop le premier élément de la liste chainée
void* CIMP_PopElement(CIMP_ChainedList*);
// Retourne le premier élément de la liste chainée
void* CIMP_GetFirstElement(const CIMP_ChainedList*);
// Retourne un élément de la liste chainée
void* CIMP_GetElement(const CIMP_ChainedList*, size_t);
// Retourne la taille de la liste (sans compter l'en-tête)
size_t CIMP_ChainedListSize(CIMP_ChainedList*);
// Ajoute un élément au début de la liste chainée
int CIMP_AddElement(CIMP_ChainedList*, void*, size_t);
// Retire le premier élément de la liste chainée
int CIMP_RemoveFirstElement(CIMP_ChainedList*, void(void**));
// Retire un élément de la liste chainée
int CIMP_RemoveElement(CIMP_ChainedList*, size_t, void(void**));
// Libère la mémoire occupé par la liste chainée
void CIMP_DestroyChainedList(CIMP_ChainedList**, void(void**));
```