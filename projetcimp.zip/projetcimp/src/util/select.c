/**
 * \file        select.c
 * \author      P.Nelly
 * \version     1.0
 * \date        Avril 2019
 * \brief       Module de selection.
 *
 * \details    Ce module permet la gestion d'une selection.
 */

#include "selection.h"


/*!
*   \struct Pixels_Select
*   \brief Objet selection de pixels.
*
*   Pixels_Select correspond à une selection de pixels.
*   Elle contient le tableau de pixels selectionné,
*   la largeur de l'image original et son nombre pixels.
*/
struct Pixels_Select{
  Uint32 *pixels; /*!< Le tableau de pixels */
  int width; /*!< La largeur de la selection */
  int size; /*!< Le nombre de pixels */

};

//creation d'un tableau de selection vide selon une image donnee
Pixels_Select* create_selec(int size, int width){
  Pixels_Select* p;
  p=malloc(sizeof(struct Pixels_Select));
  p->pixels=malloc(sizeof(Uint32)*size);
  p->width=width;
  p->size=size;

  int i;

  //on initialise a 0 les pixels non selectionnes
  for(i=0;i<size;i++){
    p->pixels[i]=0;
  }

  return p;
}

//On recupère la selection d'une image et met a 1 les pixels selectionnés
int selection(int x1, int y1, int x2, int y2, Pixels_Select* select, int val){

  if (val!=0 && val!=1){
    perror("mauvaise valeur de selection");
    return 0;
  }

int ymin;
int ymax;
int xmin;
int xmax;

  if(y1<y2){
    ymin=y1;
    ymax=y2;
  }else{
    ymin=y2;
    ymax=y1;
  }

  if(x1<x2){
    xmin=x1;
    xmax=x2;
  }else{
    xmin=x2;
    xmax=x1;
  }

  for(int i = ymin; i < ymax; i++){

    for(int j = xmin; j < xmax; j++){
        select->pixels[i * select->width + j] = val;
    }
  }

  return 1;
}

void clear_selection(Pixels_Select* select){

  // for(int i = 0; i <sizeof(select->pixels)/sizeof(select->pixels[0]) ; i++){
  //   select->pixels[i] = 0;
  // }
  for(int i = 0; i < select->size; i++) {
    select->pixels[i]=0;
  }

}


//Libération de la mémoire de l'objet Pixels_Select
void destroySelec(Pixels_Select** select){
  if ( (*select)->pixels ) {
    free((*select)->pixels);
    (*select)->pixels = NULL;
  }
  if ( *select ) {
    free(*select);
    *select = NULL;
  }
}


/*int main(){
  Pixels_Select* p=create_selec(100,40);
  selection(2,4,5,8,p,10,1);


  int j;
  for(j=0; j<p->size; j++){
    printf("%u ",p->pixels[j]);
  }

}*/
