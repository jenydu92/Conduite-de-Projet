/**
 * \file        CIMP_bmpfile.h
 * \author      C.Cedric
 * \version     1.0
 * \date        Avril 2019
 * \brief       Définit l'interface du gestionnaire de fichier bmp.
 *
 * \details     Ce module permet de traiter les fichiers bmp.
 */

#ifndef _CIMP_BMPFILE_H_
#define _CIMP_BMPFILE_H_
    
#include <SDL2/SDL.h>

/*!
*   \fn int CIMP_SaveBMP (SDL_Surface* surface, char* path)
*   \brief Fonction enregistrant le fichier au format BMP.
* 
*   \param path Le chemin d'enregistrement.
*   \param surface La surface correspondant à l'image.
*
*   \return 0 si pas d'erreur, sinon un entier négatif.
*/
int CIMP_SaveBMP ( SDL_Surface*, char*);

#endif