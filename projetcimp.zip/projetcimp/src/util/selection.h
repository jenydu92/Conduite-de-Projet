/**
 * \file        select.c
 * \author      P.Nelly
 * \version     1.0
 * \date        Avril 2019
 * \brief       Définit l'interface de selection.
 *
 * \details    Ce module permet la gestion d'une selection.
 */

#ifndef _SELECT_H_
#define _SELECT_H_


#include <SDL2/SDL.h>
#include <errno.h>

/*!
*   \typedef Pixels_Select
*   \brief Objet selection de pixels.
*/
typedef struct Pixels_Select Pixels_Select;

/*!
*   \fn Pixels_Select* create_selec(int size, int width)
*   \brief Fonction Initialisant une selection.
*
*   \param size Le nombre de pixels dans la sélection.
*   \param width La largeur de la sélection.
*
*   \return Pixels_Select*
*
*   Creer un tableau de Uint32 representant
*   les pixels de la surface envoyer en arguments,
*   initialise a 0 pour signifier qu'ils ne sont pas selectionne.
*/
Pixels_Select* create_selec(int,int);

/*!
*   \fn void selection(int x1, int y1, int x2, int y2, Pixels_Select* select, int width, int val)
*   \brief Fonction permettant de modifier la sélection.
*
*   \param x1 La postion sur l'axe des abscisses du point supérieur gauche.
*   \param y1 La position sur l'axe des ordonnées du  point supérieur gauche.
*   \param x2 La postion sur l'axe des abscisses du point inférieur droite.
*   \param y2 La position sur l'axe des ordonnées du point inférieur droite.
*   \param select Le pointeur vers la sélection.
*   \param val Si val vaut 1, désigne une sélection, si val vaut 0, désigne une désélection.
*
*   Permet de modifier la selection en fonction
*   de x1 x2 y1 y2 et de val qui definie
*   si c'est une selection ou deselection
*/
int selection(int, int, int , int, Pixels_Select*,int );

/*!
*   \fn void clear_selection(Pixels_Select* select)
*   \brief Fonction réinitialisant la sélection à 0.
*
*   \param select La sélection à réinitialiser.
*/
void clear_selection(Pixels_Select*);

//Libération de la mémoire de l'objet Pixels_Select
/*!
*   \fn void destroySelec(Pixels_Select** select)
*   \brief Fonction libérant la mémoire occupé par l'objet Pixels_Select.
*
*   \param select L'adresse du pointeur de sélection.
*/
void destroySelec(Pixels_Select**);

#endif
