/*! \mainpage Documentation de CIMP
 *
 * \section intro_sec Introduction
 *
 * Dans le cadre de ce projet, la documentation a été généré de manière à tout montrer.
 *
 * \section install_sec Installation
 *
 * \subsection libs_subsec Librairie nécéssaire
 * - SDL version 2.0 ou plus récent <small><a href="https://www.libsdl.org/download-2.0.php">Librairie SDL2</a></small>
 * - SDL Image version 2.0 ou plus récent <small><a href="https://www.libsdl.org/projects/SDL_image/">Librairie SDL2 Image</a></small>
 * - SDL2_gfx version 1.0.4 ou plus récent <small><a href="http://www.ferzkopp.net/wordpress/2016/01/02/sdl_gfx-sdl2_gfx/">Librairie SDL2_gfx</a></small>
 * - Libpng 1.6 ou plus récent <small><a href="http://www.libpng.org/pub/png/libpng.html">Librairie libpng</a></small>
 *
 * \subsection launch Lancer le programme
 * - Dans une console, placez-vous dans le repertoire /src puis saisissez : <br />
 * make
 * - Puis pour lancer le programme CIMP : <br />
 * ./cimp
 */

#include "./commande/process_command.h"


int main(int argc, char* argv[]){
	return deroulement(argc, argv);
}



