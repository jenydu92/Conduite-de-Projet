#include "symetrie.h"

void symetrieHorizontale(SDL_Surface* surface){
  Uint32* pixels= surface->pixels;
  Uint32 tmp =0;
  int i=0;
  int j=0;

    for(i = 0; i < surface->h/2; i++)
  {
      for(j = 0; j < surface->w; j++){
        //modification direct du tableau de pixel de la surface
        tmp=pixels[i * surface->w + j];
        pixels[i * surface->w + j]=pixels[(surface->h-i-1) * surface->w + j];
        pixels[(surface->h-i-1) * surface->w + j]=tmp;
      }
  }
}

void symetrieVerticale(SDL_Surface* surface){
  Uint32* pixels= surface->pixels;
  Uint32 tmp =0;
  int i=0;
  int j=0;

  for(i = 0; i < (surface->h); i++)
  {
      for(j = 0; j < (surface->w)/2; j++){
        //modification direct du tableau de pixel de la surface
        tmp=pixels[i * surface->w + j];
        pixels[i * surface->w + j]=pixels[i * surface->w +(surface->w-1-j)];
        pixels[i * surface->w + (surface->w-1-j)]=tmp;
      }
  }
}
