#ifndef _SYMETRIE_H_
#define _SYMETRIE_H_

#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>

void symetrieHorizontale(SDL_Surface*);

void symetrieVerticale(SDL_Surface*);

#endif
