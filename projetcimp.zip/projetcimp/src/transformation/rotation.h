#ifndef _ROTATION_H_
#define _ROTATION_H_

#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <SDL2/SDL2_rotozoom.h>

void rotation(SDL_Surface*);

#endif
