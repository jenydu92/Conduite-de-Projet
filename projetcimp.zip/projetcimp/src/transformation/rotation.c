#include "rotation.h"
#include <SDL2/SDL2_rotozoom.h>

//pour la rotation nous avons besoin de SDL2_gfx
void rotation(SDL_Surface* surface){
    //angle en degres
    double angle = 90;

    surface= rotozoomSurface(surface, angle, 1.0, 1);
}
