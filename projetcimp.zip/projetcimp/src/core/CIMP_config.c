/**
 * \file        CIMP_config.c
 * \author      C.Cedric
 * \version     1.0
 * \date        Avril 2019
 * \brief       Module de configuration du programme.
 *
 * \details     Ce module permet de configurer le programme.
 */

#include "CIMP_config.h"


int CIMP_initConfig(CIMP_Config** config, CIMP_ThreadCLI threadFunc) {
    *config = NULL;


    if ( !(*config = (CIMP_Config*)malloc(sizeof(CIMP_Config))) ) {
        fprintf(stderr, "\033[31;1m Erreur rencontré lors de l'allocation mémoire de CIMP_Config \033[0m \n");
        
        return 0;
    }


    (*config)->command = NULL;
    (*config)->workspace = NULL;

    if (SDL_Init(SDL_INIT_VIDEO) != 0) {
        fprintf(stderr, "\033[31;1m Echec de l'initialisation de SDL (%s) \033[0m \n", SDL_GetError());
        
        return 0;
    }

    int flags=IMG_INIT_JPG|IMG_INIT_PNG;
    int initted=IMG_Init(flags);

    if((initted&flags) != flags) {
        fprintf(stderr, "\033[31;1m IMG_Init: Echec de l'initialisation de SDL_IMG.  Nécessite le support du format jpg et png. \033[0m \n");
        fprintf(stderr, "\033[31;1m IMG_Init: %s \033[0m \n", IMG_GetError());
    }

    (*config)->thread_cli = NULL;
    SDL_EventState(SDL_MOUSEMOTION, SDL_DISABLE);

    if ( initCommand(&(*config)->command) < 0 ) {
        fprintf(stderr, "\033[31;1m Erreur lors de l'initialisation de l'interface textuel \033[0m \n");

        return 0;
    }

    if ( CIMP_InitWorkspace(&(*config)->workspace) < 0 ) {
        destroyCommand(&(*config)->command);
        SDL_Quit();
        fprintf(stderr, "\033[31;1m Erreur lors de l'initialisation de l'espace de travail \033[0m \n");

        return 0;
    }

    (*config)->thread_cli = SDL_CreateThread( threadFunc, "User Input", &(*config)->command );


    if ( !(*config)->thread_cli ) {
        printf("\033[31;1m Erreur rencontré lors de la création du thread: %s \033[0m \n", SDL_GetError());
        
        destroyCommand(&(*config)->command);
        CIMP_DestroyWorkspace(&(*config)->workspace);

        return 0;
    }

    return 1;
}


void CIMP_destroyConfig(CIMP_Config** config) {
    if ( (*config)->command ) {
        destroyCommand(&(*config)->command);
        (*config)->command = NULL;  
    }
    if ( (*config)->workspace ) {
        CIMP_DestroyWorkspace(&(*config)->workspace);
        (*config)->workspace = NULL;
    }
    if ( (*config)->thread_cli )    
        (*config)->thread_cli = NULL;
    if ( *config ) {
        free(*config);
        *config = NULL;
    }

    IMG_Quit();
    SDL_Quit();
}