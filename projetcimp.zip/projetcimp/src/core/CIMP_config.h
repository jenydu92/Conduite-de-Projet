/**
 * \file        CIMP_config.h
 * \author      C.Cedric
 * \version     1.0
 * \date        Avril 2019
 * \brief       Définit l'interface de configuration du programme.
 *
 * \details     Ce module permet de configurer le programme.
 */

#ifndef _CIMP_CONFIG_H_
#define _CIMP_CONFIG_H_

#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include "../graphics/CIMP_workspace.h"
#include "../commande/check_command.h"

/*!
*   \typedef CIMP_ThreadCLI
*   \brief La fonction de pour le thread de l'interface en ligne de commande.
*/
typedef int (*CIMP_ThreadCLI)(void*);

/*!
*   \typedef CIMP_Config
*   \brief La définition de l'objet CIMP_Config.
*/
typedef struct CIMP_Config CIMP_Config;

/*!
*   \struct CIMP_Config
*   \brief Objet configuration.
* 
*   CIMP_Config correspond à la configuration du programme.
*   La configuration du programme contient une structure correspondant à une commande,
*   l'espace de travaille, les évènements de type SDL_Event et le thread gérant l'interface
*   en ligne de commande de type SDL_Thread. 
*/
struct CIMP_Config {
    Command* command; /*!< La structure de commande */
    CIMP_Workspace* workspace; /*!< L'espace de travaille */
    SDL_Event ev; /*!< Les évènements */
    SDL_Thread* thread_cli; /*!< Le thread de l'interface en ligne de commande */
};


/*!
*   \fn CIMP_initConfig(CIMP_Config** config, CIMP_ThreadCLI threadFunc)
*   \brief Fonction d'initialisation de la configuration.
* 
*   \param config L'adresse du pointeur vers la configuration.
*   \param threadFunc La fonction qui sera utilisé dans le thread de l'interface en ligne de commande.
*
*   \return 1 si aucune erreur, sinon 0.
*/
int CIMP_initConfig(CIMP_Config**, CIMP_ThreadCLI);

/*!
*   \fn void CIMP_destroyConfig(CIMP_Config** config)
*   \brief Fonction libérant la mémoire occupé par la configuration du programme.
* 
*   \param config L'adresse du pointeur vers la configuration.
*/
void CIMP_destroyConfig(CIMP_Config**);

#endif