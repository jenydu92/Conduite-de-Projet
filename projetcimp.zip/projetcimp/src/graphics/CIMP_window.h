/**
 * \file        CIMP_window.h
 * \author      C.Cedric
 * \version     1.0
 * \date        Avril 2019
 * \brief       Définit l'interface d'une fenêtre de CIMP.
 *
 * \details    Ce module permet la gestion d'une fenêtre spécifique à CIMP.
 */

#ifndef _CIMP_WINDOW_H_
#define _CIMP_WINDOW_H_
    
#include <SDL2/SDL.h>

/*!
*   \typedef CIMP_Window
*   \brief Objet fenêtre.
*/
typedef struct CIMP_Window CIMP_Window; 


/*!
*   \fn int CIMP_CreateWindow (CIMP_Window** window)
*   \brief Fonction créant une nouvelle fenêtre.
* 
*   \param window L'adresse du pointeur vers la fenêtre.
*
*   \return 0 si pas d'erreur, sinon un entier négatif.
*/
int CIMP_CreateWindow(CIMP_Window**);

/*!
*   \fn SDL_Window* CIMP_GetWindowWindow(CIMP_Window* window)
*   \brief Fonction retournant la SDL_Window* de la fenêtre.
* 
*   \param window Le pointeur vers la fenêtre.
*
*   \return SDL_Window*.
*/
SDL_Window* CIMP_GetWindowWindow(CIMP_Window*);

/*!
*   \fn Uint32 CIMP_GetWindowId(CIMP_Window* window)
*   \brief Fonction retournant l'identifiant de la fenêtre.
* 
*   \param window Le pointeur vers la fenêtre.
*
*   \return Uint32.
*/
Uint32 CIMP_GetWindowId(CIMP_Window*);

/*!
*   \fn const char* CIMP_GetWindowTitle(CIMP_Window* window)
*   \brief Fonction retournant le titre de la fenêtre.
* 
*   \param window Le pointeur vers la fenêtre.
*
*   \return char*.
*/
const char* CIMP_GetWindowTitle(CIMP_Window*);

/*!
*   \fn int CIMP_SetWindowTexture(CIMP_Window** window, SDL_Surface* surface)
*   \brief Fonction modifiant la texture appliqué à la fenêtre.
* 
*   \param window L'adresse du pointeur vers la fenêtre.
*   \param surface La SDL_Surface* qui mettra à jour la texture.
*
*   \return 0 si pas d'erreur, sinon un entier négatif.
*
*   Si la dernier paramètre est NULL, alors la texture est assigné à NULL.
*/
int CIMP_SetWindowTexture(CIMP_Window**, SDL_Surface*);

/*!
*   \fn void CIMP_SetWindowTitle (CIMP_Window* window, const char* name, size_t nameSize)
*   \brief Fonction modifiant le titre de la fenêtre.
* 
*   \param window Le pointeur vers la fenêtre.
*   \param name Le nouveau nom de la fenêtre.
*   \param nameSize Le poids de la chaine de caractère.
*
*   Si nameSize vaut 0 ou name vaut NULL, alors seul l'identifiant
*   de la fenêtre sera affiché dans le titre.
*/
void CIMP_SetWindowTitle(CIMP_Window*, const char*, size_t);

/*!
*   \fn void CIMP_SetWindowSize (CIMP_Window *window, int new_size_w, int new_size_h)
*   \brief Fonction redimensionnant la fenêtre.
* 
*   \param window Le pointeur vers la fenêtre.
*   \param new_size_w La largeur de la fenêtre.
*   \param new_size_h La heuteur de la fenêtre.
*/
void CIMP_SetWindowSize(CIMP_Window*, int, int);

/*!
*   \fn void CIMP_SetWindowPosition (CIMP_Window* window, int x, int y)
*   \brief Fonction modifiant la position de la fenêtre.
* 
*   \param window Le pointeur vers la fenêtre.
*   \param x La position sur l'axe des abscisses.
*   \param y La position sur l'axe des ordonnées.
*/
void CIMP_SetWindowPosition (CIMP_Window*, int, int);

/*!
*   \fn void CIMP_WindowMoveView (CIMP_Window* window, size_t x, size_t y)
*   \brief Fonction modifiant la position de la fenêtre.
* 
*   \param window Le pointeur vers la fenêtre.
*   \param x La position de la vue sur l'axe des abscisses.
*   \param y La position de la vue sur l'axe des ordonnées.
*/
void CIMP_WindowMoveView (CIMP_Window*, size_t , size_t);

/*!
*   \fn void CIMP_WindowIncrementalMoveView (CIMP_Window* window, int x, int y)
*   \brief Fonction déplacant la vue à la position initial plus x et y.
* 
*   \param window Le pointeur vers la fenêtre.
*   \param x L'incrémentation en x.
*   \param y L'incrémentation en y.
*/
void CIMP_WindowIncrementalMoveView (CIMP_Window*, int, int);

/*!
*   \fn int CIMP_RepaintWindow (CIMP_Window **window)
*   \brief Fonction Actualisant la fenêtre.
* 
*   \param window L'adresse du pointeur vers la fenêtre.
*
*   \return 0 si pas d'erreur, sinon un entier négatif.
*/
int CIMP_RepaintWindow(CIMP_Window**);

/*!
*   \fn void CIMP_HideWindow(CIMP_Window* window)
*   \brief Fonction cachant la fenêtre.
* 
*   \param window Le pointeur vers la fenêtre.
*/
void CIMP_HideWindow(CIMP_Window*);

/*!
*   \fn void CIMP_ShowWindow(CIMP_Window* window)
*   \brief Fonction affichant la fenêtre.
* 
*   \param window La fenêtre.
*/
void CIMP_ShowWindow(CIMP_Window*);

/*!
*   \fn void CIMP_DestroyWindow (CIMP_Window** window)
*   \brief Fonction libérant la mémoire occupé par la fenêtre.
* 
*   \param window L'adresse du pointeur vers la fenêtre.
*/
void CIMP_DestroyWindow(CIMP_Window**);

#endif