/**
 * \file        CIMP_workspace.c
 * \author      C.Cedric
 * \version     1.0
 * \date        Avril 2019
 * \brief       Définit un espace de travail.
 *
 * \details    Ce module permet de gérer toutes les images et toutes les fenêtres.
 */

#include "CIMP_workspace.h"


/*!
*   \fn static CIMP_PictureCell* CIMP_SelectPictureCell (CIMP_Workspace* workspace, size_t pictureId, size_t* pos)
*   \brief Fonction permettant de récupérer une cellule image et la position dans la liste.
* 
*   \param workspace L'adresse du pointeur vers l'espace de travail.
*   \param pictureId L'identifiant de l'image.
*   \param pos L'adresse vers la variable qui contiendra la position.
*
*   \return CIMP_PictureCell* si aucune erreur, sinon NULL.
*
*   Cette fonction permet de récupérer la cellule image ainsi que sa position
*   dans la liste chainée à partir de son identifiant.
*   Le dernier paramètre permet de récupérer la position dans la liste chainée.
*   Si l'image n'existe pas, pos vaut -1.
*   Le dernier paramètre peut être NULL.
*/
static CIMP_PictureCell* CIMP_SelectPictureCell (CIMP_Workspace*, size_t, size_t*);


/*!
*   \fn static CIMP_WindowCell* CIMP_SelectWindowCell(CIMP_Workspace* workspace, size_t windowId, size_t* pos)
*   \brief Permet de récupérer une cellule fenêtre et la position dans la liste.
* 
*   \param workspace L'adresse du pointeur vers l'espace de travail.
*   \param windowId L'identifiant de la fenêtre.
*   \param pos L'adresse vers la variable qui contiendra la position.
*
*   \return CIMP_WindowCell* si aucune erreur, sinon NULL.
*
*   Cette fonction permet de récupérer la cellule fenêtre ainsi que sa position
*   dans la liste chainée à partir de son identifiant.
*   Le dernier paramètre permet de récupérer la position dans la liste chainée.
*   Si la fenêtre n'existe pas, pos vaut -1.
*   Le dernier paramètre peut être NULL.
*/
static CIMP_WindowCell* CIMP_SelectWindowCell (CIMP_Workspace*, size_t, size_t*);


/*!
*   \fn static void CIMP_RemoveRefFromPicture(CIMP_Workspace* workspace, CIMP_PictureCell** pictureCell)
*   \brief Fonction permettant de supprimer les liens de l'image à sa fenêtre associé si ce lien existe.
* 
*   \param workspace L'adresse du pointeur vers l'espace de travail.
*   \param pictureCell L'adresse du pointeur vers la cellule image.
*
*   Une cellule image contient son image ainsi que la fenêtre associé.
*   Une cellule fenetre contient sa fenêtre ainsi que l'image associé.
*   Cette fonction permet de mettre à NULL la fenêtre de la cellule image
*   ainsi que l'image de la cellule fenêtre.
*   La fenêtre est mise à jour avec une texture NULL.
*/
static void CIMP_RemoveRefFromPicture (CIMP_Workspace*, CIMP_PictureCell**);


/*!
*   \fn static void CIMP_RemoveRefFromWindow(CIMP_Workspace* workspace, CIMP_WindowCell** windowCell)
*   \brief Fonction permettant de supprimer les liens de la fenêtre à son image associé si ce lien existe.
* 
*   \param workspace L'adresse du pointeur vers l'espace de travail.
*   \param windowCell L'adresse du pointeur vers La cellule fenêtre.
*
*   Une cellule fenetre contient sa fenêtre ainsi que l'image associé.
*   Une cellule image contient son image ainsi que la fenêtre associé.
*   Cette fonction permet de mettre à NULL l'image de la cellule fenêtre
*   ainsi que la fenêtre de la cellule image.
*   La fenêtre est mise à jour avec une texture NULL.
*/
static void CIMP_RemoveRefFromWindow (CIMP_Workspace*, CIMP_WindowCell**);


/*!
*   \fn static void CIMP_DestroyId(void** voidId)
*   \brief Fonction permettant de libérer la mémoire occupé par un identifiant.
* 
*   \param voidId L'adresse du pointeur vers l'identifiant à supprimer.
*/
static void CIMP_DestroyId (void**);


/*!
*   \struct CIMP_Workspace
*   \brief Objet espace de travail.
* 
*   CIMP_Workspace correspond à l'espace de travail.
*   L'espace de travail contient une liste chainée de cellule image
*   chargé par l'utilisateur, une liste chainée de cellule fenêtre
*   créé par l'utilisateur ainsi qu'une liste chainée contenant les 
*   identifiants des images récemment supprimé. 
*/
struct CIMP_Workspace {
    CIMP_ChainedList* pictureList; /*!< Liste chainée de cellule image */
    CIMP_ChainedList* windowList; /*!< Liste chainée de cellule fenêtre */

    CIMP_ChainedList* lastPictureId; /*!< Liste chainée des anciens identifiants d'image */
    SDL_Surface* clipboard; /*!< Cache temporaire pour une image copié/coupé */
};


// Permet de sélectionner une cellule de pictureList à partir
// de l'identifiant d'une image
static CIMP_PictureCell* CIMP_SelectPictureCell (CIMP_Workspace* workspace, size_t pictureId, size_t* pos) {    
    size_t listSize = CIMP_ChainedListSize(workspace->pictureList);


    if ( pos )   
        *pos = -1;
    

    CIMP_PictureCell* pictureCell = NULL;
    CIMP_PictureCell* tmp = NULL;

    for (size_t i = 0; i < listSize; i++) {
        tmp = CIMP_GetElement(workspace->pictureList, i);


        if ( CIMP_GetPictureId(CIMP_GetPictureCellPicture(tmp)) == pictureId ) {
            if ( pos )
                *pos = i;
            pictureCell = tmp;
            break;
        }

    }

    return pictureCell;
}


// Permet de sélectionner une cellule de windowList à partir
// de l'identifiant d'une fenêtre
static CIMP_WindowCell* CIMP_SelectWindowCell (CIMP_Workspace* workspace, size_t windowId,  size_t* pos) {
    size_t listSize = CIMP_ChainedListSize(workspace->windowList);

    if ( pos )
        *pos = -1;
    CIMP_WindowCell* windowCell = NULL;
    CIMP_WindowCell* tmp = NULL;

    for (size_t i = 0; i < listSize; i++) {
        tmp = CIMP_GetElement(workspace->windowList, i);


        if ( CIMP_GetWindowId(CIMP_GetWindowCellWindow(tmp)) == windowId ) {
            if ( pos )
                *pos = i;
            windowCell = tmp;
            break;
        }

    }

    return windowCell;
}


// Permet de supprimer les références mutuels fenêtre/image
// à partir d'une CIMP_PictureCell
static void CIMP_RemoveRefFromPicture (CIMP_Workspace* workspace, CIMP_PictureCell** pictureCell) {
    CIMP_WindowCell* windowCell = NULL;
    CIMP_Window* window = NULL;
    
    if ( !(window = CIMP_GetPictureCellWindow(*pictureCell)) )
        return;

    windowCell = CIMP_SelectWindowCell(workspace, CIMP_GetWindowId(window), 0);

    CIMP_WindowCellRemovePicture(&windowCell);
    CIMP_PictureCellRemoveWindow(pictureCell);
}


// Permet de supprimer les références mutuels fenêtre/image
// à partir d'une CIMP_WindowCell
static void CIMP_RemoveRefFromWindow (CIMP_Workspace* workspace, CIMP_WindowCell** windowCell) {
    CIMP_PictureCell* pictureCell = NULL;
    CIMP_Picture* picture = NULL;
    
    if ( !(picture = CIMP_GetWindowCellPicture(*windowCell)) )
        return;

    pictureCell = CIMP_SelectPictureCell(workspace, CIMP_GetPictureId(picture), 0);

    CIMP_PictureCellRemoveWindow(&pictureCell);
    CIMP_WindowCellRemovePicture(windowCell);
}




// Initialise la structure
int CIMP_InitWorkspace (CIMP_Workspace** workspace) {
    *workspace = NULL;


    if ( !(*workspace = (CIMP_Workspace*)malloc(sizeof(CIMP_Workspace))) ) {
        fprintf(stderr, "\033[31;1m Erreur rencontré lors de l'allocation mémoire de CIMP_Workspace \033[0m \n");
        
        return -1;
    }


    (*workspace)->pictureList = NULL;
    (*workspace)->windowList = NULL;
    (*workspace)->lastPictureId = NULL;
    (*workspace)->clipboard = NULL;


    if ( CIMP_CreateChainedList(&(*workspace)->pictureList, sizeof(CIMP_PictureCell*)) < 0 ) {
        free(*workspace);
        *workspace = NULL;

        return -2;
    }


    if ( CIMP_CreateChainedList(&(*workspace)->windowList, sizeof(CIMP_WindowCell*)) < 0 ) {
        CIMP_DestroyChainedList(&(*workspace)->pictureList, CIMP_DestroyPictureCell);

        free(*workspace);
        *workspace = NULL;

        return -3;
    }


    if ( CIMP_CreateChainedList(&(*workspace)->lastPictureId, sizeof(Uint32)) < 0 ) {
        CIMP_DestroyChainedList(&(*workspace)->pictureList, CIMP_DestroyPictureCell);
        CIMP_DestroyChainedList(&(*workspace)->windowList, CIMP_DestroyWindowCell);

        free(*workspace);
        *workspace = NULL;

        return -4;
    }


    return 0;
}




// Retourne le contenu du cache
SDL_Surface* CIMP_GetClipboard (CIMP_Workspace* workspace) {
    return workspace->clipboard;
}


// Retourne le contenu du cache
void CIMP_SetClipboard (CIMP_Workspace* workspace, SDL_Surface* surface) {
    if ( workspace->clipboard )
        SDL_FreeSurface(workspace->clipboard);
    workspace->clipboard = surface;
}


// Recherche et renvoie une image
CIMP_Picture* CIMP_GetPicture (CIMP_Workspace* workspace, size_t pictureId) {
    CIMP_PictureCell* pictureCell = NULL;    

    return ( pictureCell = CIMP_SelectPictureCell(workspace, pictureId, 0) )?
        CIMP_GetPictureCellPicture(pictureCell) : NULL;
}


// Recherche et renvoie une fenêtre
CIMP_Window* CIMP_GetWindow(CIMP_Workspace* workspace, size_t windowId) {
    CIMP_WindowCell* windowCell = NULL;

    return ( windowCell = CIMP_SelectWindowCell(workspace, windowId, 0) )?
        CIMP_GetWindowCellWindow(windowCell) : NULL;
}


// Retourne l'identifiant de la fenêtre associé à l'image
size_t CIMP_GetPictureAssocId(CIMP_Workspace* workspace, size_t pictureId) {
    CIMP_PictureCell* pictureCell = NULL;


    if ( !(pictureCell = CIMP_SelectPictureCell(workspace, pictureId, 0)) )
        return 0;


    if ( CIMP_PictureCellWindowExists(pictureCell) ) {
        size_t windowId = CIMP_GetWindowId(CIMP_GetPictureCellWindow(pictureCell));
        return windowId;
    }
    else {
        return 0;
    }
}


// Retourne l'identifiant de l'image associé à la fenêtre
size_t CIMP_GetWindowAssocId(CIMP_Workspace* workspace, size_t windowId) {
    CIMP_WindowCell* windowCell = NULL;


    if ( !(windowCell = CIMP_SelectWindowCell(workspace, windowId, 0)) )
        return 0;


    return ( CIMP_WindowCellPictureExists(windowCell) )?
        CIMP_GetPictureId(CIMP_GetWindowCellPicture(windowCell)) : 0;
}




// Charge une image
CIMP_PictureCell* CIMP_LoadPicture (CIMP_Workspace* workspace, char* path) {
    CIMP_PictureCell* pictureCell = NULL;

    static Uint32 counter = 1;
    Uint32 id;

    if ( !CIMP_ChainedListSize(workspace->lastPictureId) ) {
        id = counter;
        counter += 1;
    }
    else
        id = *(Uint32*)CIMP_PopElement(workspace->lastPictureId);


    if ( CIMP_CreatePictureCell(&pictureCell, path, id) < 0
        || CIMP_AddElement(workspace->pictureList, pictureCell, sizeof(CIMP_PictureCell*)) < 0 ) {
        counter -=1;
        
        return NULL;
    }


    return pictureCell;
}


// Sauvegarde une image
int CIMP_SavePicture(CIMP_Workspace* workspace, size_t pictureId, char* path) {
    CIMP_PictureCell* pictureCell = NULL;
    CIMP_Picture* picture = NULL;
    SDL_Surface* surface = NULL;


    if ( !( pictureCell = CIMP_SelectPictureCell(workspace, pictureId, NULL))
        || !( picture = CIMP_GetPictureCellPicture(pictureCell)) )
        return -1;

    if ( !(surface = CIMP_GetPictureSurface(picture)) )
        return -2;

    if ( !(CIMP_PathExists(path)) )
        return -3;

    switch ( CIMP_SaveFile(path, surface) ) {
        case -1 :
            return -4;
        case -2 :
            return -5;
        case -3 :
            return -6;
        case -4 :
            return -7;
    }


    return 0;
}


// Modifie l'image et met à jour la fenêtre associé
int CIMP_ModifyPicture (CIMP_Workspace* workspace, size_t pictureId, SDL_Surface* surface) {
    CIMP_PictureCell* pictureCell = NULL;
    CIMP_Picture* picture = NULL;


    if ( !( pictureCell = CIMP_SelectPictureCell(workspace, pictureId, NULL)) )
        return -1;

    if ( !( picture = CIMP_GetPictureCellPicture(pictureCell)) ) 
        return -1;


    CIMP_SetPictureSurface(picture, surface);

    if ( CIMP_PictureCellWindowExists(pictureCell) ) {
        CIMP_Window* window = CIMP_GetPictureCellWindow(pictureCell);
        CIMP_SetWindowTexture(&window, surface);
    }

    return 0;
}


// Supprime une image
int CIMP_RemovePicture (CIMP_Workspace* workspace, size_t pictureId) {
    CIMP_PictureCell* pictureCell = NULL;
    Uint32* id = NULL;
    size_t pos;


    if ( !(id = malloc(sizeof(Uint32))) ) {
        fprintf(stderr, "\033[31;1m Erreur rencontré lors de l'allocation mémoire de l'identifiant d'image dans la liste \033[0m \n");

        return -1;
    }


    if ( !(pictureCell = CIMP_SelectPictureCell(workspace, pictureId, &pos)) ) {
        fprintf(stderr, "\033[31;1m Erreur, l'identifiant de l'image est incorrect \033[0m \n");

        return -1;
    }


    if ( CIMP_PictureCellWindowExists(pictureCell) )
        CIMP_RemoveRefFromPicture(workspace, &pictureCell);

    *id = CIMP_GetPictureId(CIMP_GetPictureCellPicture(pictureCell));
    CIMP_RemoveElement(workspace->pictureList, pos, CIMP_DestroyPictureCell);


    if ( CIMP_AddElement(workspace->lastPictureId, id, sizeof(Uint32)) < 0 )
        return -3;


    return 0;
}


// Change le nom d'une image
int CIMP_RenamePicture (CIMP_Workspace* workspace, size_t pictureId, char* name) {
    CIMP_PictureCell* pictureCell = NULL;

    CIMP_Picture* picture = NULL;
    CIMP_Window* window = NULL;


    if ( !(pictureCell = CIMP_SelectPictureCell(workspace, pictureId, NULL)) )
        return -1;


    picture = CIMP_GetPictureCellPicture(pictureCell);


    if ( CIMP_SetPictureName(picture, name, strlen(name)) < 0 )
        return -1;
    

    if ( CIMP_PictureCellWindowExists(pictureCell) ) {
        window = CIMP_GetPictureCellWindow(pictureCell);
        CIMP_SetWindowTitle(window, name, strlen(name));
    }

    return 0;
}




// Affiche une image dans une fenêtre existante
int CIMP_DisplayPicture (CIMP_Workspace* workspace, size_t pictureId, size_t windowId) {
    CIMP_PictureCell* pictureCell = NULL;
    CIMP_WindowCell* windowCell = NULL;

    CIMP_Picture* picture = NULL;
    CIMP_Window* window = NULL;


    if ( !(pictureCell = CIMP_SelectPictureCell(workspace, pictureId, NULL)) )
        return -1;


    if ( windowId == 0 ) {
        windowCell = CIMP_OpenWindow(workspace);
    }
    else if( !(windowCell = CIMP_SelectWindowCell(workspace, windowId, 0)) ) {
        return -2;
    }

    // Si la fenetre affiche déjà une image
    if ( CIMP_WindowCellPictureExists(windowCell) ) {
        CIMP_RemoveRefFromWindow(workspace, &windowCell);
    }

    // Si l'image est déjà affiché dans une fenêtre
    if ( CIMP_PictureCellWindowExists(pictureCell) ) {
        CIMP_RemoveRefFromPicture(workspace, &pictureCell);
    }

    picture = CIMP_GetPictureCellPicture(pictureCell);
    window = CIMP_GetWindowCellWindow(windowCell);

    SDL_Surface* surface = CIMP_GetPictureSurface(picture);
    char* name = CIMP_GetPictureName(picture);
    int resolution_w, resolution_h;
    int window_w, window_h;
    int max_window_w, max_window_h;
    int surface_w, surface_h;

    // On cache la fenêtre le temps d'effectuer les opérations sur elle
    CIMP_HideWindow(window);

    if ( CIMP_SetWindowTexture(&window, surface) < 0 ) 
        return -3;

    CIMP_SetWindowTitle (window, name, strlen(name));

    CIMP_GetDesktopResolution(&resolution_w, &resolution_h);

    max_window_w = resolution_w / 1.2;
    max_window_h = resolution_h / 1.2;

    surface_w = surface->w;
    surface_h = surface->h;

    window_w = (surface_w > max_window_w)? max_window_w : surface_w;
    window_h = (surface_h > max_window_h)? max_window_h : surface_h;

    CIMP_SetWindowSize(window, window_w, window_h);
    CIMP_SetWindowPosition(window, SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED);

    CIMP_WindowCellAssignPicture(&windowCell, picture);
    CIMP_PictureCellAssignWindow(&pictureCell, window);

    // On réaffiche la fenêtre
    CIMP_ShowWindow(window);

    return 0;
}


// Cache l'image (similaire à CIMP_HideWindow)
int CIMP_MaskPicture (CIMP_Workspace* workspace, size_t pictureId) {
    CIMP_PictureCell* pictureCell = NULL;
    size_t pos;


    if ( !(pictureCell = CIMP_SelectPictureCell(workspace, pictureId, &pos)) )
        return -1;

    if ( CIMP_PictureCellWindowExists(pictureCell) ) {
        CIMP_Window* window = NULL;
        
        window = CIMP_GetPictureCellWindow(pictureCell);
        CIMP_HideWindow(window);
    }

    return 0;
}




// Ouvre une fenêtre
CIMP_WindowCell* CIMP_OpenWindow (CIMP_Workspace* workspace) {
    CIMP_WindowCell* windowCell = NULL;


    if (   CIMP_CreateWindowCell(&windowCell) < 0 
        || CIMP_AddElement(workspace->windowList, windowCell, sizeof(CIMP_WindowCell*)) < 0 )
        return NULL;
    
    return windowCell;
}


// Affiche la fenêtre
int CIMP_DisplayWindow (CIMP_Workspace* workspace, size_t windowId) {
    CIMP_WindowCell* windowCell = NULL;
    size_t pos;


    if ( !(windowCell = CIMP_SelectWindowCell(workspace, windowId, &pos)) )
        return -1;


    CIMP_Window* window = NULL;

    window = CIMP_GetWindowCellWindow(windowCell);
    CIMP_ShowWindow(window);

    return 0;
}


// Cache la fenêtre (similaire à CIMP_HidePicture)
int CIMP_MaskWindow (CIMP_Workspace* workspace, size_t windowId) {
    CIMP_WindowCell* windowCell = NULL;
    size_t pos;


    if ( !(windowCell = CIMP_SelectWindowCell(workspace, windowId, &pos)) )
        return -1;

    CIMP_Window* window = NULL;

    window = CIMP_GetWindowCellWindow(windowCell);
    CIMP_HideWindow(window);

    return 0;
}


// Supprime une fenêtre
int CIMP_RemoveWindow (CIMP_Workspace* workspace, size_t windowId) {
    CIMP_WindowCell* windowCell = NULL;
    size_t pos; 


    if ( !(windowCell = CIMP_SelectWindowCell(workspace, windowId, &pos)) )
        return -1;


    CIMP_RemoveRefFromWindow(workspace, &windowCell);

    CIMP_RemoveElement(workspace->windowList, pos, CIMP_DestroyWindowCell);


    return 0;
}


// Deplace la vue d'une fenêtre
int CIMP_MoveView (CIMP_Workspace* workspace, size_t windowId, size_t x, size_t y) {
    CIMP_Window* window = NULL;


    if ( !(window = CIMP_GetWindow(workspace, windowId)) )
        return -1;

    CIMP_WindowMoveView(window, x , y);

    return 0;
}


// Deplacement par incrémentation de la vue d'une fenêtre
int CIMP_IncrementalMoveView (CIMP_Workspace* workspace, size_t windowId, int x, int y) {
    CIMP_Window* window = NULL;


    if ( !(window = CIMP_GetWindow(workspace, windowId)) )
        return -1;

    CIMP_WindowIncrementalMoveView(window, x , y);

    return 0;
}


// Actualise la fenêtre
void CIMP_Repaint (CIMP_Workspace* workspace, size_t windowId) {
    CIMP_Window* window = CIMP_GetWindow(workspace, windowId);
    CIMP_RepaintWindow(&window);
}




// Affiche la liste des fenêtres
void CIMP_PrintWindowList (CIMP_Workspace* workspace) {
    size_t listSize = CIMP_ChainedListSize(workspace->windowList);

    CIMP_WindowCell* windowCell = NULL;
    CIMP_Window* window = NULL;
    CIMP_Picture* picture = NULL;

    printf("\033[34m Liste de fenêtres: \n");
    printf(" Id | Nom de la fenêtre | Nom de l'image \033[0m\n");
    for (size_t i = 0; i < listSize; i++) {
        windowCell = (CIMP_WindowCell*)CIMP_GetElement(workspace->windowList, i);
        window = CIMP_GetWindowCellWindow(windowCell);
        picture = CIMP_GetWindowCellPicture(windowCell);

        printf("\033[34m %u.", CIMP_GetWindowId(window) );
        printf(" | ");
        printf("'%s'", CIMP_GetWindowTitle(window) );
        printf(" | ");
        if ( CIMP_WindowCellPictureExists(windowCell) )
            printf("'%s' \033[0m\n", CIMP_GetPictureName(picture) );
        else
            printf("NULL \033[0m \n");
    }
}


// Affiche la liste des images
void CIMP_PrintPictureList (CIMP_Workspace* workspace) {
    size_t listSize = CIMP_ChainedListSize(workspace->pictureList);

    CIMP_PictureCell* pictureCell = NULL;
    CIMP_Window* window = NULL;
    CIMP_Picture* picture = NULL;

    printf("\033[34m Liste d'images: \n");
    printf(" Id | Nom de l'image | Nom de la fenêtre \033[0m\n");

    for (size_t i = 0; i < listSize; i++) {
        pictureCell = (CIMP_PictureCell*)CIMP_GetElement(workspace->pictureList, i);
        window = CIMP_GetPictureCellWindow(pictureCell);
        picture = CIMP_GetPictureCellPicture(pictureCell);

        printf("\033[34m %u.", CIMP_GetPictureId(picture) );
        printf(" | ");
        printf("'%s'", CIMP_GetPictureName(picture) );
        printf(" | ");
        if ( CIMP_PictureCellWindowExists(pictureCell) )
            printf("'%s' \033[0m\n", CIMP_GetWindowTitle(window) );
        else
            printf("NULL \033[0m\n");
    }
}



// Libère la mémoire de CIMP_Workspace
void CIMP_DestroyWorkspace (CIMP_Workspace** workspace) {
    if ( (*workspace)->pictureList ) {        
        CIMP_DestroyChainedList(&(*workspace)->pictureList, CIMP_DestroyPictureCell);
        (*workspace)->pictureList = NULL;
    }    
    if ( (*workspace)->windowList ) {
        CIMP_DestroyChainedList(&(*workspace)->windowList, CIMP_DestroyWindowCell);
        (*workspace)->windowList = NULL;
    }
    if ( (*workspace)->lastPictureId ) {
        CIMP_DestroyChainedList(&(*workspace)->lastPictureId, CIMP_DestroyId);
        (*workspace)->lastPictureId = NULL;
    }
    if ( *workspace ) {
        free(*workspace);
        *workspace = NULL;
    }
}


// Libère la mémoire occupé par l'identifiant
static void CIMP_DestroyId (void** voidId) {
    if ( voidId ) {
        free(*voidId);
        voidId = NULL;
    }
}