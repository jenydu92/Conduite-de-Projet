/**
 * \file        CIMP_picturemanager.c
 * \author      C.Cedric
 * \version     1.0
 * \date        Avril 2019
 * \brief       Définit les cellules images.
 *
 * \details    Ce module permet de gérer l'associativité image/fenêtre.
 */

#include "CIMP_picturemanager.h"

/*!
*   \struct CIMP_PictureCell
*   \brief Objet cellule image.
* 
*   CIMP_PictureCell correspond à une association image/fenêtre.
*   Une cellule image contient un pointeur vers une image et
*   un pointeur vers une fenêtre.
*/
struct CIMP_PictureCell {
    CIMP_Picture* picture; /*!< Image CIMP */
    CIMP_Window* window; /*!< Fenêtre CIMP */
};


// Crée une CIMP_PictureCell
int CIMP_CreatePictureCell(CIMP_PictureCell** cell, char* path, Uint32 id) {
    *cell = NULL;
    CIMP_Picture* picture = NULL;


    if ( !(*cell = (CIMP_PictureCell*)malloc(sizeof(CIMP_PictureCell))) ) {
        fprintf(stderr, "\033[31;1m Erreur rencontré lors de l'allocation mémoire de CIMP_PictureCell \033[0m \n");
        
        return -1;
    }


    if ( CIMP_CreatePicture(&picture, path, id) < 0 ) {
        free(*cell);
        *cell = NULL;

        return -1;
    }
    
    
    (*cell)->picture = picture;
    (*cell)->window = NULL;

    return 0;
}


// Retourne la CIMP_Picture
CIMP_Picture* CIMP_GetPictureCellPicture(CIMP_PictureCell* cell) {
    return cell->picture;
}


// Retourne la CIMP_Window
CIMP_Window* CIMP_GetPictureCellWindow(CIMP_PictureCell* cell) {
    return cell->window;
}


// Vérifie si une fenêtre a déjà été assignée à l'image
int CIMP_PictureCellWindowExists(CIMP_PictureCell* cell) {
    return (cell->window)? 1 : 0;
}


// Asigne une fenêtre à l'image
int CIMP_PictureCellAssignWindow(CIMP_PictureCell** cell, CIMP_Window* window) {
    if ( (*cell)->window ) {
        fprintf(stderr, "\033[33;1m Une fenêtre est déjà assignée à cette image \033[0m \n");

        return -1;
    }

    (*cell)->window = window;

    return 0;
}


// Retire la fenêtre
void CIMP_PictureCellRemoveWindow(CIMP_PictureCell** cell) {
    (*cell)->window = NULL;
}


// Libére la mémoire occupé par CIMP_PictureCell
void CIMP_DestroyPictureCell(void** voidCell) {
    CIMP_PictureCell** cell = (CIMP_PictureCell**)voidCell;
    if ( (*cell)->picture ) {        
        CIMP_DestroyPicture(&(*cell)->picture);
        (*cell)->picture = NULL;
    }
    if ( *cell ) {
        free(*cell);
        *cell = NULL;
    }
}