/**
 * \file        CIMP_windowmanager.c
 * \author      C.Cedric
 * \version     1.0
 * \date        Avril 2019
 * \brief       Définit les cellules fenêtres.
 *
 * \details    Ce module permet de gérer l'associativité fenêtre/image.
 */

#include "CIMP_windowmanager.h"

/*!
*   \struct CIMP_WindowCell
*   \brief Objet cellule fenêtre.
* 
*   CIMP_WindowCell correspond à une association fenêtre/image.
*   Une cellule fenêtre contient un pointeur vers une fenêtre et
*   un pointeur vers une image.
*/
struct CIMP_WindowCell {
    CIMP_Window* window; /*!< Fenêtre CIMP */
    CIMP_Picture* picture; /*!< Image CIMP */
};


// Crée une CIMP_WindowCell avec une nouvelle fenêtre
int CIMP_CreateWindowCell(CIMP_WindowCell** cell) {
    *cell = NULL;
    CIMP_Window* window = NULL;


    if ( !(*cell = (CIMP_WindowCell*)malloc(sizeof(CIMP_WindowCell))) ) {
        fprintf(stderr, "\033[31;1m Erreur rencontré lors de l'allocation mémoire de CIMP_WindowCell \033[0m \n");
        
        return -1;
    }


    if ( CIMP_CreateWindow(&window) < 0 ) {
        free(*cell);
        *cell = NULL;

        return -1;
    }


    (*cell)->window = window;
    (*cell)->picture = NULL;

    return 0;
}


// Retourne la CIMP_Window
CIMP_Window* CIMP_GetWindowCellWindow(CIMP_WindowCell* cell) {
    return cell->window;
}


// Retourne la CIMP_Picture
CIMP_Picture* CIMP_GetWindowCellPicture(CIMP_WindowCell* cell) {
    return cell->picture;
}


// Vérifie si une image a déjà été assignée à la fenêtre
int CIMP_WindowCellPictureExists(CIMP_WindowCell* cell) {
    return (cell->picture)? 1 : 0;
}


// Asigne une image
int CIMP_WindowCellAssignPicture(CIMP_WindowCell** cell, CIMP_Picture* picture) {
    if ( (*cell)->picture ) {
        fprintf(stderr, "\033[31;1m Une image est déjà assignée à cette fenêtre \033[0m \n");

        return -1;
    }


    (*cell)->picture = picture;

    return 0;
}


// Retire l'image
void CIMP_WindowCellRemovePicture(CIMP_WindowCell** cell) {
    if ( (*cell)->picture ) {
        CIMP_SetWindowTexture(&(*cell)->window, NULL);
        CIMP_SetWindowTitle((*cell)->window, "", 0);
        (*cell)->picture = NULL;
    }
}


// Libére la mémoire occupé par CIMP_WindowCell
void CIMP_DestroyWindowCell(void** voidCell) {
    CIMP_WindowCell** cell = (CIMP_WindowCell**)voidCell;
    if ( (*cell)->window ) {        
        CIMP_DestroyWindow(&(*cell)->window);
        (*cell)->window = NULL;
    }
    if ( *cell ) {
        free(*cell);
        *cell = NULL;
    }
}