/**
 * \file        CIMP_picture.c
 * \author      C.Cedric
 * \version     1.0
 * \date        Avril 2019
 * \brief       Définit une image de CIMP.
 *
 * \details    Ce module permet la gestion d'une image spécifique à CIMP.
 */

#include "CIMP_picture.h"


/*!
*   \struct CIMP_Picture
*   \brief Objet image.
* 
*   CIMP_Picture correspond à une image.
*   Une image contient un pointeur vers une surface
*   de type SDL_Surface, un nom, une selection de pixels 
*   et un identifiant.
*/
struct CIMP_Picture {
    SDL_Surface* surface; /*!< Surface SDL */
    char* name; /*!< Le nom de l'image */
    Pixels_Select* selection; /*!< Les pixels selectionnés */
    Uint32 id; /*!< Identifiant de l'image */
};


// Crée une image
int CIMP_CreatePicture (CIMP_Picture** picture, const char* path, Uint32 id) {
    size_t nameSize = strlen(path);
    char* filename = NULL;
    *picture = NULL;


    if ( !(*picture = (CIMP_Picture*)malloc(sizeof(CIMP_Picture))) ) {
        fprintf(stderr, "\033[31;1m Erreur rencontré lors de l'allocation mémoire de CIMP_Picture \033[0m \n");
        
        return -1;
    }


    if ( (filename = strrchr(path, '/')) ) {
        filename += 1;
        nameSize = strlen(filename);
    }


    (*picture)->surface = NULL;
    (*picture)->name = NULL;
    (*picture)->selection = NULL;

    SDL_Surface* loaded = IMG_Load(path);

    if ( !(loaded) ) {
        fprintf(stderr, "\033[31;1m Erreur lors du chargement de l'image: %s \033[0m \n", IMG_GetError());
        
        free(*picture);
        *picture = NULL;
        
        return -1;
    }

    SDL_Surface* optimized = SDL_ConvertSurface( loaded, loaded->format, 0);

    if ( !(optimized) ) {
        fprintf(stderr, "\033[31;1m Erreur lors de l'optimisation de l'image: %s \033[0m \n", IMG_GetError());

        SDL_FreeSurface(loaded);
        loaded = NULL;

        free(*picture);
        *picture = NULL;
        
        return -1;
    }

    (*picture)->surface = optimized;

    SDL_FreeSurface(loaded);
    loaded = NULL;

    if ( !((*picture)->name = (char*)malloc( (nameSize + 1) * sizeof(char))) ) {
        fprintf(stderr, "\033[31;1m Erreur rencontré lors de l'allocation du nom de l'image \033[0m \n");
        
        free(*picture);
        *picture = NULL;

        free((*picture)->surface);
        (*picture)->surface = NULL;

        return -1;
    }


    memset((*picture)->name, '\0', ( (nameSize + 1) * sizeof(char) ));
    (*picture)->name = memcpy((*picture)->name, ((filename)? filename : path), ( nameSize * sizeof(char)));


    if ( !((*picture)->selection = create_selec((((*picture)->surface)->w * ((*picture)->surface)->h), ((*picture)->surface)->w)) ) {
        fprintf(stderr, "\033[31;1m Erreur rencontré lors de la création de la sélection de l'image \033[0m \n");
        
        free(*picture);
        *picture = NULL;

        free((*picture)->surface);
        (*picture)->surface = NULL;

        free((*picture)->name);
        (*picture)->name = NULL;

        return -1;
    }

    (*picture)->id = id;


    return 0;
}


// Retourne la SDL_Surface de l'image
SDL_Surface* CIMP_GetPictureSurface(CIMP_Picture* picture) {
    return picture->surface;
}


// Retourne le nom de l'image
char* CIMP_GetPictureName(CIMP_Picture* picture) {
    return picture->name;
}


// Retourne la selection de l'image
Pixels_Select* CIMP_GetPictureSelection(CIMP_Picture* picture) {
    return picture->selection;
}


// Retourne l'identifiant de l'image
Uint32 CIMP_GetPictureId(CIMP_Picture* picture) {
    return picture->id;
}


// Modifie le nom de l'image
int CIMP_SetPictureName(CIMP_Picture* picture, char* name, size_t nameSize) {
    if ( picture->name ) {
        free(picture->name);
        picture->name = NULL;
    }

    if ( !(picture->name = malloc( (nameSize + 1) * sizeof(char))) ) {
        fprintf(stderr, "\033[31;1m Erreur rencontré lors de l'allocation du nom de l'image \033[0m \n");
        
        return -1;
    }

    memset(picture->name, '\0', ( (nameSize + 1) * sizeof(char) ));
    picture->name = memcpy(picture->name, name, ( nameSize * sizeof(char)));

    return 0;
}


// Modifie la SDL_Surface de l'image
void CIMP_SetPictureSurface(CIMP_Picture* picture, SDL_Surface* surface) {
    picture->surface = surface;
}


// Libère correctement les pointeurs utilisé
void CIMP_DestroyPicture (CIMP_Picture** picture) {
    
    if ( (*picture)->surface ) {
        SDL_FreeSurface((*picture)->surface);
        (*picture)->surface = NULL;
    }
    if ( (*picture)->name ) {
        free((*picture)->name);
        (*picture)->name = NULL;
    }
    if ( (*picture)->selection ) {
        destroySelec(&(*picture)->selection);
    }
    if ( *picture ) {
        free(*picture);
        *picture = NULL;
    }
}