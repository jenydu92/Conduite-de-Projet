/**
 * \file        CIMP_picturemanager.h
 * \author      C.Cedric
 * \version     1.0
 * \date        Avril 2019
 * \brief       Définit l'interface des cellules images.
 *
 * \details    Ce module permet de gérer l'associativité image/fenêtre.
 */

#ifndef _CIMP_PICTUREMANAGER_H_
#define _CIMP_PICTUREMANAGER_H_

#include "CIMP_window.h"
#include "CIMP_picture.h"

/*!
*   \typedef CIMP_PictureCell
*   \brief Objet cellule image.
*/
typedef struct CIMP_PictureCell CIMP_PictureCell;

/*!
*   \fn int CIMP_CreatePictureCell(CIMP_PictureCell** cell, char* path, Uint32 id)
*   \brief Fonction créant une nouvelle cellule image.
* 
*   \param cell L'adresse du pointeur vers l'image.
*   \param path L'adresse où charger l'image.
*   \param id L'identifiant à assigner à l'image.
*
*   \return 0 si pas d'erreur, sinon un entier négatif.
*
*   Cette fonction créé une nouvelle cellule image avec
*   une image créé à partir du chemin vers l'image et de
*   l'identifiant passé en paramètre.
*/
int CIMP_CreatePictureCell(CIMP_PictureCell**, char*, Uint32);

/*!
*   \fn CIMP_Window* CIMP_GetPictureCellWindow(CIMP_PictureCell* cell)
*   \brief Fonction retournant la CIMP_Window* de la cellule image.
* 
*   \param cell Le pointeur vers la cellule image.
*
*   \return CIMP_Window*.
*/
CIMP_Window* CIMP_GetPictureCellWindow(CIMP_PictureCell*);

/*!
*   \fn CIMP_Picture* CIMP_GetPictureCellPicture(CIMP_PictureCell* cell)
*   \brief Fonction retournant la CIMP_Picture* de la cellule image.
* 
*   \param cell Le pointeur vers la cellule image.
*
*   \return CIMP_Picture*.
*/
CIMP_Picture* CIMP_GetPictureCellPicture(CIMP_PictureCell*);

/*!
*   \fn int CIMP_PictureCellWindowExists(CIMP_PictureCell* cell)
*   \brief Fonction vérifiant si la cellule image possède une fenêtre.
* 
*   \param cell Le pointeur vers la cellule image.
*
*   \return 1 si il y a une fenêtre, sinon 0.
*/
int CIMP_PictureCellWindowExists(CIMP_PictureCell*);

/*!
*   \fn int CIMP_PictureCellAssignWindow(CIMP_PictureCell** cell, CIMP_Window* window)
*   \brief Fonction assignant une fenêtre à la cellule image.
* 
*   \param cell Le pointeur vers la cellule image.
*   \param window Le pointeur vers la fenêtre.
*
*   \return 0 si pas d'erreur, sinon un entier négatif.
*/
int CIMP_PictureCellAssignWindow(CIMP_PictureCell**, CIMP_Window*);

/*!
*   \fn void CIMP_PictureCellRemoveWindow(CIMP_PictureCell** cell)
*   \brief Fonction supprimant la fenêtre de la cellule image.
* 
*   \param cell Le pointeur vers la cellule image.
*/
void CIMP_PictureCellRemoveWindow(CIMP_PictureCell**);

/*!
*   \fn void CIMP_DestroyPictureCell(void** voidCell)
*   \brief Fonction libérant la mémoire occupé par la cellule image.
* 
*   \param voidCell L'adresse du pointeur vers la cellule image.
*/
void CIMP_DestroyPictureCell(void**);


#endif