/**
 * \file        CIMP_workspace.h
 * \author      C.Cedric
 * \version     1.0
 * \date        Avril 2019
 * \brief       Définit l'interface d'un espace de travail.
 *
 * \details    Ce module permet de gérer toutes les images et toutes les fenêtres.
 */

#ifndef _CIMP_WORKSPACE_H_
#define _CIMP_WORKSPACE_H_
    
#include <SDL2/SDL.h>
#include "../util/CIMP_graphicconfig.h"
#include "../util/CIMP_chainedlist.h"
#include "../util/CIMP_file.h"
#include "../util/CIMP_savefile.h"
#include "CIMP_windowmanager.h"
#include "CIMP_picturemanager.h"
    

/*!
*   \typedef CIMP_Workspace
*   \brief Objet espace de travail.
*/
typedef struct CIMP_Workspace CIMP_Workspace;


/*!
*   \fn int CIMP_InitWorkspace(CIMP_Workspace** workspace)
*   \brief Fonction d'initialisation de l'espace de travail.
* 
*   \param workspace L'adresse du pointeur vers l'espace de travail.
*
*   \return 0 si aucune erreur, sinon un entier négatif.
*
*    L'utilisateur doit fournir l'adresse du pointeur de 
*   CIMP_Workspace en paramètre pour que celui-ci 
*   soit rempli par la fonction.
*   Celui-ci vaudra NULL en cas d'erreur et toute mémoire alloué
*   durant le processus sera libéré.
*/
int CIMP_InitWorkspace(CIMP_Workspace**);



/*!
*   \fn SDL_Surface* CIMP_GetClipboard (CIMP_Workspace* workspace)
*   \brief Fonction permettant de récupérer une surface dans le presse-papier.
* 
*   \param workspace Le pointeur vers l'espace de travail.
*
*   \return SDL_Surface* si presse-papier non vide, sinon NULL.
*/
SDL_Surface* CIMP_GetClipboard (CIMP_Workspace*);


/*!
*   \fn void CIMP_SetClipboard (CIMP_Workspace* workspace, SDL_Surface* surface)
*   \brief Fonction permettant de remplacer le contenu du presse-papier.
* 
*   \param workspace Le pointeur vers l'espace de travail.
*   \param surface La surface qui sera mis dans le presse-papier.
*/
void CIMP_SetClipboard (CIMP_Workspace*, SDL_Surface*);


/*!
*   \fn CIMP_Picture* CIMP_GetPicture(CIMP_Workspace* workspace, size_t pictureId)
*   \brief Fonction permettant de récupérer une image à partir de son id.
* 
*   \param workspace Le pointeur vers l'espace de travail.
*   \param pictureId L'identifiant de l'image.
*
*   \return CIMP_Picture* si aucune erreur, sinon NULL.
*/
CIMP_Picture* CIMP_GetPicture(CIMP_Workspace*, size_t);

/*!
*   \fn CIMP_Picture* CIMP_GetWindow(CIMP_Workspace* workspace, size_t windowId)
*   \brief Fonction permettant de récupérer une fenêtre à partir de son id.
* 
*   \param workspace Le pointeur vers l'espace de travail.
*   \param windowId L'identifiant de la fenêtre.
*
*   \return CIMP_Window* si aucune erreur, sinon NULL.
*/
CIMP_Window* CIMP_GetWindow(CIMP_Workspace*, size_t);

/*!
*   \fn size_t CIMP_GetPictureAssocId(CIMP_Workspace* workspace, size_t pictureId)
*   \brief Fonction permettant de récupérer l'identifiant de la fenêtre associé à une image.
* 
*   \param workspace Le pointeur vers l'espace de travail.
*   \param pictureId L'identifiant de l'image.
*
*   \return size_t L'identifiant de la fenêtre associé si aucune erreur, sinon 0.
*/
size_t CIMP_GetPictureAssocId(CIMP_Workspace*, size_t);

/*!
*   \fn size_t CIMP_GetWindowAssocId(CIMP_Workspace* workspace, size_t windowId)
*   \brief Fonction permettant de récupérer l'identifiant de l'image associé à une fenêtre.
* 
*   \param workspace Le pointeur vers l'espace de travail.
*   \param windowId L'identifiant de la fenêtre.
*
*   \return size_t L'identifiant de l'image associé si aucune erreur, sinon 0.
*/
size_t CIMP_GetWindowAssocId(CIMP_Workspace*, size_t);


/*!
*   \fn CIMP_PictureCell* CIMP_LoadPicture(CIMP_Workspace* workspace, char* path)
*   \brief Fonction de chargement de l'image.
* 
*   \param workspace Le pointeur vers l'espace de travail.
*   \param path Le chemin vers l'image.
*
*   \return CIMP_PictureCell* si aucune erreur, sinon NULL.
*/
CIMP_PictureCell* CIMP_LoadPicture(CIMP_Workspace*, char*);

/*!
*   \fn int CIMP_SavePicture(CIMP_Workspace* workspace, size_t pictureId, char* path)
*   \brief Fonction enregistrant une image.
* 
*   \param workspace Le pointeur vers l'espace de travail.
*   \param pictureId L'identifiant de l'image.
*   \param path Chemin où enregistrer l'image.
*
*   \return 0 si pas d'erreur, sinon un entier négatif.
*/
int CIMP_SavePicture(CIMP_Workspace*, size_t, char*);


/*!
*   \fn int CIMP_ModifyPicture(CIMP_Workspace* workspace, size_t pictureId, SDL_Surface* surface)
*   \brief Fonction modifiant l'image et mettant à jour sa fenêtre associé.
* 
*   \param workspace Le pointeur vers l'espace de travail.
*   \param pictureId L'identifiant de l'image.
*   \param surface La SDL_Surface de remplacement.
*
*   \return 0 si pas d'erreur, sinon un entier négatif.
*/
int CIMP_ModifyPicture(CIMP_Workspace*, size_t, SDL_Surface*);

/*!
*   \fn int CIMP_RemovePicture(CIMP_Workspace* workspace, size_t pictureId)
*   \brief Fonction supprimant l'image de l'espace de travail.
* 
*   \param workspace Le pointeur vers l'espace de travail.
*   \param pictureId L'identifiant de l'image.
*
*   \return 0 si pas d'erreur, sinon un entier négatif.
*/
int CIMP_RemovePicture(CIMP_Workspace*, size_t);

/*!
*   \fn int CIMP_RenamePicture(CIMP_Workspace* workspace, size_t pictureId, char* name)
*   \brief Fonction renommant l'image.
* 
*   \param workspace Le pointeur vers l'espace de travail.
*   \param pictureId L'identifiant de l'image.
*   \param name Le nouveau nom de l'image.
*
*   \return 0 si pas d'erreur, sinon un entier négatif.
*/
int CIMP_RenamePicture(CIMP_Workspace*, size_t, char*);


/*!
*   \fn int CIMP_DisplayPicture (CIMP_Workspace* workspace, size_t pictureId, size_t windowId)
*   \brief Fonction affichant une image dans une fenêtre.
* 
*   \param workspace Le pointeur vers l'espace de travail.
*   \param pictureId L'identifiant de l'image.
*   \param windowId L'identifiant de la fenêtre.
*
*   \return 0 si pas d'erreur, sinon un entier négatif.
*
*   Si le dernier paramètre de la fonction vaut 0,
*   alors l'image sera affiché dans une nouvelle fenêtre.
*/
int CIMP_DisplayPicture (CIMP_Workspace* workspace, size_t pictureId, size_t windowId);

/*!
*   \fn int CIMP_MaskPicture(CIMP_Workspace* workspace, size_t pictureId)
*   \brief Fonction cachant une fenêtre contenant l'image identifié.
* 
*   \param workspace Le pointeur vers l'espace de travail.
*   \param pictureId L'identifiant de l'image.
*
*   \return 0 si pas d'erreur, sinon un entier négatif.
*
*   Cette fonction est similaire à `int CIMP_MaskWindow(CIMP_Workspace*, size_t)`.
*/
int CIMP_MaskPicture(CIMP_Workspace*, size_t);


/*!
*   \fn CIMP_WindowCell* CIMP_OpenWindow(CIMP_Workspace* workspace)
*   \brief Fonction créant une nouvelle fenêtre dans l'espace de travail.
* 
*   \param workspace Le pointeur vers l'espace de travail.
*
*   \return CIMP_WindowCell* si pas d'erreur, sinon NULL.
*/
CIMP_WindowCell* CIMP_OpenWindow(CIMP_Workspace*);

/*!
*   \fn int CIMP_DisplayWindow(CIMP_Workspace* workspace, size_t windowId)
*   \brief Fonction affichant une fenêtre.
* 
*   \param workspace Le pointeur vers l'espace de travail.
*   \param windowId L'identifiant de la fenêtre.
*
*   \return 0 si pas d'erreur, sinon un entier négatif.
*/
int CIMP_DisplayWindow(CIMP_Workspace*, size_t);

/*!
*   \fn int CIMP_MaskWindow(CIMP_Workspace* workspace, size_t windowId)
*   \brief Fonction cachant une fenêtre.
* 
*   \param workspace Le pointeur vers l'espace de travail.
*   \param windowId L'identifiant de la fenêtre.
*
*   \return 0 si pas d'erreur, sinon un entier négatif.
*
*   Cette fonction est similaire à `int CIMP_MaskPicture(CIMP_Workspace**, size_t)`.
*/
int CIMP_MaskWindow(CIMP_Workspace*, size_t);

/*!
*   \fn int CIMP_RemoveWindow(CIMP_Workspace* workspace, size_t windowId)
*   \brief Fonction supprimant une fenêtre.
* 
*   \param workspace Le pointeur vers l'espace de travail.
*   \param windowId L'identifiant de la fenêtre.
*
*   \return 0 si pas d'erreur, sinon un entier négatif.
*/
int CIMP_RemoveWindow(CIMP_Workspace*, size_t);

/*!
*   \fn int CIMP_MoveView (CIMP_Workspace* workspace, size_t windowId, size_t x, size_t y)
*   \brief Fonction permettant de déplacer la vue à la position donné.
* 
*   \param workspace L'adresse du pointeur vers l'espace de travail.
*   \param windowId L'identifiant de la fenêtre.
*   \param x La nouvelle position sur l'axe des abscisses.
*   \param y La nouvelle position sur l'axe des ordonnées.
*
*   \return 0 si pas d'erreur, sinon un entier négatif.
*
*   Attention, la position x,y correspond au coin supérieur gauche de la fenêtre.
*   La vue n'est pas centré sur ce point.
*/
int CIMP_MoveView (CIMP_Workspace*, size_t, size_t, size_t);

/*!
*   \fn void CIMP_IncrementalMoveView (CIMP_Workspace* workspace, size_t windowId, int x, int y)
*   \brief Fonction permettant de déplacer la vue par incrémentation.
* 
*   \param workspace L'adresse du pointeur vers l'espace de travail.
*   \param windowId L'identifiant de la fenêtre.
*   \param x L'incrémentation sur l'axe des abscisses.
*   \param y L'incrémentation sur l'axe des ordonnées.
*
*   \return 0 si pas d'erreur, sinon un entier négatif.
*/
int CIMP_IncrementalMoveView (CIMP_Workspace*, size_t, int, int); 

/*!
*   \fn void CIMP_Repaint(CIMP_Workspace* workspace, size_t windowId)
*   \brief Fonction de mise à jours d'une fenêtre.
* 
*   \param workspace Le pointeur vers l'espace de travail.
*   \param windowId L'identifiant de la fenêtre.
*
*   La fonction ne vérifie pas si l'identifiant existe.
*/
void CIMP_Repaint(CIMP_Workspace*, size_t);



/*!
*   \fn void CIMP_PrintWindowList(CIMP_Workspace* workspace)
*   \brief Fonction affichant la liste des fenêtres existantes.
* 
*   \param workspace Le pointeur vers l'espace de travail.
*/
void CIMP_PrintWindowList(CIMP_Workspace*);

/*!
*   \fn void CIMP_PrintPictureList(CIMP_Workspace* workspace)
*   \brief Fonction affichant la liste des images existantes.
* 
*   \param workspace Le pointeur vers l'espace de travail.
*/
void CIMP_PrintPictureList(CIMP_Workspace*);


/*!
*   \fn void CIMP_DestroyWorkspace(CIMP_Workspace** workspace)
*   \brief Fonction libérant la mémoire occupé par l'espace de travail.
* 
*   \param workspace L'adresse du pointeur vers l'espace de travail.
*/
void CIMP_DestroyWorkspace(CIMP_Workspace**);

#endif