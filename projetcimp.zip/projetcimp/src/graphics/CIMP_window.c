/**
 * \file        CIMP_window.c
 * \author      C.Cedric
 * \version     1.0
 * \date        Avril 2019
 * \brief       Définit une fenêtre de CIMP.
 *
 * \details    Ce module permet la gestion d'une fenêtre spécifique à CIMP.
 */

#include "CIMP_window.h"

#define WIN_DEFSIZE_X 400 /*!< Largeur par défaut d'une fenêtre */
#define WIN_DEFSIZE_Y 200 /*!< Hauteur par défaut d'une fenêtre */


/*!
*   \struct CIMP_Window
*   \brief Objet fenêtre.
* 
*   CIMP_Window correspond à une fenêtre.
*   Une fenêtre contient un pointeur vers une fenêtre
*   de type SDL_Window ainsi qu'une texture de type
*   SDL_Texture. 
*/
struct CIMP_Window {
    SDL_Window* window; /*!< Fenêtre SDL */
    SDL_Texture* texture; /*!< Texture SDL */
    SDL_Rect* position; /*!< Position de la vue */
};


/*!
*   \fn static int CIMP_CreateRenderer(SDL_Window* window)
*   \brief Fonction initialisant le moteur de rendu de la fenêtre.
* 
*   \param window La fenêtre.
*
*   \return 0 si pas d'erreur, sinon un entier négatif.
*/
static int CIMP_CreateRenderer(SDL_Window*);


/*!
*   \fn int CIMP_MakeWindowTitle (char** title, Uint32 id, const char* pictureName, size_t nameSize)
*   \brief Fonction de mise en forme du titre de la fenêtre.
* 
*   \param title L'adresse du pointeur vers le nouveau titre.
*   \param id L'identifiant de la fenêtre
*   \param pictureName La chaine de caractère suivant l'identifiant
*   \param nameSize La taille de la chaine de caractère
*
*   \return 0 si pas d'erreur, sinon un entier négatif.
*/
static int CIMP_MakeWindowTitle (char**, Uint32, const char*, size_t);


// Initialise la fenetre passé en paramètre
int CIMP_CreateWindow (CIMP_Window** window) {
    *window = NULL;


    if ( !(*window = (CIMP_Window*)malloc(sizeof(CIMP_Window))) ) {
        fprintf(stderr, "\033[31;1m Erreur rencontré lors de l'allocation mémoire de CIMP_Window \033[0m \n");
        
        return -1;
    }


    (*window)->window = NULL;
    (*window)->texture = NULL;
    (*window)->position = NULL;

    (*window)->window =  SDL_CreateWindow("#", // nom 
                                SDL_WINDOWPOS_CENTERED, // pos x
                                SDL_WINDOWPOS_CENTERED, // pos Y
                                WIN_DEFSIZE_X, // largeur
                                WIN_DEFSIZE_Y, // hauteur
                                SDL_WINDOW_HIDDEN | SDL_WINDOW_RESIZABLE); // option


    if (!((*window)->window)) {
        fprintf(stderr, "\033[31;1m Impossible de créer la nouvelle fenêtre: %s \033[0m \n", SDL_GetError());
        
        free(*window);
        *window = NULL;
        
        return -1;
    }


    if ( CIMP_CreateRenderer((*window)->window) < 0 ) {
        SDL_DestroyWindow((*window)->window);
        (*window)->window = NULL;
        
        free(*window);
        *window = NULL;
        
        return -1;
    }


    if ( !((*window)->position = (SDL_Rect*)malloc(sizeof(SDL_Rect))) ) {
        fprintf(stderr, "\033[31;1m Erreur rencontré lors de l'allocation mémoire de la vue de CIMP_Window \033[0m \n");
        
        return -1;
    }

    ((*window)->position)->x = 0;
    ((*window)->position)->y = 0;
    ((*window)->position)->w = WIN_DEFSIZE_X;
    ((*window)->position)->h = WIN_DEFSIZE_Y;

    CIMP_SetWindowTitle (*window, NULL, 0);

    return 0;
}


static int CIMP_CreateRenderer(SDL_Window* window) {
    SDL_Renderer *renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);


    if (!renderer) {
        fprintf(stderr, "\033[31;1m Erreur rencontré: %s \033[0m \n", SDL_GetError());

        return -1;
    }


    if ( SDL_SetRenderDrawColor(renderer, 255, 255, 255, 255) < 0 ) {
        fprintf(stderr, "\033[31;1m Impossible de choisir la couleur de dessin: %s \033[0m \n", SDL_GetError());

        SDL_DestroyRenderer(renderer);
        
        return -1;
    }

    if ( SDL_RenderClear(renderer) < 0 ) {
        fprintf(stderr, "\033[31;1m Erreur rencontré: %s \033[0m \n", SDL_GetError());

        SDL_DestroyRenderer(renderer);

        return -1;
    }


    SDL_RenderPresent(renderer);

    return 0;
}


// Retourne la fenêtre de la CIMP_Window
SDL_Window* CIMP_GetWindowWindow(CIMP_Window* window) {
    return window->window;
}


// Retourne l'identifiant de la fenêtre
Uint32 CIMP_GetWindowId(CIMP_Window* window) {
    return SDL_GetWindowID(window->window);
}


// Retourne le titre de la fenêtre
const char* CIMP_GetWindowTitle(CIMP_Window* window) {
    return SDL_GetWindowTitle(window->window);
}


// Modifie la texture
int CIMP_SetWindowTexture(CIMP_Window** window, SDL_Surface* surface) {
    SDL_Renderer* renderer = NULL;
    SDL_Texture* texture = NULL;
    int texture_w, texture_h;

    if ( !(renderer = (SDL_GetRenderer((*window)->window))) ) {
        fprintf(stderr, "\033[31;1m Erreur innatendu: %s \033[0m \n", SDL_GetError());

        SDL_DestroyWindow((*window)->window);
        (*window)->window = NULL;

        free(*window);
        *window = NULL;

        return -1;
    }

    if ( !surface ) {
        CIMP_SetWindowSize(*window, WIN_DEFSIZE_X, WIN_DEFSIZE_Y);

        SDL_DestroyTexture(texture);
        (*window)->texture = NULL;
    }
    else {
        if ( !(texture = SDL_CreateTextureFromSurface(renderer, surface)) ) {
            fprintf(stderr, "\033[31;1m Erreur rencontré: %s \033[0m \n", SDL_GetError());

            SDL_DestroyRenderer(renderer);
            SDL_DestroyWindow((*window)->window);
            (*window)->window = NULL;

            free(*window);
            *window = NULL;

            return -1;
        }

        if ( SDL_QueryTexture(texture, NULL, NULL, &texture_w, &texture_h) ) {
            fprintf(stderr, "\033[31;1m Erreur rencontré: %s \033[0m \n", SDL_GetError());

            SDL_DestroyTexture(texture);
            SDL_DestroyRenderer(renderer);
            SDL_DestroyWindow((*window)->window);
            (*window)->window = NULL;

            free(*window);
            *window = NULL;

            return -1;
        }
        
        CIMP_SetWindowSize(*window, texture_w, texture_h);    

        SDL_DestroyTexture((*window)->texture);
        (*window)->texture = texture;
    }

    return 0;
}


// Renomme la fenêtre
void CIMP_SetWindowTitle (CIMP_Window* window, const char* name, size_t nameSize) {
    char* title = NULL;
    CIMP_MakeWindowTitle (&title, SDL_GetWindowID(window->window), name, nameSize);
    SDL_SetWindowTitle(window->window, title);

    // On libère notre pointeur, 
    // la SDL fait son propre malloc de son côté
    free(title);
    title = NULL;
}


int CIMP_MakeWindowTitle (char** title, Uint32 id, const char* pictureName, size_t nameSize) {
    char* header = "#";
    char s_id [3];
    snprintf(s_id, 3, "%d", id);
    char* separator = " - ";
    int totalSize = strlen(header) + strlen(s_id) + strlen(separator) + nameSize + 1;
    
    *title = malloc(totalSize * sizeof(char));

    if ( !title ) {
        fprintf(stderr, "\033[31;1m Erreur rencontré lors de l'allocation mémoire du nom de la fenêtre \033[0m \n");
        
        return -1;
    }

    memset(*title,0,totalSize);
    strncpy(*title, header, strlen(header));
    strncat(*title, s_id, strlen(s_id));
    strncat(*title, separator, strlen(separator));
    if ( pictureName && nameSize > 0 ) 
        strncat(*title, pictureName, nameSize);
    strcat(*title, "\0");

    return ( *title )? 1 : -1;
}


// Redimensionne la fenêtre
void CIMP_SetWindowSize (CIMP_Window *window, int new_size_w, int new_size_h) {
    SDL_SetWindowSize(window->window, new_size_w, new_size_h);
}


// Modifie la position de la fenêtre
void CIMP_SetWindowPosition (CIMP_Window* window, int x, int y) {
    SDL_SetWindowPosition(window->window, x, y);
}


// Deplace la vue aux positions x, y (coordonné du point en haut à gauche)
void CIMP_WindowMoveView (CIMP_Window* window, size_t x, size_t y) {
    (window->position)->x = x;
    (window->position)->y = y;
}


// Deplace la vue de la position initial plus x et y
void CIMP_WindowIncrementalMoveView (CIMP_Window* window, int x, int y) {
    (window->position)->x = (window->position)->x + x;
    (window->position)->y = (window->position)->y + y;
}


// Actualise la fenêtre
int CIMP_RepaintWindow (CIMP_Window **window) {
    int texture_w, texture_h;
    int window_w, window_h;

    SDL_Renderer* renderer = NULL;

    if ( !(renderer = (SDL_GetRenderer((*window)->window))) ) {
        fprintf(stderr, "\033[31;1m Erreur rencontré: %s \033[0m \n", SDL_GetError());
        
        return -1;
    }                


    SDL_GetWindowSize((*window)->window, &window_w, &window_h);

    
    if ( (*window)->texture ) {
        if ( SDL_QueryTexture((*window)->texture, NULL, NULL, &texture_w, &texture_h) ) {
            fprintf(stderr, "\033[31;1m Erreur rencontré: %s \033[0m \n", SDL_GetError());
            
            return -1;
        }


        ((*window)->position)->w = texture_w;
        ((*window)->position)->h = texture_h;


        if ( SDL_RenderClear(renderer) < 0 ) {
            fprintf(stderr, "\033[31;1m Erreur rencontré: %s \033[0m \n", SDL_GetError());
            
            return -1;
        }

        if ( SDL_RenderCopy(renderer, (*window)->texture, NULL, (*window)->position) < 0 ) {
            fprintf(stderr, "\033[31;1m Erreur rencontré: %s \033[0m \n", SDL_GetError());
            
            return -1;
        }
    }


    SDL_RenderPresent(renderer);

    return 0;
}


// Cache la fenêtre
void CIMP_HideWindow(CIMP_Window* window) {
    SDL_HideWindow(window->window);
}


// Affiche la fenêtre
void CIMP_ShowWindow(CIMP_Window* window) {
    SDL_ShowWindow(window->window);
}


// Libère correctement les pointeurs utilisé
void CIMP_DestroyWindow (CIMP_Window** window) {    
    if ( (*window)->window ) {        
        SDL_DestroyRenderer(SDL_GetRenderer((*window)->window));
        SDL_DestroyWindow((*window)->window);
        (*window)->window = NULL;
    }    
    if ( (*window)->texture ) {
        SDL_DestroyTexture((*window)->texture);
        (*window)->texture = NULL;
    }
    if ( (*window)->position ) {
        free((*window)->position);
        (*window)->position = NULL;
    }
    if ( *window ) {
        free(*window);
        *window = NULL;
    }
}