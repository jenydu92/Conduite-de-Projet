## Librairie gérant l'interface graphique du projet


### CIMP_window.h

```C
#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>

typedef struct CIMP_Window CIMP_Window; 

// Initialise la fenetre passé en paramètre
int CIMP_CreateWindow(CIMP_Window**);
// Retourne la fenêtre de la CIMP_Window
SDL_Window* CIMP_GetWindowWindow(CIMP_Window*);
// Retourne l'identifiant de la fenêtre
Uint32 CIMP_GetWindowId(CIMP_Window*);
// Retourne le titre de la fenêtre
const char* CIMP_GetWindowTitle(CIMP_Window*);
// Modifie la texture
int CIMP_SetWindowTexture(CIMP_Window**, SDL_Surface*);
// Renomme la fenêtre
void CIMP_SetWindowTitle(CIMP_Window*, const char*, size_t);
// Redimensionne la fenêtre
void CIMP_SetWindowSize(CIMP_Window*, int, int);
// Actualise la fenêtre
int CIMP_RepaintWindow(CIMP_Window**);
// Libère correctement les pointeurs utilisé
void CIMP_DestroyWindow(CIMP_Window**);
```

### CIMP_picture.h

```C
#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>


typedef struct CIMP_Picture CIMP_Picture;

// Crée une image
int CIMP_CreatePicture (CIMP_Picture**, const char*, Uint32);
// Retourne la SDL_Surface de l'image
SDL_Surface* CIMP_GetPictureSurface(CIMP_Picture*);
// Retourne le nom de l'image
char* CIMP_GetPictureName(CIMP_Picture*);
// Retourne l'identifiant de l'image
Uint32 CIMP_GetPictureId(CIMP_Picture*);
// Modifie le nom de l'image
void CIMP_SetPictureName(CIMP_Picture*, char*);
// Modifie la SDL_Surface de l'image
void CIMP_SetPictureSurface(CIMP_Picture*, SDL_Surface*);
// Libère correctement les pointeurs utilisé
void CIMP_DestroyPicture(CIMP_Picture**);
```

### CIMP_picturemanager.h

```C
#include "CIMP_window.h"
#include "CIMP_picture.h"

typedef struct CIMP_PictureCell CIMP_PictureCell;

// Crée une CIMP_PictureCell
int CIMP_CreatePictureCell(CIMP_PictureCell**, char*, Uint32);
// Retourne la CIMP_Window
CIMP_Window* CIMP_GetPictureCellWindow(CIMP_PictureCell*);
// Retourne la CIMP_Picture
CIMP_Picture* CIMP_GetPictureCellPicture(CIMP_PictureCell*);
// Vérifie si une fenêtre a déjà été assignée à l'image
int CIMP_PictureCellWindowExists(CIMP_PictureCell*);
// Asigne une fenêtre à l'image
int CIMP_PictureCellAssignWindow(CIMP_PictureCell**, CIMP_Window*);
// Retire la fenêtre
void CIMP_PictureCellRemoveWindow(CIMP_PictureCell**);
// Libére la mémoire occupé par CIMP_PictureCell
void CIMP_DestroyPictureCell(void**);
```

### CIMP_windowmanager.h

```C
#include "CIMP_window.h"
#include "CIMP_picture.h"

typedef struct CIMP_WindowCell CIMP_WindowCell;

// Crée une CIMP_WindowCell avec une nouvelle fenêtre
int CIMP_CreateWindowCell(CIMP_WindowCell**);
// Retourne la CIMP_Window
CIMP_Window* CIMP_GetWindowCellWindow(CIMP_WindowCell*);
// Retourne la CIMP_Picture
CIMP_Picture* CIMP_GetWindowCellPicture(CIMP_WindowCell*);
// Vérifie si une image a déjà été assignée à la fenêtre
int CIMP_WindowCellPictureExists(CIMP_WindowCell*);
// Asigne une image
int CIMP_WindowCellAssignPicture(CIMP_WindowCell**, CIMP_Picture*);
// Retire l'image
void CIMP_WindowCellRemovePicture(CIMP_WindowCell**);
// Libére la mémoire occupé par CIMP_WindowCell
void CIMP_DestroyWindowCell(void**);
```

### CIMP_workspace.h

```C
#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include "CIMP_graphicconfig.h"
#include "CIMP_chainedlist.h"
#include "CIMP_windowmanager.h"
#include "CIMP_picturemanager.h"
    
typedef struct CIMP_Workspace CIMP_Workspace;


// Initialise la structure
int CIMP_InitWorkspace(CIMP_Workspace**);


// Recherche et renvoie une image
CIMP_Picture* CIMP_GetPicture(CIMP_Workspace**, size_t);
// Recherche et renvoie une fenêtre
CIMP_Window* CIMP_GetWindow(CIMP_Workspace**, size_t);


// Charge une image
CIMP_PictureCell* CIMP_LoadPicture(CIMP_Workspace**, char*);
// Sauvegarde une image
// int CIMP_SavePicture(CIMP_Workspace**, size_t, char*);
// Modifie l'image et met à jour la fenêtre associé
int CIMP_ModifyPicture(CIMP_Workspace**, size_t, SDL_Surface*);
// Supprime une image
int CIMP_RemovePicture(CIMP_Workspace**, size_t);
// Change le nom d'une image
int CIMP_RenamePicture(CIMP_Workspace**, size_t, char*);


// Affiche une image
int CIMP_ShowPicture(CIMP_Workspace**, size_t, size_t);
// Cache l'image (similaire à CIMP_HideWindow)
int CIMP_HidePicture(CIMP_Workspace**, size_t);


// Ouvre une fenêtre
CIMP_WindowCell* CIMP_OpenWindow(CIMP_Workspace**);
// Affiche la fenêtre
int CIMP_ShowWindow(CIMP_Workspace**, size_t);
// Cache la fenêtre (similaire à CIMP_HidePicture)
int CIMP_HideWindow(CIMP_Workspace**, size_t);
// Supprime une fenêtre
int CIMP_RemoveWindow(CIMP_Workspace**, size_t);
// Actualise la fenêtre
void CIMP_Repaint(CIMP_Workspace**, size_t);


// Affiche la liste des fenêtres
void CIMP_PrintWindowList(CIMP_Workspace**);
// Affiche la liste des images
void CIMP_PrintPictureList(CIMP_Workspace**);


// Libère la mémoire de CIMP_Workspace
void CIMP_DestroyWorkspace(CIMP_Workspace**);
```