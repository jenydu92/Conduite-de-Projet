/**
 * \file        CIMP_picture.h
 * \author      C.Cedric
 * \version     1.0
 * \date        Avril 2019
 * \brief       Définit l'interface d'une image de CIMP.
 *
 * \details    Ce module permet la gestion d'une image spécifique à CIMP.
 */

#ifndef _CIMP_PICTURE_H_
#define _CIMP_PICTURE_H_
     
#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include "../util/selection.h"

/*!
*   \typedef CIMP_Picture
*   \brief Objet image.
*/
typedef struct CIMP_Picture CIMP_Picture;


/*!
*   \fn int CIMP_CreatePicture (CIMP_Picture** picture, const char* path, Uint32 id)
*   \brief Fonction créant une nouvelle image.
* 
*   \param picture L'adresse du pointeur vers l'image.
*   \param path L'adresse où charger l'image.
*   \param id L'identifiant à assigner à l'image.
*
*   \return 0 si pas d'erreur, sinon un entier négatif.
*/
int CIMP_CreatePicture (CIMP_Picture**, const char*, Uint32);

/*!
*   \fn SDL_Surface* CIMP_GetPictureSurface(CIMP_Picture* picture)
*   \brief Fonction retournant la SDl_Surface* de l'image.
* 
*   \param picture Le pointeur vers l'image.
*
*   \return SDL_Surface*.
*/
SDL_Surface* CIMP_GetPictureSurface(CIMP_Picture*);

/*!
*   \fn char* CIMP_GetPictureName(CIMP_Picture* picture)
*   \brief Fonction retournant le nom de l'image.
* 
*   \param picture Le pointeur vers l'image.
*
*   \return char*.
*/
char* CIMP_GetPictureName(CIMP_Picture*);

/*!
*   \fn char* CIMP_GetPictureSelection(CIMP_Picture* picture)
*   \brief Fonction retournant la selection de l'image.
* 
*   \param picture Le pointeur vers l'image.
*
*   \return Pixels_Select*.
*/
Pixels_Select* CIMP_GetPictureSelection(CIMP_Picture* picture);

/*!
*   \fn char* CIMP_GetPictureId(CIMP_Picture* picture)
*   \brief Fonction retournant l'identifiant de l'image.
* 
*   \param picture Le pointeur vers l'image.
*
*   \return Uint32 L'identifiant de l'image.
*/
Uint32 CIMP_GetPictureId(CIMP_Picture*);

/*!
*   \fn void CIMP_SetPictureName(CIMP_Picture* picture, char* name, size_t nameSize)
*   \brief Fonction modifiant le nom de l'image.
* 
*   \param picture Le pointeur vers l'image.
*   \param name Le nouveau nom de l'image.
*   \param nameSize Le poids de la chaine de caractère.
*/
int CIMP_SetPictureName(CIMP_Picture*, char*, size_t);

/*!
*   \fn void CIMP_SetPictureSurface(CIMP_Picture* picture, SDL_Surface* surface)
*   \brief Fonction modifiant la surface de l'image.
* 
*   \param picture Le pointeur vers l'image.
*   \param surface La nouvelle surface de l'image.
*
*   \return 0 si pas d'erreur, sinon un entier négatif.
*/
void CIMP_SetPictureSurface(CIMP_Picture*, SDL_Surface*);

/*!
*   \fn void CIMP_DestroyPicture (CIMP_Picture** picture)
*   \brief Fonction libérant la mémoire occupé par l'image.
* 
*   \param picture L'adresse du pointeur vers l'image.
*/
void CIMP_DestroyPicture(CIMP_Picture**);

#endif