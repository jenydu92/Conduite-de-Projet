/**
 * \file        CIMP_windowmanager.h
 * \author      C.Cedric
 * \version     1.0
 * \date        Avril 2019
 * \brief       Définit l'interface des cellules fenêtres.
 *
 * \details    Ce module permet de gérer l'associativité fenêtre/image.
 */

#ifndef _CIMP_WINDOWMANAGER_H_
#define _CIMP_WINDOWMANAGER_H_

#include "CIMP_window.h"
#include "CIMP_picture.h"

/*!
*   \typedef CIMP_WindowCell
*   \brief Objet cellule fenêtre.
*/
typedef struct CIMP_WindowCell CIMP_WindowCell;

/*!
*   \fn int CIMP_CreateWindowCell(CIMP_WindowCell** cell)
*   \brief Fonction créant une nouvelle cellule fenêtre.
* 
*   \param cell L'adresse du pointeur vers l'image.
*
*   \return 0 si pas d'erreur, sinon un entier négatif.
*
*   Cette fonction créé une nouvelle cellule fenêtre avec
*   une fenêtre par défaut.
*/
int CIMP_CreateWindowCell(CIMP_WindowCell**);

/*!
*   \fn CIMP_Window* CIMP_GetWindowCellWindow(CIMP_WindowCell* cell)
*   \brief Fonction retournant la CIMP_Window* de la cellule fenêtre.
* 
*   \param cell Le pointeur vers la cellule fenêtre.
*
*   \return CIMP_Window*.
*/
CIMP_Window* CIMP_GetWindowCellWindow(CIMP_WindowCell*);

/*!
*   \fn CIMP_Picture* CIMP_GetWindowCellPicture(CIMP_WindowCell* cell)
*   \brief Fonction retournant la CIMP_Picture* de la cellule fenêtre.
* 
*   \param cell Le pointeur vers la cellule fenêtre.
*
*   \return CIMP_Picture*.
*/
CIMP_Picture* CIMP_GetWindowCellPicture(CIMP_WindowCell*);

/*!
*   \fn int CIMP_WindowCellPictureExists(CIMP_WindowCell* cell)
*   \brief Fonction vérifiant si la cellule fenêtre possède une image.
* 
*   \param cell Le pointeur vers la cellule fenêtre.
*
*   \return 1 si il y a une image, sinon 0.
*/
int CIMP_WindowCellPictureExists(CIMP_WindowCell*);

/*!
*   \fn int CIMP_WindowCellAssignPicture(CIMP_WindowCell** cell, CIMP_Picture* picture)
*   \brief Fonction assignant une image à la cellule fenêtre.
* 
*   \param cell Le pointeur vers la cellule fenêtre.
*   \param picture Le pointeur vers la fenêtre.
*
*   \return 0 si pas d'erreur, sinon un entier négatif.
*/
int CIMP_WindowCellAssignPicture(CIMP_WindowCell**, CIMP_Picture*);

/*!
*   \fn void CIMP_WindowCellRemovePicture(CIMP_WindowCell** cell)
*   \brief Fonction supprimant une image à la cellule fenêtre.
* 
*   \param cell Le pointeur vers la cellule fenêtre.
*/
void CIMP_WindowCellRemovePicture(CIMP_WindowCell**);

/*!
*   \fn void CIMP_DestroyWindowCell(void** voidCell)
*   \brief Fonction libérant la mémoire occupé par la cellule fenêtre.
* 
*   \param voidCell L'adresse du pointeur vers la cellule fenêtre.
*/
void CIMP_DestroyWindowCell(void**);


#endif