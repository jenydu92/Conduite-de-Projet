#include "./graphics/CIMP_workspace.h"
#include <stdlib.h>

void initSDL();
void graphic_events_listener(SDL_Event, CIMP_Workspace*);
void window_event(SDL_Event, CIMP_Workspace*);
int FONCTION_TRAITEMENT_SURFACE(CIMP_Workspace*, size_t);


int main(void) {
    initSDL();
    
    int err = 0;

    char* path = "pictures/jazzrabbit.png";

    printf("Hello !\n");

    CIMP_Workspace* workspace = NULL;

    if ( (err = CIMP_InitWorkspace(&workspace)) < 0 ) {
        SDL_Quit();
        fprintf(stderr, "\033[31m Erreur %d InitWorkspace \033[0m \n", err);

        return EXIT_FAILURE;
    }

    if ( !CIMP_LoadPicture(&workspace, path) ) {
        CIMP_DestroyWorkspace(&workspace);
        SDL_Quit();
        fprintf(stderr, "\033[31m Erreur LoadPicture \033[0m \n");

        return EXIT_FAILURE;
    }

    if ( (err = CIMP_ShowPicture(&workspace, 1, 0)) < 0 ) {
        CIMP_DestroyWorkspace(&workspace);
        SDL_Quit();
        fprintf(stderr, "\033[31m Erreur %d ShowPicture \033[0m \n", err);

        return EXIT_FAILURE;
    }

    CIMP_Repaint(&workspace, 2);

    CIMP_PrintWindowList(&workspace);
    CIMP_PrintPictureList(&workspace);
    
    size_t pictureId = 1;


    FONCTION_TRAITEMENT_SURFACE(workspace, pictureId);


    CIMP_PrintWindowList(&workspace);
    CIMP_PrintPictureList(&workspace);

    SDL_Event ev;
    SDL_EventState(SDL_MOUSEMOTION,SDL_DISABLE);

    while (1) {
        graphic_events_listener(ev, workspace);
    }

    CIMP_DestroyWorkspace(&workspace);
    SDL_Quit();
    
    printf("Bye ! \n");


    return EXIT_SUCCESS;
}


int FONCTION_TRAITEMENT_SURFACE(CIMP_Workspace* workspace, size_t pictureId) {
    // On récupère la surface de l'image d'id "pictureId" envoyé en paramètre, 
    // qui a été saisi par l'utilisateur lors de l'appel
    CIMP_Picture* picture = NULL;
    SDL_Surface* surface = NULL;

    if (   !(picture = CIMP_GetPicture(&workspace, pictureId)) 
        || !(surface = CIMP_GetPictureSurface(picture)) )
        return 0;    


    // On modifie la surface, 
    // ici je charge simplement une autre surface
    char* path2 = "pictures/jazz2.png";
    surface = IMG_Load(path2);



    // On demande à mettre à jour la surface de l'image
    // mais aussi la fenêtre associé si elle existe
    if ( CIMP_ModifyPicture(&workspace, 1, surface) < 0 )
        return 0;

    return 1;
}





void initSDL() {
    if (SDL_Init(SDL_INIT_VIDEO) != 0) {
        fprintf(stdout, "SDL init failure (%s) \n", 
            SDL_GetError());
        exit(EXIT_FAILURE);
    }
}


/** Lit les evenements sur la fenetre
 * Prend en parametre un type SDL_Event
 * Retourne un entier correspondant a une action a executer
 */
void graphic_events_listener (SDL_Event ev, CIMP_Workspace* workspace) {

    while (SDL_PollEvent(&ev)) {
        switch(ev.type) {
            case SDL_WINDOWEVENT :
            {
                window_event(ev, workspace);
            }
            break;
        }
    } 
}


/** Gestion d un evenement de fenetre
 * Prend en parametre un type SDL_Event
 * Retourne un entier correspondant a une action a executer
 */
void window_event (SDL_Event ev, CIMP_Workspace* workspace)  {
    switch (ev.window.event) {
        case SDL_WINDOWEVENT_RESTORED :
        {
            CIMP_Repaint(&workspace, ev.window.windowID);
        }
        break;
        case SDL_WINDOWEVENT_CLOSE :
        {   
            CIMP_RemoveWindow(&workspace, ev.window.windowID);
            
            // Temporaire pour les tests
            // Coupe le programme dès qu'une fenêtre est close
            CIMP_DestroyWorkspace(&workspace);
            SDL_Quit();
            
            printf("Bye ! \n");

            exit(EXIT_SUCCESS);
        }
        break;
        case SDL_WINDOWEVENT_EXPOSED :
        {
            CIMP_Repaint(&workspace, ev.window.windowID);
        }
        break;
    }

}