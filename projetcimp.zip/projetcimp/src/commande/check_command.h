/**
 * \file        check_command.h
 * \author      T.Jennifer
 * \version     1.0
 * \date        Avril 2019
 * \brief       Définit l'interface de contrôle d'existance d'une commande de CIMP.
 *
 * \details    Ce module permet de contrôler l'existance d'une commande saisie par l'utilisateur.
 */

#ifndef _CHECK_COMMAND_H_
#define _CHECK_COMMAND_H_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

/*!
*   \typedef Command
*   \brief Objet commande.
*/
typedef struct Command Command;

/*!
*   \fn int initCommand(Command** command)
*   \brief Fonction d'initialisation de l'objet Command.
* 
*   \param command L'adresse du pointeur vers la structure Command.
*
*   \return 0 si pas d'erreur, sinon -1.
*/
int initCommand(Command**);

/*!
*   \fn char* getArgv(Command* command, int i)
*   \brief Fonction récupérant un argument de la commande.
* 
*   \param command Le pointeur vers la commande.
*   \param i Position de l'argument.
*
*   \return char* si pas d'erreur, sinon NULL.
*/
char* getArgv(Command*, int);

/*!
*   \fn int getFlag(Command* command)
*   \brief Fonction récupérant le flag.
* 
*   \param command Le pointeur vers la commande.
*
*   \return 0 si le thread doit s'arrêter, 1 sinon.
*/
int getFlag(Command*);

/*!
*   \fn int setFlag(Command* command, int flag)
*   \brief Fonction modifiant la valeur du flag.
* 
*   \param command Le pointeur vers la commande.
*   \param flag La valeur du drapeau.
*/
void setFlag(Command*, int);

/*!
*   \fn void addCommand(Command* command, char* userInput)
*   \brief Fonction traitant la chaine de caractère entré par l'utilisateur.
* 
*   \param command Le pointeur vers la commande.
*   \param userInput La chaine envoyé par l'utilisateur.
*/
void addCommand(Command*, char*);

/*!
*   \fn int commandExists(Command* command)
*   \brief Fonction vérifiant si il existe encore une commande à traiter.
* 
*   \param command Le pointeur vers la commande.
*
*   \return 1 si il y a une commande, sinon 0.
*/
int commandExists(Command*);

/*!
*   \fn void removeCommand(Command* command)
*   \brief Fonction supprimant la commande.
* 
*   \param command Le pointeur vers la commande.
*/
void removeCommand(Command*);

/*!
*   \fn int verif_cmd(Command* command)
*   \brief Fonction vérifiant si une commande existe.
* 
*   \param command Le pointeur vers la commande.
*
*   \return le code d'une commande si elle existe, sinon -1.
*/
int verif_cmd(Command*);

/*!
*   \fn void destroyCommand(Command** command)
*   \brief Fonction libérant la mémoire occupé par l'objet Command.
* 
*   \param command L'adresse du pointeur vers la commande.
*/
void destroyCommand(Command**);

int nombre(char *argv);

#endif