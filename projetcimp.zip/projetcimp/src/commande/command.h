/**
 * \file        command.h
 * \author      T.Jennifer
 * \version     1.0
 * \date        Avril 2019
 * \brief       Définit l'interface de traitement des commandes de CIMP.
 *
 * \details     Ce module contient le traitement des commandes utilisables par l'utilisateur.
 */

#ifndef _COMMAND_H_
#define _COMMAND_H_

#include <SDL2/SDL.h>
#include <stdio.h>

#include "./../graphics/CIMP_workspace.h"

#define TAILLE_MAX 512 /*!< Taille maximum d'une chaine */
#define TAILLE_CHAINE 1000 /*!< Taille d'une chaine */

/*!
*   \fn void help(char* path)
*   \brief Fonction d'affichage de l'aide.
*
*   \param path Chemin absolu où se trouve le programme.
*/
void help(char*);

/*!
*   \fn int load(CIMP_Workspace* workspace, char* path)
*   \brief Fonction de chargement de l'image.
* 
*   \param workspace L'espace de travail.
*   \param path Le chemin vers l'image.
*
*   \return 1 si pas d'erreur, sinon 0.
*/
int load(CIMP_Workspace*, char*);

/*!
*   \fn int save(CIMP_Workspace* workspace, char* idPicture_s, char* path)
*   \brief Fonction enregistrant une image.
* 
*   \param workspace L'espace de travail.
*   \param idPicture_s L'identifiant de l'image entré par l'utilisateur
*   \param path Le chemin où enregistrer l'image.
*
*   \return 1 si pas d'erreur, sinon 0.
*/
int save(CIMP_Workspace*, char*, char*) ;

/*!
*   \fn int newWindow(CIMP_Workspace* workspace)
*   \brief Fonction de création d'une fenêtre.
* 
*   \param workspace L'espace de travail.
*
*   \return 1 si pas d'erreur, sinon 0.
*/
int newWindow(CIMP_Workspace*);

/*!
*   \fn int renamePicture(CIMP_Workspace* workspace, char* idPicture_s, char* name)
*   \brief Fonction renommant l'image.
* 
*   \param workspace L'espace de travail.
*   \param idPicture_s L'identifiant de l'image entré par l'utilisateur.
*   \param name Le nouveau nom de l'image.
*
*   \return 1 si pas d'erreur, sinon 0.
*/
int renamePicture(CIMP_Workspace*, char*, char*);

/*!
*   \fn int showPicture(CIMP_Workspace* workspace, char* idPicture_s, char* idWindow_s)
*   \brief Fonction permettant d'afficher une image.
* 
*   \param workspace L'espace de travail.
*   \param idPicture_s L'identifiant de l'image entré par l'utilisateur.
*   \param idWindow_s L'identifiant de la fenêtre entré par l'utilisateur.
*
*   \return 1 si pas d'erreur, sinon 0.
*
*   Si idWindow_s vaut NULL ou "0", l'image est ouvert dans une nouvelle fenêtre.
*/
int showPicture(CIMP_Workspace*, char*, char*);

/*!
*   \fn int showWindow(CIMP_Workspace* workspace, char* idWindow_s)
*   \brief Fonction permettant de rendre visible une fenêtre.
* 
*   \param workspace L'espace de travail.
*   \param idWindow_s L'identifiant de la fenêtre entré par l'utilisateur.
*
*   \return 1 si pas d'erreur, sinon 0.
*/
int showWindow(CIMP_Workspace*, char*);

/*!
*   \fn int hidePicture(CIMP_Workspace* workspace, char* idPicture_s)
*   \brief Fonction permettant de cacher une image.
* 
*   \param workspace L'espace de travail.
*   \param idPicture_s L'identifiant de l'image entré par l'utilisateur.
*
*   \return 1 si pas d'erreur, sinon 0.
*/
int hidePicture(CIMP_Workspace*, char*);

/*!
*   \fn int hideWindow(CIMP_Workspace* workspace, char* idWindow_s)
*   \brief Fonction permettant de cacher une fenêtre.
* 
*   \param workspace L'espace de travail.
*   \param idWindow_s L'identifiant de la fenêtre entré par l'utilisateur.
*
*   \return 1 si pas d'erreur, sinon 0.
*/
int hideWindow(CIMP_Workspace*, char*);

/*!
*   \fn int deletePicture(CIMP_Workspace* workspace, char* id_s)
*   \brief Fonction d'appel de suppression d'image.
* 
*   \param workspace L'espace de travail.
*   \param id_s L'identifiant de l'image entré par l'utilisateur.
*
*   \return 1 si pas d'erreur, sinon 0.
*/
int deletePicture(CIMP_Workspace*, char*);

/*!
*   \fn int deleteWindow(CIMP_Workspace* workspace, char* id_s)
*   \brief Fonction d'appel de suppression de fenêtre.
* 
*   \param workspace L'espace de travail.
*   \param id_s L'identifiant de la fenêtre entré par l'utilisateur.
*
*   \return 1 si pas d'erreur, sinon 0.
*/
int deleteWindow(CIMP_Workspace*, char*);

/*!
*   \fn int moveView(CIMP_Workspace* workspace, char* id_s, char* x_s, char* y_s)
*   \brief Fonction déplacant la vue d'une fenêtre.
* 
*   \param workspace L'espace de travail.
*   \param id_s L'identifiant de la fenêtre entré par l'utilisateur.
*   \param x_s La position sur l'axe des abscisses entrée par l'utilisateur.
*   \param y_s La position sur l'axe des ordonnées entrée par l'utilisateur.
*
*   \return 1 si pas d'erreur, sinon 0.
*/
int moveView(CIMP_Workspace*, char*, char*, char*); 

/*!
*   \fn int resetView(CIMP_Workspace* workspace, char* id_s)
*   \brief Fonction réinitialisant la vue.
* 
*   \param workspace L'espace de travail.
*   \param id_s L'identifiant de la fenêtre entré par l'utilisateur.
*
*   \return 1 si pas d'erreur, sinon 0.
*/
int resetView(CIMP_Workspace* workspace, char* id_s);

/*!
*   \fn void listPicture(CIMP_Workspace* workspace)
*   \brief Affiche la liste des images.
* 
*   \param workspace L'espace de travail.
*/
void listPicture(CIMP_Workspace*);


/*!
*   \fn void listWindow(CIMP_Workspace* workspace)
*   \brief Affiche la liste des fenêtres.
* 
*   \param workspace L'espace de travail.
*/
void listWindow(CIMP_Workspace*);

/*!
*   \fn int transformationCouleur(CIMP_Workspace* workspace, size_t pictureId)
*   \brief Transforme en noir et blanc.
* 
*   \param workspace L'espace de travail.
*/
int transformationCouleur(CIMP_Workspace* workspace, char* transfo, size_t pictureId, int selection);


#endif
