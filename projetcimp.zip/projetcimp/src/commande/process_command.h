/**
 * \file        process_command.h
 * \author      T.Jennifer
 * \version     1.0
 * \date        Avril 2019
 * \brief       Définit l'interface d'entrée utilisateur des commandes de CIMP.
 *
 * \details    Ce module permet de contrôler le traitement des entrées utilisateurs afin de savoir si la commande est valide et quelle fonction lancer.
 */

#ifndef _PROCESS_COMMAND_H_
#define _PROCESS_COMMAND_H_

#include <SDL2/SDL.h>
#include <stdio.h>
#include <stdlib.h>
#include <SDL2/SDL2_rotozoom.h>

#include "command.h"
#include "check_command.h"
#include "../core/CIMP_config.h"
#include "../event/CIMP_eventlistener.h"
#include "../transformation/symetrie.h"
#include "../transformation/rotation.h"

#define TAILLE_MAX 512 /*!< Taille maximum d'une chaine */
#define TAILLE_CHAINE 1000 /*!< Taille d'une chaine */

/*!
*   \fn int deroulement(int argc, char** argv)
*   \brief Fonction lancant le déroulement du programme.
*
*   \param argc Le nombre d'arguments reçu
*   \param argv Les mots reçu

*   \return 1 si pas d'erreur, sinon 0.
*/
int deroulement(int, char**);

/*!
*   \fn void help()
*   \brief Fonction affichant l'aide.
*/
void help();

 #endif
