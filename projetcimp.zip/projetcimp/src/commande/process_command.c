/**
 * \file        process_command.c
 * \author      T.Jennifer
 * \version     1.0
 * \date        Avril 2019
 * \brief       Module d'entrée utilisateur des commandes de CIMP.
 *
 * \details     Ce module permet de contrôler le traitement des entrées utilisateurs afin de savoir si la commande est valide et quelle fonction lancer.
 */

#include "process_command.h"
#include <SDL2/SDL2_rotozoom.h>

#define FRAMERATE 1000/32 /*!< Calcul du framerate */

/*!
*   \fn static int read_cmd(void* data)
*   \brief Fonction permettant de récupérer l'entrée clavier de l'utilisateur.
*
*   \param data Le pointeur vers la structure commande.
*
*   \return 1 si pas d'erreur, sinon 0.
*/
static int read_cmd(void*);

/*!
*   \fn static int exec_cmd(int argc, char** argv, CIMP_Workspace** workspace, Command** command)
*   \brief Fonction permettant la commande entrée par l'utilisateur.
*
*   \param argc Le nombre d'argument envoyé
*   \param argv Les mots envoyé
*   \param workspace L'adresse du pointeur vers l'espace de travail
*   \param command L'adresse du pointeur vers la l'objet CIMP_command.
*
*   \return 1 si pas d'erreur, sinon 0.
*/
static int exec_cmd(int, char**, CIMP_Workspace**, Command**);


/*
*Deroulement de la boucle principal
*
*/
int deroulement(int argc, char** argv){
    CIMP_Config* config = NULL;
    int status;
    int again = 1;

    printf("[ProjetCimp]$ Bienvenue sur notre traitement d'image !\n");
    printf("(Ctrl+C ou exit pour quitter...)\n\n");

    CIMP_initConfig(&config, &read_cmd);

    while ( again ) {
        event_listener(config->ev, config->workspace);

        if ( commandExists(config->command) ) {
            again = exec_cmd(argc, argv, &config->workspace, &config->command);
        }

        SDL_Delay(FRAMERATE);
    }

    SDL_WaitThread(config->thread_cli, &status);
    CIMP_destroyConfig(&config);

    return (status)? EXIT_SUCCESS : EXIT_FAILURE;
}


// Execution d'une commande
static int exec_cmd(int argc, char** argv, CIMP_Workspace** workspace, Command** command) {
    switch ( verif_cmd(*command) ) {
        case 0: // #EXIT
            setFlag(*command, 0);
            return 0;
        break;
        case 1: // #HELP
            if ( argc >= 1 ) {
                help(argv[0]);
            }
        break;
        case 2: // #SELECTION
            ;
            size_t id = atoi(getArgv(*command, 1));
            CIMP_Picture* p=NULL;
            if(!(p=CIMP_GetPicture(*workspace, id))|| !(CIMP_GetPictureSurface(p))){
              return 0;
            }
            Pixels_Select* sel=CIMP_GetPictureSelection(CIMP_GetPicture(*workspace, id));
            if (selection(atoi(getArgv(*command, 2)),atoi(getArgv(*command, 3)),atoi(getArgv(*command, 4)),atoi(getArgv(*command, 5)),sel,1)==0){
              printf("erreur dans les valeurs entrées pour la selection\n");
            }

        break;
        case 3: // #COPIER
            printf("Lance la cmd copier\n");
        break;
        case 4: // #COLLER
            printf("Lance la cmd coller\n");
        break;
        case 5: // #COUPER
            printf("Lance la cmd couper\n");
        break;
        case 6: // #TRANSFORMATION
            ;
            size_t pictureId = atoi(getArgv(*command, 1));
            CIMP_Picture* pic=NULL;
            SDL_Surface* s=NULL;
            if(!(pic=CIMP_GetPicture(*workspace,pictureId ))|| !(s=CIMP_GetPictureSurface(pic))){
              return 0;
            }
            if(strcmp(getArgv(*command, 0),"Rotation")==0){
                rotation(s);
            }else if(strcmp(getArgv(*command, 0),"SymetrieV")==0){
                symetrieVerticale(s);
            }else if(strcmp(getArgv(*command, 0),"SymetrieH")==0){
                symetrieHorizontale(s);
            }else{
                //le reste
                printf("le reste\n");
                int selection = 0;
                selection = atoi(getArgv(*command, 2));
                
                size_t pictureId = atoi(getArgv(*command, 1));
                if (transformationCouleur(*workspace, getArgv(*command, 0),pictureId, selection) == 0){
                    printf("La transformation n'as pas pu être effectué\n");
                } 
            }

        break;
        case 7: // #SAUVEGARDER
            if ( save(*workspace, getArgv(*command, 1), getArgv(*command, 2)) )
                printf("\033[32m L'image a été enregistrée avec succès. \033[0m \n");
            else
                printf("\033[31m L'image n'a pas pu être enregistrée. \033[0m \n");
        break;
        case 8: // #CHARGER
            if ( load(*workspace, getArgv(*command, 1)) )
                printf("\033[32m L'image a été chargée avec succès. \033[0m \n");
            else
                printf("\033[31m L'image n'a pas pu être chargée. \033[0m \n");
        break;
        case 9: // #NOUVELLE FENETRE
            if ( newWindow(*workspace) )
                printf("\033[32m La fenêtre a été créée avec succès. \033[0m \n");
            else
                printf("\033[31m La fenêtre n'a pas pu être créée. \033[0m \n");
        break;
        case 10: // #SUPPRIMER IMAGE
            if ( deletePicture(*workspace, getArgv(*command, 2)) )
                printf("\033[32m L'image a été supprimée avec succès. \033[0m \n");
            else
                printf("\033[31m L'image n'a pas pu être supprimée. \033[0m \n");
        break;
        case 11: // #SUPPRIMER FENETRE
            if ( deleteWindow(*workspace, getArgv(*command, 2)) )
                printf("\033[32m La fenetre a été supprimée avec succès. \033[0m \n");
            else
                printf("\033[31m La fenetre n'a pas pu être supprimée. \033[0m \n");
        break;
        case 12: // #AFFICHER IMAGE
        {
            char* pictureId = getArgv(*command, 2);
            char* windowId = getArgv(*command, 3);

            if ( !windowId )
                windowId = "0";

            if ( showPicture(*workspace, pictureId, windowId) ) {
                if ( strcmp(windowId, "0") == 0 )
                    printf("\033[32m L'image %s à été assignée à une nouvelle fenêtre avec succès. \033[0m \n", pictureId);
                else
                    printf("\033[32m L'image %s à été assignée à la fenêtre %s avec succès. \033[0m \n", pictureId, windowId);
            }
            else
                printf("\033[31m L'image %s n'a pas pu etre assigné à la fenêtre %s. \033[0m \n", pictureId, windowId);
        }
        break;
        case 13: // #LISTER IMAGE
            listPicture(*workspace);
        break;
        case 14: // #LISTER FENETRE
            listWindow(*workspace);
        break;
        case 15: // #RENOMME UNE IMAGE
            if ( renamePicture(*workspace, getArgv(*command, 2), getArgv(*command, 3)) )
                printf("\033[32m L'image a été renommée avec succès. \033[0m \n");
            else
                printf("\033[31m L'image n'a pas pu être renommée. \033[0m \n");
        break;
        case 16: // #CACHER UNE IMAGE
            if ( hidePicture(*workspace, getArgv(*command, 2)) )
                printf("\033[32m L'image a été cachée avec succès. \033[0m \n");
            else
                printf("\033[31m L'image n'a pas pu être cachée. \033[0m \n");
        break;
        case 17: // #CACHER UNE FENETRE
            if ( hideWindow(*workspace, getArgv(*command, 2)) )
                printf("\033[32m La fenetre a été cachée avec succès. \033[0m \n");
            else
                printf("\033[31m La fenetre n'a pas pu être caché. \033[0m \n");
        break;
        case 18: // #AFFICHER UNE FENETRE
            if ( showWindow(*workspace, getArgv(*command, 2)) )
                printf("\033[32m La fenetre a été affichée avec succès. \033[0m \n");
            else
                printf("\033[31m La fenetre n'a pas pu être affichée. \033[0m \n");
        break;
        case 19: // #DEPLACER LA VUE
            if ( moveView(*workspace, getArgv(*command, 2), getArgv(*command, 3), getArgv(*command, 4)) )
                printf("\033[32m La vue de la fenêtre %s a été déplacée avec succès. \033[0m \n", getArgv(*command, 2));
            else
                printf("\033[31m La vue de la fenêtre %s n'a pas pu être déplacée. \033[0m \n", getArgv(*command, 2));
        break;
        case 20: // #REINITIALISER LA VUE
            if ( resetView(*workspace, getArgv(*command, 2)) )
                printf("\033[32m La vue de la fenêtre %s a été réinitialisée avec succès. \033[0m \n", getArgv(*command, 2));
            else
                printf("\033[31m La vue de la fenêtre %s n'a pas pu être réinitialisée. \033[0m \n", getArgv(*command, 2));
        break;
        default:
            printf("\033[31m Votre commande n'est pas correct \033[0m \n");
            printf("\033[31m Taper Help pour afficher la liste des commandes disponibles \033[0m \n");
    }

    removeCommand(*command);

    return 1;
}


// Boucle d'entrée clavier de l'utilisateur
static int read_cmd(void* data) {
    Command** command = (Command**)data;
    char* userInput = NULL;


    if ( ! (userInput = (char*)malloc(TAILLE_MAX*sizeof(char))) ) {
        fprintf(stderr, "\033[31;1m Erreur rencontré lors de l'allocation mémoire de l'entrée utilisateur \033[0m\n");

        return 0;
    }


    while ( getFlag(*command) ) {
        if ( !(commandExists(*command)) ) {
            printf("[ProjetCimp]$ ");
            userInput = fgets (userInput, TAILLE_MAX, stdin);

            addCommand(*command, userInput);
        }

        SDL_Delay(FRAMERATE);
    }

    free(userInput);

    return 1;
}
