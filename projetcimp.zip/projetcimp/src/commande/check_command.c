/**
 * \file        check_command.c
 * \author      T.Jennifer
 * \version     1.0
 * \date        Avril 2019
 * \brief       Module de contrôle d'existance d'une commande de CIMP.
 *
 * \details    Ce module permet de contrôler l'existance d'une commande saisie par l'utilisateur.
 */
 
#include "check_command.h"

#define NBRE_COMMANDE 15 /*!< Nombre maximum de mot dans une commande */
#define TAILLE_MAX 512 /*!< Taille maximum d'une chaine */

/*!
*   \struct Command
*   \brief Objet commande.
* 
*   Command correspond à une commande entrée par l'utilisateur.
*   Une commande contient les adresses des mots entrée par l'utilisateur
*   de type char* et le nombre de mots entrée.
*/
struct Command {
    char** argv; /*!< Adresses des mots */
    int argc; /*!< Nombre de mots */
    int flag; /*!< Indique si le thread doit mourrir */
};


// Initialise l'objet Command
int initCommand(Command** command) {
    *command = NULL;

    if ( !(*command = (Command*)malloc(sizeof(Command))) ) {
        fprintf(stderr, "\033[31;1m Erreur rencontré lors de l'allocation mémoire de Command \033[0m \n");
        
        return -1;
    }


    (*command)->argv = NULL;


    if ( !((*command)->argv =  (char**)malloc(NBRE_COMMANDE * sizeof(char*)) ) ) {
        fprintf(stderr, "\033[31;1m Erreur rencontré lors de l'allocation mémoire de Command \033[0m \n");
        
        free(*command);
        *command = NULL;

        return -1;
    }

    for (int i = 0; i < NBRE_COMMANDE; i++) {
        if ( !((*command)->argv[i] =  (char*)malloc(TAILLE_MAX * sizeof(char)) ) ) {
            fprintf(stderr, "\033[31;1m Erreur rencontré lors de l'allocation mémoire de Command \033[0m \n");
            
            for (int j = 0; j < i-1; j++) {
                free((*command)->argv[j]);
                (*command)->argv[j] = NULL;
            }

            free((*command)->argv);
            (*command)->argv = NULL;

            free(*command);
            *command = NULL;

            return -1;
        }

        memset((*command)->argv[i], '\0', ( TAILLE_MAX * sizeof(char) ));
    }

    (*command)->argc = 0;
    (*command)->flag = 1;

    return 0;
}


// Récupère une partie de la commande
char* getArgv(Command* command, int i) {
    if ( i < 0 || i > (command->argc - 1) )
    	return NULL;

    return command->argv[i];
}


// Récupère le flag
int getFlag(Command* command) {
    return command->flag;
}


// Modifie le flag
void setFlag(Command* command, int flag) {
    command->flag = flag;
}


// Ajoute la commande
void addCommand(Command* command, char* userInput) {
    int i; 
    int deb; 

    if( command->argc != 0)
    	removeCommand(command);

    deb = -1; 
    i = 0;

    while(userInput[i] != '\n'){
        switch(userInput[i]){
            case 9 : // Caractère tabulation
            case ' ' : 
                if ( deb != -1 && (i - deb) < TAILLE_MAX ) {
                    memcpy(command->argv[command->argc], (userInput+deb), (i - deb));
                    strcat(command->argv[command->argc], "\0");
                    
                    (command->argc)++;
                    deb = -1;
                } 
            break; 
            default :
            if ( deb == -1 )
                deb = i;
        } 
        i++; 
    }

    if ( i != deb && (i - deb) < TAILLE_MAX) {
        memcpy(command->argv[command->argc], (userInput+deb), (i - deb));
        strcat(command->argv[command->argc], "\0");
        (command->argc)++;
    }
}


// Vérifie si il reste une commande à traiter
int commandExists(Command* command) {
    return (command->argc > 0)? 1 : 0;
}
 
// Supprime la commande
void removeCommand(Command* command) {

    for (int i = 0; i < NBRE_COMMANDE; i++) {        
        memset(command->argv[i], '\0', ( TAILLE_MAX * sizeof(char) ));        
    }

    command->argc = 0;
}


/*
*Fonction qui vérifie l'existence des commandes appeller
*Ainsi que les parametres necessaires aux cmd
*/
int verif_cmd(Command* command){
	char** argv = command->argv;
	int argc = command->argc;

	if(strcmp(argv[0], "Help") == 0){
		return 1;
	}else if(strcmp(argv[0], "Selection") == 0){
        if((argc > 5) && (atoi(argv[1]) >0)){
            if ((nombre(argv[1]) == 0) && (nombre(argv[2]) == 0) && (nombre(argv[3]) == 0) && (nombre(argv[4]) == 0) && (nombre(argv[5]) == 0) ){
                return 2;
            }       
        }
	}else if(strcmp(argv[0], "Copier") == 0){
		return 3;
	}else if(strcmp(argv[0], "Coller") == 0){
		return 4;
	}else if(strcmp(argv[0], "Couper") == 0){
		return 5;
	}else if(strcmp(argv[0],"Noir")==0 || strcmp(argv[0],"Gris")==0 || strcmp(argv[0],"Negatif")==0 || strcmp(argv[0],"Couleur")==0 || strcmp(argv[0],"Rotation")==0 || strcmp(argv[0],"SymetrieH")==0 || strcmp(argv[0],"SymetrieV")==0 || strcmp(argv[0],"RemplaceCouleur")==0){
        if((atoi(argv[1]) >0) && (argc > 2) && (atoi(argv[2]) == 0 || atoi(argv[2]) == 1 )){
            printf("return\n");
            return 6;
        }
	}else if(argc == 3 && strcmp(argv[0], "Sauvegarder") == 0){
		return 7;
	}else if(argc == 2 && strcmp(argv[0], "Charger") == 0){
		return 8;	
	}else if(argc == 2 && strcmp(argv[0], "Nouvelle") == 0 && strcmp(argv[1], "fenetre") == 0){
    	return 9;  
    }else if(argc == 3 && strcmp(argv[0], "Supprimer") == 0){
        if (strcmp(argv[1], "image") == 0){
            return 10;
        }else if(strcmp(argv[1], "fenetre") == 0){
            return 11;
        }
    }else if(strcmp(argv[0], "Afficher") == 0){
        if ( (argc == 3 || argc == 4) && strcmp(argv[1], "image") == 0){
            return 12;
        }else if(argc == 3 && strcmp(argv[1], "fenetre") == 0){
            return 18;
        }
    }else if(argc == 2 && strcmp(argv[0], "Lister") == 0){
        if (strcmp(argv[1], "image") == 0){
            return 13; 
        }else if(strcmp(argv[1], "fenetre") == 0){
            return 14;
        }
    }else if(argc == 4 && strcmp(argv[0], "Renommer") == 0 && strcmp(argv[1], "image") == 0){
            return 15; 
    }else if(argc == 3 && strcmp(argv[0], "Cacher") == 0){
        if (strcmp(argv[1], "image") == 0){
            return 16; 
        }else if(strcmp(argv[1], "fenetre") == 0){
            return 17;
        }
    }else if(argc == 5 && strcmp(argv[0], "Deplacer") == 0 && strcmp(argv[1], "vue") == 0){
            return 19; 
    }else if(argc == 3 && strcmp(argv[0], "Reinitialiser") == 0 && strcmp(argv[1], "vue") == 0){
            return 20; 
    }else if(strcmp(argv[0], "exit") == 0){
		return 0;
	}

	return -1;
}


// Libère la mémoire occupé par l'objet Command
void destroyCommand(Command** command) {
	if ( (*command)->argv ) {  
		
        for (int i = 0; i < NBRE_COMMANDE; i++) {
            if ( (*command)->argv[i] ) {
                free((*command)->argv[i]);
                (*command)->argv[i] = NULL;
            }
        }

        free((*command)->argv);
        (*command)->argv = NULL;
    }
    if ( *command) {
        free(*command);
        *command = NULL;
    }
}

int nombre(char *argv){
    int length = strlen(argv);
    for (int i = 0; i < length ; i++){
        if(isdigit(argv[i])==0){
            return -1;
        }
    }return 0;
}
