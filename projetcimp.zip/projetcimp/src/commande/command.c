/**
 * \file        command.c
 * \author      T.Jennifer
 * \version     1.0
 * \date        Avril 2019
 * \brief       Module de traitement des commandes de CIMP.
 *
 * \details    Ce module contient le traitement des commandes utilisables par l'utilisateur.
 */

#include "command.h"
#include "../util/select.c"

/*
*Lit le fichier help.txt
*Contient toutes les commandes autorisees de notre programme.
*/
void help(char* pathExec){
    static char* fullPath = NULL;

    if ( !fullPath ) {
        char* path = CIMP_GetDirname(pathExec);
        char* dir = "/commande/";
        char* filename = "help.txt";
        int pathSize = (strlen(path) + strlen(dir) + strlen(path) );

        if ( !(fullPath = (malloc( (pathSize + 1) * sizeof(char)) )) ) {
            printf("\033[31;1m Impossible de récupérer le chemin vers l'aide. \033[0m \n");

            free(path);
            path = NULL;

            return;
        }


        memset(fullPath, '\0', ( pathSize + 1));
        strncpy(fullPath, path, strlen(path));
        strncat(fullPath, dir, strlen(dir));
        strncat(fullPath, filename, strlen(filename));

        free(path);
        path = NULL;
    }

    FILE* fichier = NULL;
    char chaine[TAILLE_MAX] = "";

    fichier = fopen(fullPath, "r");

    if (fichier != NULL){
        while (fgets(chaine, TAILLE_CHAINE, fichier) != NULL) {
            printf("%s", chaine);
        }
        fclose(fichier);
    }printf("\n");
}


// Permet de charger une image
int load(CIMP_Workspace* workspace, char* path) {
    if ( !CIMP_LoadPicture(workspace, path) )
        return 0;

    return 1;
}

int save(CIMP_Workspace* workspace, char* idPicture_s, char* path) {
    int err;
    size_t pictureId;


    if ( !stringToSize_t(idPicture_s, &pictureId) ) {
        printf("\033[33m Argument invalide. \n Un entier positif est attendu. \033[0m \n");

        return 0;
    }

    if ( (err = CIMP_SavePicture(workspace, pictureId, path)) < 0 ) {
        switch ( err ) {
            case -1:
            {
                printf("\033[33m Mauvais identifiants. \033[0m\n");
            }
            break;
            case -2:
            {
                printf("\033[31;1m Erreur, l'image n'a pas de surface. \033[0m\n");
            }
            break;
            case -3:
            {
                printf("\033[33m Chemin incorrect. \033[0m\n");
            }
            break;
            case -5:
            {
                printf("\033[33m Nom de fichier incorrect. \033[0m\n");
            }
            break;
            case -6:
            {
                printf("\033[33m Format non pris en charge. \033[0m\n");
            }
            break;
            default:
                printf("\033[33m Echec de l'enregistrement. \033[0m\n");
        }

        return 0;
    }


    return 1;
}


// Permet de créer une nouvelle fenêtre
int newWindow(CIMP_Workspace* workspace) {
    if ( !(CIMP_OpenWindow(workspace)) )
        return 0;

    return 1;
}


// Permet de renommer l'image
int renamePicture(CIMP_Workspace* workspace, char* idPicture_s, char* name) {
    size_t pictureId;


    if ( !stringToSize_t(idPicture_s, &pictureId) ) {
        printf("\033[33m Argument invalide. \n Un entier positif est attendu. \033[0m \n");

        return 0;
    }

    if ( CIMP_RenamePicture(workspace, pictureId, name) < 0 ) {
        printf("\033[33m Mauvais identifiants. \033[0m\n");

        return 0;
    }


    return 1;
}


// Permet de voir l'image dans une fenêtre
int showPicture(CIMP_Workspace* workspace, char* idPicture_s, char* idWindow_s) {
    int err;
    size_t pictureId, windowId;


    if ( !stringToSize_t(idPicture_s, &pictureId) || !stringToSize_t(idWindow_s, &windowId)) {
        printf("\033[33m Argument invalide. \n Un entier positif est attendu. \033[0m \n");

        return 0;
    }

    if ( (err = CIMP_DisplayPicture(workspace, pictureId, windowId)) < 0 ) {
        switch ( err ) {
            case -1:
            {
                printf("\033[33m Mauvais identifiants. \033[0m\n");
            }
            break;
        }

        return 0;
    }


    return 1;
}


// Permet de rendre visible une fenêtre
int showWindow(CIMP_Workspace* workspace, char* idWindow_s) {
    size_t windowId;


    if ( !stringToSize_t(idWindow_s, &windowId) ) {
        printf("\033[33m Argument invalide. \n Un entier positif est attendu. \033[0m \n");

        return 0;
    }

    if ( CIMP_DisplayWindow(workspace, windowId) < 0 ) {
        printf("\033[33m Mauvais identifiants. \033[0m\n");

        return 0;
    }


    return 1;
}


// Permet de cacher une image
int hidePicture(CIMP_Workspace* workspace, char* idPicture_s) {
    size_t pictureId;


    if ( !stringToSize_t(idPicture_s, &pictureId) ) {
        printf("\033[33m Argument invalide. \n Un entier positif est attendu. \033[0m \n");

        return 0;
    }

    if ( CIMP_MaskPicture(workspace, pictureId) < 0 ) {
        printf("\033[33m Mauvais identifiants. \033[0m\n");

        return 0;
    }


    return 1;
}


// Permet de cacher une fenetre
int hideWindow(CIMP_Workspace* workspace, char* idWindow_s) {
    size_t windowId;


    if ( !stringToSize_t(idWindow_s, &windowId) ) {
        printf("\033[33m Argument invalide. \n Un entier positif est attendu. \033[0m \n");

        return 0;
    }

    if ( CIMP_MaskWindow(workspace, windowId) < 0 ) {
        printf("\033[33m Mauvais identifiants. \033[0m\n");

        return 0;
    }


    return 1;
}


// Permet de supprimer une image
int deletePicture(CIMP_Workspace* workspace, char* id_s) {
    size_t pictureId;

    if ( !stringToSize_t(id_s, &pictureId) ) {
        printf("\033[33m Argument invalide. \n Un entier positif est attendu. \033[0m \n");

        return 0;
    }


    if ( CIMP_RemovePicture(workspace, pictureId) < 0 )
        return 0;


    return 1;
}


// Permet de supprimer une fenêtre
int deleteWindow(CIMP_Workspace* workspace, char* id_s) {
    size_t windowId;

    if ( !stringToSize_t(id_s, &windowId)) {
        printf("\033[33m Argument invalide. \n Un entier positif est attendu. \033[0m \n");

        return 0;
    }


    if ( CIMP_RemoveWindow(workspace, windowId) < 0 )
        return 0;


    return 1;
}


// Permet de déplacer la vue
int moveView(CIMP_Workspace* workspace, char* id_s, char* x_s, char* y_s) {
    size_t windowId, x, y;

    if ( !stringToSize_t(id_s, &windowId) || !stringToSize_t(x_s, &x) || !stringToSize_t(y_s, &y) ) {
        printf("\033[33m Argument invalide. \n Un entier positif est attendu. \033[0m \n");

        return 0;
    }


    if ( CIMP_MoveView(workspace, windowId, (x*-1), (y*-1)) < 0 )
        return 0;

    CIMP_Repaint(workspace, windowId);

    return 1;
}


// Permet de réinitialiser la vue
int resetView(CIMP_Workspace* workspace, char* id_s) {
    size_t windowId;

    if ( !stringToSize_t(id_s, &windowId) ) {
        printf("\033[33m Argument invalide. \n Un entier positif est attendu. \033[0m \n");

        return 0;
    }


    if ( CIMP_MoveView(workspace, windowId, 0, 0) < 0 )
        return 0;

    CIMP_Repaint(workspace, windowId);

    return 1;
}


// Permet de lister les images
void listPicture(CIMP_Workspace* workspace) {
    CIMP_PrintPictureList(workspace);
}


// Permet de lister les fenêtres
void listWindow(CIMP_Workspace* workspace) {
    CIMP_PrintWindowList(workspace);
}


// Permet d'obtenir un pixel d'une surface
static Uint32 getPixel(SDL_Surface *surface, int x, int y) {
    int bpp = surface->format->BytesPerPixel;
    Uint8 *p = (Uint8 *)surface->pixels + y * surface->pitch + x * bpp;

    switch(bpp)
    {
        case 1:
            return *p;
        case 2:
            return *(Uint16 *)p;
        case 3:
            if(SDL_BYTEORDER == SDL_BIG_ENDIAN)
                return p[0] << 16 | p[1] << 8 | p[2];
            else
                return p[0] | p[1] << 8 | p[2] << 16;
        case 4:
            return *(Uint32 *)p;
        default:
            return 0;
    }
}

// Permet de redéfinir un pixel d'une surface par un autre pixel
static void setPixel(SDL_Surface *surface, int x, int y, Uint32 pixel) {
    int bpp = surface->format->BytesPerPixel;
    Uint8 *p = (Uint8 *)surface->pixels + y * surface->pitch + x * bpp;

    switch(bpp)
    {
        case 1:
            *p = pixel;
            break;
        case 2:
            *(Uint16 *)p = pixel;
            break;
        case 3:
            if(SDL_BYTEORDER == SDL_BIG_ENDIAN)
            {
                p[0] = (pixel >> 16) & 0xff;
                p[1] = (pixel >> 8) & 0xff;
                p[2] = pixel & 0xff;
            }
            else
            {
                p[0] = pixel & 0xff;
                p[1] = (pixel >> 8) & 0xff;
                p[2] = (pixel >> 16) & 0xff;
            }
            break;
        case 4:
            *(Uint32 *)p = pixel;
            break;
    }
}

// Convertit un entier au format d'une couleur SDL
static Uint8 int2color(int value) {
    if ( value > 255 )
        value = 255;
    else if ( value < 0 )
        value = 0;

    return (Uint8)value;
}

// Noir/Gris/Negatif/Couleur idImage selection *******************************************************
int transformationCouleur(CIMP_Workspace* workspace, char* transfo, size_t pictureId, int selection) {
    printf("iciici\n");
    Uint8 r, g, b, a;
    Uint8 rc=0, gc=0, bc=0; //Stock la couleur donnée
    Uint8 rcr=0, gcr=0, bcr=0; //Stock la couleur a remplacer

    if(strcmp(transfo, "Couleur") == 0 || strcmp(transfo, "RemplaceCouleur") == 0){ //Récupère la couleur voulut
        printf("ici\n");
        int recup = 0;// nombre de couleur récupéré
        int ri, gi, bi;
        printf("On récupère les valeurs de r, g, b correspondant a la couleur souhaité.\n");
        while(recup < 3){
            printf("Entrez un nombre entre 0 et 255, ");
            if(recup == 0){
                printf("valeur de r :\n");
                scanf("%d", &ri);
                if(ri <256 && ri >= 0){
                    rc = /*(Uint8)*/ri;
                    recup++;
                }
            }else if(recup == 1){
                printf("valeur de g :\n");
                scanf("%d", &gi);
                if(gi <256 && gi >= 0){
                    gc = /*(Uint8)*/gi;
                    recup++;
                }
            }else if(recup == 2){
                printf("valeur de b :\n");
                scanf("%d", &bi);
                if(bi <256 && bi >= 0){
                    bc = /*(Uint8)*/bi;
                    recup++;
                }
            }
        }
    }if(strcmp(transfo, "RemplaceCouleur") == 0){ //Récupère la couleur a changer
        printf("la\n");
        int recup = 0;// nombre de couleur récupéré
        int ri, gi, bi;
        printf("On récupère les valeurs de r, g, b correspondant a la couleur a remplacer.\n");
        while(recup < 3){
            printf("Entrez un nombre entre 0 et 255, ");
            if(recup == 0){
                printf("valeur de r :\n");
                scanf("%d", &ri);
                if(ri <256 && ri >= 0){
                    rcr = /*(Uint8)*/ri;
                    recup++;
                }
            }else if(recup == 1){
                printf("valeur de g :\n");
                scanf("%d", &gi);
                if(gi <256 && gi >= 0){
                    gcr = /*(Uint8)*/gi;
                    recup++;
                }
            }else if(recup == 2){
                printf("valeur de b :\n");
                scanf("%d", &bi);
                if(bi <256 && bi >= 0){
                    bcr = /*(Uint8)*/bi;
                    recup++;
                }
            }
        }
    }

    // On récupère la surface de l'image d'id "pictureId" envoyé en paramètre,
    // qui a été saisi par l'utilisateur lors de l'appel
    CIMP_Picture* picture = NULL;
    SDL_Surface* surface = NULL;
    Pixels_Select* sel = CIMP_GetPictureSelection(CIMP_GetPicture(workspace, pictureId));

    if (   !(picture = CIMP_GetPicture(workspace, pictureId))
      || !(surface = CIMP_GetPictureSurface(picture)) )
      return 0;

    SDL_SetSurfaceRLE(surface, 1);

    if(SDL_LockSurface(surface) < 0){
        fprintf(stderr, "Erreur SDL_LockSurface : %s", SDL_GetError());
        return 0;
    }

    // Uint32* pixels = surface->pixels;
    Uint32 pixel;

    // On modifie la surface
    for(int i = 0; i < surface->h; i++){
        for(int j = 0; j < surface->w; j++){
            pixel = getPixel(surface, j, i);

            SDL_GetRGBA(pixel, surface->format, &r, &g, &b, &a);

            Uint8 gris = int2color((int)((r + g + b) / 3));

            if((sel->pixels[i*surface->w+j] == 1) || (selection == 0) ){//Si le pixel est selectionner ou si on ne veut pas de selection
                //printf("Dans un pixel selectionné\n");
                if(strcmp(transfo, "Noir") == 0){//Noir et blanc
                    if(gris < 50 ){
                        gris = 0;
                    }else{
                        gris = 255;
                    }
                    pixel = SDL_MapRGBA(surface->format, gris, gris, gris, a);
                }
                else if(strcmp(transfo, "Gris") == 0){ //Niveau de gris
                    pixel = SDL_MapRGBA(surface->format, gris, gris, gris, a);
                }
                else if(strcmp(transfo, "Negatif") == 0){ //Négatif
                    pixel = SDL_MapRGB(surface->format, int2color((int)(255 - r)), int2color((int)(255 - g)), int2color((int)(255 - b)));
                }
                else if(strcmp(transfo, "Couleur") == 0){//CouleurDonnée
                    pixel = SDL_MapRGB(surface->format, rc, gc, bc);
                }else if(strcmp(transfo, "RemplaceCouleur") == 0){//CouleurDonnée
                    if((r == rcr) && (g == gcr) && (b == bcr)){
                        pixel = SDL_MapRGB(surface->format, rc, gc, bc);
                    }  
                }
                else
                    return 0;
            }
            setPixel(surface, j, i, pixel);
        }
    }

    SDL_UnlockSurface(surface);
    SDL_SetSurfaceRLE(surface, 0);

    // On demande à mettre à jour la surface de l'image
    // mais aussi la fenêtre associé si elle existe
    if ( CIMP_ModifyPicture(workspace, pictureId, surface) < 0 )
        return 0;

    size_t windowId = CIMP_GetPictureAssocId(workspace, pictureId);

    if(windowId !=0)
        CIMP_Repaint(workspace, windowId);

    return 1;
}
