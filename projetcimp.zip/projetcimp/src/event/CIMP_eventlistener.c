/**
 * \file        CIMP_eventlistener.c
 * \author      C.Cedric
 * \version     1.0
 * \date        Avril 2019
 * \brief       Module d'écoute des évènements.
 *
 * \details     Ce module permet d'écouter les évènements et de rediriger vers le module gérant ce type d'évènement.
 */

#include "CIMP_eventlistener.h"

// Lit les evenements
void event_listener (SDL_Event ev, CIMP_Workspace* workspace) {

    while ( SDL_PollEvent(&ev) ) {
        switch(ev.type) {
            case SDL_WINDOWEVENT :
            {
                window_event(ev, workspace);
            }
            break;
            case SDL_KEYDOWN :
            {
                keyboard_event(ev, workspace);
            }
            break;
        }
    }

}
