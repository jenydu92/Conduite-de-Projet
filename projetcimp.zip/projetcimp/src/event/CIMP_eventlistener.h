/**
 * \file        CIMP_eventlistener.h
 * \author      C.Cedric
 * \version     1.0
 * \date        Avril 2019
 * \brief       Définit l'interface d'écoute des évènements.
 *
 * \details     Ce module permet d'écouter les évènements et de rediriger vers le module gérant ce type d'évènement.
 */

#ifndef _CIMP_EVENTLISTENER_H_
#define _CIMP_EVENTLISTENER_H_

#include <SDL2/SDL.h>
#include "CIMP_windowevent.h"
#include "CIMP_keyboardevent.h"
#include "../graphics/CIMP_workspace.h"


/*!
*   \fn void event_listener (SDL_Event ev, CIMP_Workspace* workspace)
*   \brief Fonction permettant d'écouter les évènements.
* 
*   \param ev La SDL_Event stockant les évènements survenu non encore traité.
*   \param workspace Le pointeur vers l'espace de travail
*/
void event_listener (SDL_Event, CIMP_Workspace*);

#endif
