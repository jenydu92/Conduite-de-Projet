/**
 * \file        CIMP_keyboardevent.h
 * \author      C.Cedric
 * \version     1.0
 * \date        Avril 2019
 * \brief       Définit l'interface de gestions des évènements clavier.
 *
 * \details     Ce module permet la gestions des évènements provenant du clavier.
 */

#ifndef _CIMP_KEYBOARDEVENT_H_
#define _CIMP_KEYBOARDEVENT_H_

#include <SDL2/SDL.h>
#include "../graphics/CIMP_workspace.h"


/*!
*   \fn void keyboard_event (SDL_Event ev, CIMP_Workspace* workspace) 
*   \brief Fonction permettant d'effectuer une tâche selon un évènement clavier.
* 
*   \param ev La SDL_Event stockant les évènements survenu non encore traité.
*   \param workspace Le pointeur vers l'espace de travail
*/
void keyboard_event (SDL_Event, CIMP_Workspace*);

#endif
