/**
 * \file        CIMP_windowevent.h
 * \author      C.Cedric
 * \version     1.0
 * \date        Avril 2019
 * \brief       Définit l'interface de gestions des évènements sur fenêtre.
 *
 * \details     Ce module permet la gestions des évènements spécifique à la fenêtre.
 */

#ifndef _CIMP_WINDOWEVENT_H_
#define _CIMP_WINDOWEVENT_H_

#include <SDL2/SDL.h>
#include "../graphics/CIMP_workspace.h"


/*!
*   \fn void window_event (SDL_Event ev, CIMP_Workspace* workspace) 
*   \brief Fonction permettant d'effectuer une tâche selon un évènement de fenêtre.
* 
*   \param ev La SDL_Event stockant les évènements survenu non encore traité.
*   \param workspace Le pointeur vers l'espace de travail
*/
void window_event (SDL_Event, CIMP_Workspace*);

#endif
