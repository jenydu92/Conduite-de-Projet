/**
 * \file        CIMP_windowevent.c
 * \author      C.Cedric
 * \version     1.0
 * \date        Avril 2019
 * \brief       Module de gestions des évènements sur fenêtre.
 *
 * \details     Ce module permet la gestions des évènements spécifique à la fenêtre.
 */

#include "CIMP_windowevent.h"

/** Gestion d un evenement de fenetre
 * Prend en parametre un type SDL_Event
 * Retourne un entier correspondant a une action a executer
 */
void window_event (SDL_Event ev, CIMP_Workspace* workspace)  {
    switch (ev.window.event) {
        case SDL_WINDOWEVENT_RESTORED :
        {
            CIMP_Repaint(workspace, ev.window.windowID);
        }
        break;
        case SDL_WINDOWEVENT_CLOSE :
        {   
            CIMP_RemoveWindow(workspace, ev.window.windowID);
        }
        break;
        case SDL_WINDOWEVENT_EXPOSED :
        {
            CIMP_Repaint(workspace, ev.window.windowID);
        }
        break;
    }

}