/**
 * \file        CIMP_keyboardevent.c
 * \author      C.Cedric
 * \version     1.0
 * \date        Avril 2019
 * \brief       Module de gestions des évènements clavier.
 *
 * \details     Ce module permet la gestions des évènements provenant du clavier.
 */

#include "CIMP_keyboardevent.h"

#define MVT_SIZE 5 /*!< Taille d'un pas en nombre de pixel pour un déplacement */

void keyboard_event (SDL_Event ev, CIMP_Workspace* workspace)  {
    switch (ev.key.keysym.sym) {
        case SDLK_UP : 
        {   
            CIMP_IncrementalMoveView (workspace, ev.window.windowID, 0, -MVT_SIZE);
            CIMP_Repaint(workspace, ev.window.windowID);
        }
        break;
        case SDLK_DOWN :
        { 
            CIMP_IncrementalMoveView (workspace, ev.window.windowID, 0, MVT_SIZE);
            CIMP_Repaint(workspace, ev.window.windowID);
        }
        break;
        case SDLK_RIGHT : 
        {
            CIMP_IncrementalMoveView (workspace, ev.window.windowID, MVT_SIZE, 0);
            CIMP_Repaint(workspace, ev.window.windowID);
        }
        break;
        case SDLK_LEFT : 
        {
            CIMP_IncrementalMoveView (workspace, ev.window.windowID, -MVT_SIZE, 0);
            CIMP_Repaint(workspace, ev.window.windowID);
        }
        break;
    }

}