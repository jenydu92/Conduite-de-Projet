var NAVTREE =
[
  [ "CIMP", "index.html", [
    [ "Documentation de CIMP", "index.html", [
      [ "Introduction", "index.html#intro_sec", null ],
      [ "Installation", "index.html#install_sec", [
        [ "Librairie nécéssaire", "index.html#libs_subsec", null ],
        [ "Lancer le programme", "index.html#launch", null ]
      ] ]
    ] ],
    [ "Librairie gérant l'interface graphique du projet", "md_graphics_README.html", null ],
    [ "CODE SOURCE DU PROJET", "md_README.html", null ],
    [ "Librairie utilitaire", "md_util_README.html", null ],
    [ "Structures de données", "annotated.html", [
      [ "Structures de données", "annotated.html", "annotated_dup" ],
      [ "Index des structures de données", "classes.html", null ],
      [ "Champs de donnée", "functions.html", [
        [ "Tout", "functions.html", null ],
        [ "Variables", "functions_vars.html", null ]
      ] ]
    ] ],
    [ "Fichiers", null, [
      [ "Liste des fichiers", "files.html", "files" ],
      [ "Variables globale", "globals.html", [
        [ "Tout", "globals.html", "globals_dup" ],
        [ "Fonctions", "globals_func.html", "globals_func" ],
        [ "Définitions de type", "globals_type.html", null ],
        [ "Macros", "globals_defs.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"CIMP__bmpfile_8c.html",
"check__command_8h.html#a579ac05a201cf1b7297769798ee801fc"
];

var SYNCONMSG = 'cliquez pour désactiver la synchronisation du panel';
var SYNCOFFMSG = 'cliquez pour activer la synchronisation du panel';