var CIMP__windowmanager_8c =
[
    [ "CIMP_WindowCell", "structCIMP__WindowCell.html", "structCIMP__WindowCell" ],
    [ "CIMP_CreateWindowCell", "CIMP__windowmanager_8c.html#a2c27ad36b03ce8ba5cf1c9f205db11be", null ],
    [ "CIMP_DestroyWindowCell", "CIMP__windowmanager_8c.html#a9f1add3a35f4029b02cc202b5ee529a3", null ],
    [ "CIMP_GetWindowCellPicture", "CIMP__windowmanager_8c.html#affc4d1ada1e4e6a58ca3a384d5cb9f9a", null ],
    [ "CIMP_GetWindowCellWindow", "CIMP__windowmanager_8c.html#a941fd07e43570974df092db12bf5006a", null ],
    [ "CIMP_WindowCellAssignPicture", "CIMP__windowmanager_8c.html#a8b2cb5479770fc27aeb4d336950fec7c", null ],
    [ "CIMP_WindowCellPictureExists", "CIMP__windowmanager_8c.html#a5b5563a2817e77e22f44005b39a8cc66", null ],
    [ "CIMP_WindowCellRemovePicture", "CIMP__windowmanager_8c.html#a0f71f4635b75ef5412d228ecd74155ce", null ]
];