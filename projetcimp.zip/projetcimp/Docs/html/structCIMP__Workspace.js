var structCIMP__Workspace =
[
    [ "lastPictureId", "structCIMP__Workspace.html#a65aa143889efc974a865b6da87c11492", null ],
    [ "pictureList", "structCIMP__Workspace.html#a7234a068267fe6702bca9754fecdd685", null ],
    [ "windowList", "structCIMP__Workspace.html#aca167850893dc839bad59b86f977fbc3", null ]
];