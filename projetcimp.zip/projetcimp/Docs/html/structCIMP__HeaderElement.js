var structCIMP__HeaderElement =
[
    [ "length", "structCIMP__HeaderElement.html#a6e8ae63bc91f9ee43cc1e343f6f360e9", null ],
    [ "sizeOfEl", "structCIMP__HeaderElement.html#a6bdf87348ad81e284ab03e311ff0ade3", null ]
];