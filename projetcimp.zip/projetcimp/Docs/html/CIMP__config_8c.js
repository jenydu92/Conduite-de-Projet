var CIMP__config_8c =
[
    [ "CIMP_destroyConfig", "CIMP__config_8c.html#a9672d77478158f46ed444dc5a50a7e90", null ],
    [ "CIMP_initConfig", "CIMP__config_8c.html#ac0850ab62f0750506916a8627726cb14", null ]
];