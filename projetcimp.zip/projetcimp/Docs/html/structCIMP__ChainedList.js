var structCIMP__ChainedList =
[
    [ "el", "structCIMP__ChainedList.html#abc88c086a3c2376d15d717ce65516802", null ],
    [ "next", "structCIMP__ChainedList.html#a0c1cbd4553c547344cd8cbd4741897aa", null ]
];