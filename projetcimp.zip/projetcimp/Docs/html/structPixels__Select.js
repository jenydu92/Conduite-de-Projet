var structPixels__Select =
[
    [ "pixels", "structPixels__Select.html#a82f9f9c366b33f721e210ecacca33c32", null ],
    [ "size", "structPixels__Select.html#a5db983a9b419f0602e22ee2d3f2c6bf1", null ],
    [ "width", "structPixels__Select.html#a303fa073dd64d203a3d90a60d5bdecea", null ]
];