var structCIMP__WindowCell =
[
    [ "picture", "structCIMP__WindowCell.html#a90c495e1233e539fa8755a3c062e3db5", null ],
    [ "window", "structCIMP__WindowCell.html#a9bfb6167ae35a61e20eda092409e08b5", null ]
];