var select_8c =
[
    [ "Pixels_Select", "structPixels__Select.html", "structPixels__Select" ],
    [ "clear_selection", "select_8c.html#ae53e44d30fb96c459d935442907795f1", null ],
    [ "create_selec", "select_8c.html#ac7d6e6765a5d920b023d45496c0a992c", null ],
    [ "destroySelec", "select_8c.html#af173ffe2bd205db2c717b643e773cbec", null ],
    [ "selection", "select_8c.html#a85fdbae74db1c71f1866b9ced646d4e3", null ]
];