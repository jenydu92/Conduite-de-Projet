var CIMP__graphicconfig_8h =
[
    [ "CIMP_GetDesktopResolution", "CIMP__graphicconfig_8h.html#a76552284f221ee61f0b8151955a1e6f2", null ]
];