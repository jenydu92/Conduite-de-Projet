var dir_e79632891301b850df87e9c0030293fa =
[
    [ "CIMP_picture.c", "CIMP__picture_8c.html", "CIMP__picture_8c" ],
    [ "CIMP_picture.h", "CIMP__picture_8h.html", "CIMP__picture_8h" ],
    [ "CIMP_picturemanager.c", "CIMP__picturemanager_8c.html", "CIMP__picturemanager_8c" ],
    [ "CIMP_picturemanager.h", "CIMP__picturemanager_8h.html", "CIMP__picturemanager_8h" ],
    [ "CIMP_window.c", "CIMP__window_8c.html", "CIMP__window_8c" ],
    [ "CIMP_window.h", "CIMP__window_8h.html", "CIMP__window_8h" ],
    [ "CIMP_windowmanager.c", "CIMP__windowmanager_8c.html", "CIMP__windowmanager_8c" ],
    [ "CIMP_windowmanager.h", "CIMP__windowmanager_8h.html", "CIMP__windowmanager_8h" ],
    [ "CIMP_workspace.c", "CIMP__workspace_8c.html", "CIMP__workspace_8c" ],
    [ "CIMP_workspace.h", "CIMP__workspace_8h.html", "CIMP__workspace_8h" ]
];