var CIMP__window_8h =
[
    [ "CIMP_Window", "CIMP__window_8h.html#a81aee7c75e938acb948710b6b6bca959", null ],
    [ "CIMP_CreateWindow", "CIMP__window_8h.html#a31ceb132b1d8e1a73df385c5803eff14", null ],
    [ "CIMP_DestroyWindow", "CIMP__window_8h.html#a82a4ec0505ab5c403fe4f899c1f943e1", null ],
    [ "CIMP_GetWindowId", "CIMP__window_8h.html#a7bd0999d28e9d360c9c48e11f33ad09f", null ],
    [ "CIMP_GetWindowTitle", "CIMP__window_8h.html#a3ec7e6d77430886fcae881d268139239", null ],
    [ "CIMP_GetWindowWindow", "CIMP__window_8h.html#aed0dfdbdb30588fd3a084035cec73e0a", null ],
    [ "CIMP_HideWindow", "CIMP__window_8h.html#a6e7b7089fea72febf479d447700c688c", null ],
    [ "CIMP_RepaintWindow", "CIMP__window_8h.html#a2cad1c87ee539e42a93e7d49b8482ad4", null ],
    [ "CIMP_SetWindowPosition", "CIMP__window_8h.html#aa638073e5bdda8e7ab34bdada99bb344", null ],
    [ "CIMP_SetWindowSize", "CIMP__window_8h.html#a1e867481bd568c83cf50c75cd3a3b566", null ],
    [ "CIMP_SetWindowTexture", "CIMP__window_8h.html#ac3e69c447b1bc6ed04ecb154d390f6e2", null ],
    [ "CIMP_SetWindowTitle", "CIMP__window_8h.html#a85eaece8cb7b5f14f86d2cb8f59b8379", null ],
    [ "CIMP_ShowWindow", "CIMP__window_8h.html#acaa422727954219dd26bb6da79fd023d", null ],
    [ "CIMP_WindowIncrementalMoveView", "CIMP__window_8h.html#a5935952305a9280f06872565c54028a4", null ],
    [ "CIMP_WindowMoveView", "CIMP__window_8h.html#a4cc5bc299f10ce9deae0e894a589423e", null ]
];