var CIMP__savefile_8c =
[
    [ "CIMP_IsValidExt", "CIMP__savefile_8c.html#a925ee582da1692f2f2210055b7702708", null ],
    [ "CIMP_SaveFile", "CIMP__savefile_8c.html#ac8da1385d9112c54930d3f27e2e878b6", null ]
];