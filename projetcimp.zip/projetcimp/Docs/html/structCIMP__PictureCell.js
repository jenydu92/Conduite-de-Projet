var structCIMP__PictureCell =
[
    [ "picture", "structCIMP__PictureCell.html#a846db49e3fdac2e36fce25bacd8fa8f8", null ],
    [ "window", "structCIMP__PictureCell.html#a19375af0ec77ef8f50e4f07bf01d8d7e", null ]
];