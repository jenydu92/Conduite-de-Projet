var CIMP__windowmanager_8h =
[
    [ "CIMP_WindowCell", "CIMP__windowmanager_8h.html#aa7f09730f877715d9dcaaab6575e90d7", null ],
    [ "CIMP_CreateWindowCell", "CIMP__windowmanager_8h.html#ae4ac34bc51ebcec8378474f32a2a2a67", null ],
    [ "CIMP_DestroyWindowCell", "CIMP__windowmanager_8h.html#a650d129b879c4e6f608448296103a8b3", null ],
    [ "CIMP_GetWindowCellPicture", "CIMP__windowmanager_8h.html#a23eea44a353ab0264b4c3f8b4802637f", null ],
    [ "CIMP_GetWindowCellWindow", "CIMP__windowmanager_8h.html#ab13de60ca643dc9d7168273a9c813137", null ],
    [ "CIMP_WindowCellAssignPicture", "CIMP__windowmanager_8h.html#a5657775810d5168760893aad22e6af38", null ],
    [ "CIMP_WindowCellPictureExists", "CIMP__windowmanager_8h.html#aa34a0cdc4f965377f81de1849d71e25d", null ],
    [ "CIMP_WindowCellRemovePicture", "CIMP__windowmanager_8h.html#a1002b54a3446614d0412384892534572", null ]
];