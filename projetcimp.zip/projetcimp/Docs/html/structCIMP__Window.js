var structCIMP__Window =
[
    [ "position", "structCIMP__Window.html#af4c92405f6ac672e19d48124b01ae2ef", null ],
    [ "texture", "structCIMP__Window.html#a1e9ad9a94bcc9360629ec87c3fc92eb1", null ],
    [ "window", "structCIMP__Window.html#aacde71342497cdd758b62b557e623037", null ]
];