var CIMP__picture_8h =
[
    [ "CIMP_Picture", "CIMP__picture_8h.html#a678d78cd89e8a7fcb5fed1532324a705", null ],
    [ "CIMP_CreatePicture", "CIMP__picture_8h.html#a00b3b65b562252d641e5c1eb46876646", null ],
    [ "CIMP_DestroyPicture", "CIMP__picture_8h.html#a1ae8b945db81df739dd27bf41d0354df", null ],
    [ "CIMP_GetPictureId", "CIMP__picture_8h.html#a00060df65864508512c281f1c297ccf7", null ],
    [ "CIMP_GetPictureName", "CIMP__picture_8h.html#a1d8972045256efe3d1bd58eae6b23651", null ],
    [ "CIMP_GetPictureSelection", "CIMP__picture_8h.html#ac2ea30cd1b148673e873fc8bb752171a", null ],
    [ "CIMP_GetPictureSurface", "CIMP__picture_8h.html#aa7767a701322d69f9ad39c3f5794a921", null ],
    [ "CIMP_SetPictureName", "CIMP__picture_8h.html#a50118bcc2edbca3e03621ede61e99832", null ],
    [ "CIMP_SetPictureSurface", "CIMP__picture_8h.html#a4f0495d6c9fabb71e5a81bf059bd6e7a", null ]
];