var searchData=
[
  ['keyboard_5fevent',['keyboard_event',['../CIMP__keyboardevent_8c.html#a826dc143b21a60343f2b85b6d90b7af1',1,'keyboard_event(SDL_Event ev, CIMP_Workspace *workspace):&#160;CIMP_keyboardevent.c'],['../CIMP__keyboardevent_8h.html#a312e04f8a6c7f9fb419cc3e3b826bece',1,'keyboard_event(SDL_Event, CIMP_Workspace *):&#160;CIMP_keyboardevent.c']]]
];
