var searchData=
[
  ['listpicture',['listPicture',['../command_8c.html#a3050d179fe46900a09c9e8a9986547c7',1,'listPicture(CIMP_Workspace *workspace):&#160;command.c'],['../command_8h.html#aef433e3f1228e65c05b6937832859641',1,'listPicture(CIMP_Workspace *):&#160;command.c']]],
  ['listwindow',['listWindow',['../command_8c.html#afce8a67abdeca37e2072927edba0b8b4',1,'listWindow(CIMP_Workspace *workspace):&#160;command.c'],['../command_8h.html#ad775834ecc024388f25383103d9d076d',1,'listWindow(CIMP_Workspace *):&#160;command.c']]],
  ['load',['load',['../command_8c.html#a651446287ab5b8f432172ace7a236cc0',1,'load(CIMP_Workspace *workspace, char *path):&#160;command.c'],['../command_8h.html#a739dd1bdb3c63a60d0f08fff12797058',1,'load(CIMP_Workspace *, char *):&#160;command.c']]]
];
