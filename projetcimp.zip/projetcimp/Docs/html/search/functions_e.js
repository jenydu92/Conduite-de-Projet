var searchData=
[
  ['window_5fevent',['window_event',['../CIMP__windowevent_8c.html#a181e6e41cc3a527a51d8d4e5d960e438',1,'window_event(SDL_Event ev, CIMP_Workspace *workspace):&#160;CIMP_windowevent.c'],['../CIMP__windowevent_8h.html#a7ed0ab0df29face7a6958c3217a94b0f',1,'window_event(SDL_Event, CIMP_Workspace *):&#160;CIMP_windowevent.c']]]
];
