var searchData=
[
  ['width',['width',['../structPixels__Select.html#a303fa073dd64d203a3d90a60d5bdecea',1,'Pixels_Select']]],
  ['window',['window',['../structCIMP__PictureCell.html#a19375af0ec77ef8f50e4f07bf01d8d7e',1,'CIMP_PictureCell::window()'],['../structCIMP__Window.html#aacde71342497cdd758b62b557e623037',1,'CIMP_Window::window()'],['../structCIMP__WindowCell.html#a9bfb6167ae35a61e20eda092409e08b5',1,'CIMP_WindowCell::window()']]],
  ['windowlist',['windowList',['../structCIMP__Workspace.html#aca167850893dc839bad59b86f977fbc3',1,'CIMP_Workspace']]],
  ['workspace',['workspace',['../structCIMP__Config.html#a0db196f343701a52d5c77083d36a4e83',1,'CIMP_Config']]]
];
