var searchData=
[
  ['flag',['flag',['../structCommand.html#a01d137ae69489b7a75e3f7271002068e',1,'Command']]]
];
