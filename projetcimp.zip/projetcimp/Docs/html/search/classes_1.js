var searchData=
[
  ['pixels_5fselect',['Pixels_Select',['../structPixels__Select.html',1,'']]]
];
