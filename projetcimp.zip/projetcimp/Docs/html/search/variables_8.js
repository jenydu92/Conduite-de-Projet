var searchData=
[
  ['selection',['selection',['../structCIMP__Picture.html#a43bc028bcf007be9f05252877a59e900',1,'CIMP_Picture']]],
  ['size',['size',['../structPixels__Select.html#a5db983a9b419f0602e22ee2d3f2c6bf1',1,'Pixels_Select']]],
  ['sizeofel',['sizeOfEl',['../structCIMP__HeaderElement.html#a6bdf87348ad81e284ab03e311ff0ade3',1,'CIMP_HeaderElement']]],
  ['surface',['surface',['../structCIMP__Picture.html#a18934f084942d7e04fe38e6f90b2d9cb',1,'CIMP_Picture']]]
];
