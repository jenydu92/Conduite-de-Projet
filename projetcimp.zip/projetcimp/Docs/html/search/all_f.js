var searchData=
[
  ['save',['save',['../command_8c.html#a8021f179d6588e7ebe289428927fe478',1,'save(CIMP_Workspace *workspace, char *idPicture_s, char *path):&#160;command.c'],['../command_8h.html#afe855b4423e04d013c0d3ad985d31811',1,'save(CIMP_Workspace *, char *, char *):&#160;command.c']]],
  ['select_2ec',['select.c',['../select_8c.html',1,'']]],
  ['selection',['selection',['../structCIMP__Picture.html#a43bc028bcf007be9f05252877a59e900',1,'CIMP_Picture::selection()'],['../select_8c.html#a85fdbae74db1c71f1866b9ced646d4e3',1,'selection():&#160;select.c']]],
  ['setflag',['setFlag',['../check__command_8c.html#a3b22ebd79e38835c87e670b9fea1ba5b',1,'setFlag(Command *command, int flag):&#160;check_command.c'],['../check__command_8h.html#a9837a9f8ba08440bd141575fdd753c30',1,'setFlag(Command *, int):&#160;check_command.c']]],
  ['showpicture',['showPicture',['../command_8c.html#a29bedcb47ea76b8e02be6adacf24c955',1,'showPicture(CIMP_Workspace *workspace, char *idPicture_s, char *idWindow_s):&#160;command.c'],['../command_8h.html#a378fbde3c5286538c5356d96964fd94b',1,'showPicture(CIMP_Workspace *, char *, char *):&#160;command.c']]],
  ['showwindow',['showWindow',['../command_8c.html#afc7a2c7c6ba99f5de37661f811b8f26a',1,'showWindow(CIMP_Workspace *workspace, char *idWindow_s):&#160;command.c'],['../command_8h.html#a83702366ca044c6541425d67e2630e48',1,'showWindow(CIMP_Workspace *, char *):&#160;command.c']]],
  ['size',['size',['../structPixels__Select.html#a5db983a9b419f0602e22ee2d3f2c6bf1',1,'Pixels_Select']]],
  ['sizeofel',['sizeOfEl',['../structCIMP__HeaderElement.html#a6bdf87348ad81e284ab03e311ff0ade3',1,'CIMP_HeaderElement']]],
  ['stringtolowercase',['stringToLowerCase',['../CIMP__stringconverter_8c.html#a5f6ccad65f1ed037b627cb81f94bc964',1,'stringToLowerCase(char *s):&#160;CIMP_stringconverter.c'],['../CIMP__stringconverter_8h.html#ae91f7b57f0193e530b28b44bb2e741df',1,'stringToLowerCase(char *):&#160;CIMP_stringconverter.c']]],
  ['stringtosize_5ft',['stringToSize_t',['../CIMP__stringconverter_8c.html#ac64e5feb95aa0ae00d7b8fc100a93819',1,'stringToSize_t(char *s, size_t *number):&#160;CIMP_stringconverter.c'],['../CIMP__stringconverter_8h.html#adfdb5608aebe45c3f52ae79fedf676a9',1,'stringToSize_t(char *, size_t *):&#160;CIMP_stringconverter.c']]],
  ['surface',['surface',['../structCIMP__Picture.html#a18934f084942d7e04fe38e6f90b2d9cb',1,'CIMP_Picture']]]
];
