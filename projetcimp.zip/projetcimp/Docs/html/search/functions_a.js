var searchData=
[
  ['newwindow',['newWindow',['../command_8c.html#a69e4c684bcfcabf3c1732c9e0beee36f',1,'newWindow(CIMP_Workspace *workspace):&#160;command.c'],['../command_8h.html#a67179c585a7003ff244e1caf61935e43',1,'newWindow(CIMP_Workspace *):&#160;command.c']]]
];
