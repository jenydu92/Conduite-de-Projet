var searchData=
[
  ['texture',['texture',['../structCIMP__Window.html#a1e9ad9a94bcc9360629ec87c3fc92eb1',1,'CIMP_Window']]],
  ['thread_5fcli',['thread_cli',['../structCIMP__Config.html#ac980ee08c471790fd90ea92a4a74a5c7',1,'CIMP_Config']]]
];
