var searchData=
[
  ['moveview',['moveView',['../command_8c.html#abe0ace267f9d7b1f0253fd9e5e1d483e',1,'moveView(CIMP_Workspace *workspace, char *id_s, char *x_s, char *y_s):&#160;command.c'],['../command_8h.html#a211da7bac0c89af6dfe577ae7591811d',1,'moveView(CIMP_Workspace *, char *, char *, char *):&#160;command.c']]],
  ['mvt_5fsize',['MVT_SIZE',['../CIMP__keyboardevent_8c.html#a44d790f21dd7bc5e389aa2da2bce4c69',1,'CIMP_keyboardevent.c']]]
];
