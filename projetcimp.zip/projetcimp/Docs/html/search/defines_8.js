var searchData=
[
  ['win_5fdefsize_5fx',['WIN_DEFSIZE_X',['../CIMP__window_8c.html#a7094fffa9f9fd51e4b826a7842c2ae97',1,'CIMP_window.c']]],
  ['win_5fdefsize_5fy',['WIN_DEFSIZE_Y',['../CIMP__window_8c.html#a3bcd43b0167ad96a9c529b6f11204f99',1,'CIMP_window.c']]]
];
