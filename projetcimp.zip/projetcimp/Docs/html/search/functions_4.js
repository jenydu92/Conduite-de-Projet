var searchData=
[
  ['getargv',['getArgv',['../check__command_8c.html#acc50c637e9e0fdcd544c1c09f6a3cc8f',1,'getArgv(Command *command, int i):&#160;check_command.c'],['../check__command_8h.html#a579ac05a201cf1b7297769798ee801fc',1,'getArgv(Command *, int):&#160;check_command.c']]],
  ['getflag',['getFlag',['../check__command_8c.html#a697c0f60ff410342545c497773d5db4c',1,'getFlag(Command *command):&#160;check_command.c'],['../check__command_8h.html#ac19516b272961ab5f3439e3ff5095e1d',1,'getFlag(Command *):&#160;check_command.c']]]
];
