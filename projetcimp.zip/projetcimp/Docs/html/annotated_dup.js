var annotated_dup =
[
    [ "CIMP_ChainedList", "structCIMP__ChainedList.html", "structCIMP__ChainedList" ],
    [ "CIMP_Config", "structCIMP__Config.html", "structCIMP__Config" ],
    [ "CIMP_HeaderElement", "structCIMP__HeaderElement.html", "structCIMP__HeaderElement" ],
    [ "CIMP_Picture", "structCIMP__Picture.html", "structCIMP__Picture" ],
    [ "CIMP_PictureCell", "structCIMP__PictureCell.html", "structCIMP__PictureCell" ],
    [ "CIMP_Window", "structCIMP__Window.html", "structCIMP__Window" ],
    [ "CIMP_WindowCell", "structCIMP__WindowCell.html", "structCIMP__WindowCell" ],
    [ "CIMP_Workspace", "structCIMP__Workspace.html", "structCIMP__Workspace" ],
    [ "Command", "structCommand.html", "structCommand" ],
    [ "Pixels_Select", "structPixels__Select.html", "structPixels__Select" ]
];