var structCIMP__Picture =
[
    [ "id", "structCIMP__Picture.html#ac09ab72802997dbf436768022fada331", null ],
    [ "name", "structCIMP__Picture.html#a3c60d3293b7ea8daa21c491793abb0fb", null ],
    [ "selection", "structCIMP__Picture.html#a43bc028bcf007be9f05252877a59e900", null ],
    [ "surface", "structCIMP__Picture.html#a18934f084942d7e04fe38e6f90b2d9cb", null ]
];