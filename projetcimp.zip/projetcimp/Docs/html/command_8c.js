var command_8c =
[
    [ "deletePicture", "command_8c.html#ad14e96f55a7a9094f46d9c6a642aff26", null ],
    [ "deleteWindow", "command_8c.html#aaa777d84f0b3c6a3cfd0fed4fee69c61", null ],
    [ "getPixel", "command_8c.html#a4636288c613d3fc5d46f6f65e32bc3de", null ],
    [ "help", "command_8c.html#ae0c87f8ef749e46332ec316806d38bb5", null ],
    [ "hidePicture", "command_8c.html#a7b2738ae073dc2783f8bc3b535b1a62a", null ],
    [ "hideWindow", "command_8c.html#af02eb9efc5bdec94961627b1cdbc68a6", null ],
    [ "int2color", "command_8c.html#a5d5a927d5aad64c3a059cf50f7c02014", null ],
    [ "listPicture", "command_8c.html#a3050d179fe46900a09c9e8a9986547c7", null ],
    [ "listWindow", "command_8c.html#afce8a67abdeca37e2072927edba0b8b4", null ],
    [ "load", "command_8c.html#a651446287ab5b8f432172ace7a236cc0", null ],
    [ "moveView", "command_8c.html#abe0ace267f9d7b1f0253fd9e5e1d483e", null ],
    [ "newWindow", "command_8c.html#a69e4c684bcfcabf3c1732c9e0beee36f", null ],
    [ "renamePicture", "command_8c.html#a79c3dffc3fb5d676cda7d32cf6f79b40", null ],
    [ "resetView", "command_8c.html#adafa3e964dd5b0de629ae2cb6ef15f8d", null ],
    [ "save", "command_8c.html#a8021f179d6588e7ebe289428927fe478", null ],
    [ "setPixel", "command_8c.html#a64f20240c05dadc7c085d9faadba34c6", null ],
    [ "showPicture", "command_8c.html#a29bedcb47ea76b8e02be6adacf24c955", null ],
    [ "showWindow", "command_8c.html#afc7a2c7c6ba99f5de37661f811b8f26a", null ],
    [ "transformationCouleur", "command_8c.html#a2c32e6a9e311dbbe8759a442e11d2d19", null ]
];