var CIMP__graphicconfig_8c =
[
    [ "CIMP_GetDesktopResolution", "CIMP__graphicconfig_8c.html#ae62a0176bd7d97df632dd52a61668069", null ]
];