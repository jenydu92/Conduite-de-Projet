var CIMP__picture_8c =
[
    [ "CIMP_Picture", "structCIMP__Picture.html", "structCIMP__Picture" ],
    [ "CIMP_CreatePicture", "CIMP__picture_8c.html#ac17f590576e7a892336919dcac85334a", null ],
    [ "CIMP_DestroyPicture", "CIMP__picture_8c.html#a06e1064e8b7f90be5140bc204f21c9ec", null ],
    [ "CIMP_GetPictureId", "CIMP__picture_8c.html#afda68e4aa4d9006fd016ae0c82382ae0", null ],
    [ "CIMP_GetPictureName", "CIMP__picture_8c.html#ade7bf074287bf7c058001848cbf930ef", null ],
    [ "CIMP_GetPictureSelection", "CIMP__picture_8c.html#a4ee85904534c6d4028f3316788cc6fb3", null ],
    [ "CIMP_GetPictureSurface", "CIMP__picture_8c.html#a281e8eacb674f49670ee332a06374cb3", null ],
    [ "CIMP_SetPictureName", "CIMP__picture_8c.html#a8643cb6a3c8f68d47d1c7c24361b8d65", null ],
    [ "CIMP_SetPictureSurface", "CIMP__picture_8c.html#a91154669b5f05ad005f38c1251941a7b", null ]
];