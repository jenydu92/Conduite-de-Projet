var structCommand =
[
    [ "argc", "structCommand.html#acf9775f3f2d7b30d081130ac663b7f23", null ],
    [ "argv", "structCommand.html#ae1cd318be0c63a63186a8ddac3b3d840", null ],
    [ "flag", "structCommand.html#a01d137ae69489b7a75e3f7271002068e", null ]
];