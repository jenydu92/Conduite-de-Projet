var structCIMP__Config =
[
    [ "command", "structCIMP__Config.html#aa748c9944ba943ea22e9dc712b1a8b3a", null ],
    [ "ev", "structCIMP__Config.html#a2174a3c5aedd477ecd125e7b65bdc136", null ],
    [ "thread_cli", "structCIMP__Config.html#ac980ee08c471790fd90ea92a4a74a5c7", null ],
    [ "workspace", "structCIMP__Config.html#a0db196f343701a52d5c77083d36a4e83", null ]
];