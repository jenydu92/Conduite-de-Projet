var CIMP__window_8c =
[
    [ "CIMP_Window", "structCIMP__Window.html", "structCIMP__Window" ],
    [ "WIN_DEFSIZE_X", "CIMP__window_8c.html#a7094fffa9f9fd51e4b826a7842c2ae97", null ],
    [ "WIN_DEFSIZE_Y", "CIMP__window_8c.html#a3bcd43b0167ad96a9c529b6f11204f99", null ],
    [ "CIMP_CreateRenderer", "CIMP__window_8c.html#aece9d1fe1f0896748432dd73986f6d78", null ],
    [ "CIMP_CreateWindow", "CIMP__window_8c.html#add80a202f6158fd343ea1f9676e214cb", null ],
    [ "CIMP_DestroyWindow", "CIMP__window_8c.html#a14358b6912ba3f5d7d0858080cebe4e6", null ],
    [ "CIMP_GetWindowId", "CIMP__window_8c.html#afc8c9d37e42f27f0dde4a6721344f8d8", null ],
    [ "CIMP_GetWindowTitle", "CIMP__window_8c.html#ad414a8e542b28a6b9e812d5ec06db653", null ],
    [ "CIMP_GetWindowWindow", "CIMP__window_8c.html#a371ff6442fa6e6c0863de634188154a1", null ],
    [ "CIMP_HideWindow", "CIMP__window_8c.html#a30c5e74cf19b6343a755aa96a0af55fb", null ],
    [ "CIMP_MakeWindowTitle", "CIMP__window_8c.html#a6537d35873c3903a027844b1d018e1b2", null ],
    [ "CIMP_RepaintWindow", "CIMP__window_8c.html#a2bf48661369940750dfa1921508ef3c7", null ],
    [ "CIMP_SetWindowPosition", "CIMP__window_8c.html#a68c76a9dbcc455cf06e56b01a13353fd", null ],
    [ "CIMP_SetWindowSize", "CIMP__window_8c.html#a688e6503e799e022531cd08e234378c0", null ],
    [ "CIMP_SetWindowTexture", "CIMP__window_8c.html#a069a249d546f766e4d2a00728a2b2849", null ],
    [ "CIMP_SetWindowTitle", "CIMP__window_8c.html#a4106d381849d0620adbed15729c64c24", null ],
    [ "CIMP_ShowWindow", "CIMP__window_8c.html#a1e2f640212d80c7074680ecb1904a3f2", null ],
    [ "CIMP_WindowIncrementalMoveView", "CIMP__window_8c.html#ac7d3dc92539a373da2f3a0ba0af3b475", null ],
    [ "CIMP_WindowMoveView", "CIMP__window_8c.html#abc0afccfaace03e9a05f8508f02ebc95", null ]
];